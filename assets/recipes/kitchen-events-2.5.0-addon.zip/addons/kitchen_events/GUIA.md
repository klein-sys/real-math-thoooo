# Kitchen Events — guia de uso

Eventos no estilo RPG Maker para a Godot 4: páginas, condições, switches
locais (A, B, C, D) e globais, variáveis e uma lista de comandos editada
numa janela própria.

Versão 2.3.0 · Godot 4.7 · somente GDScript · funciona em jogos de plataforma
e de visão de cima · editor em português e inglês.

Programadores: veja também a [referência da API](API.md) (em inglês).
English: [GUIDE.md](GUIDE.md).

---

## 1. Instalação

1. Extraia o zip na **pasta raiz do projeto** (onde está o `project.godot`).
   O resultado precisa ser `res://addons/kitchen_events/plugin.cfg`.
   - No Windows, "Extrair tudo" cria uma pasta extra com o nome do zip. Se
     acontecer, mova a pasta `kitchen_events` para dentro de `addons`.
   - Se a pasta estiver no lugar errado, o plugin avisa no painel Saída.
2. **Projeto > Configurações do Projeto > Plugins** → ative **Kitchen Events**.

Ao ativar, o plugin cria o autoload **KitchenEvents** e a ação **interact**
(E, Espaço, Enter e botão A), se ela ainda não existir.

**Idioma:** o editor acompanha o idioma do editor da Godot (português ou
inglês). Para escolher, use **Configurações do Projeto > Kitchen Events > UI >
Language**.

---

## 2. O jogador

Não precisa adicionar nada no jogador. O plugin encontra o jogador assim:

1. o nó que está no grupo **player** (configurável); ou, se ninguém estiver
   no grupo, o `CharacterBody2D` da cena que:
2. tem o método `can_interact()` ou `begin_cutscene()`; ou
3. se chama Player, Jogador, Hero ou Herói (nome do nó ou `class_name`); ou
4. tem a Camera2D ativa como filha.

Se nada disso existir, o evento mostra um aviso amarelo no editor. Aí é só
colocar o nó do jogador no grupo `player` (aba **Nó > Grupos**).

O jogo **não precisa ter sistema de mensagens**: o plugin traz a própria caixa
de fala.

Durante um evento, o jogo é pausado (veja Pause Mode na seção 8) e o plugin
assume o jogador. Há dois jeitos:

- **Automático** (qualquer jogo): o plugin para o script do jogador, anda com
  ele usando a física (com gravidade, em jogos de plataforma) e troca as
  animações pelo nome (`walk`/`run`/`andar` e `idle`/`parado`), virando pelo
  `flip_h` do sprite.
- **Com contrato de cutscene** (opcional, como o Tommy de O Último Verão): se o
  jogador tiver estes métodos, o plugin usa eles:

```gdscript
func can_interact() -> bool          # pode apertar o botão agora? (ex.: só no chão)
func can_travel() -> bool            # pode ser levado por um evento "Ao tocar"?
func begin_cutscene(controller: Node) -> bool   # false = recusa o evento
func end_cutscene(controller: Node) -> void
func cutscene_face(left: bool) -> void
func cutscene_motion(direction: float, speed: float, delta: float) -> void  # chamado a cada quadro ao andar
func cutscene_stop() -> void
func cutscene_play_animation(animation: StringName, speed: float) -> float
```

Todos são opcionais. Use só os que fizerem sentido no seu jogo.

---

## 3. Criando um evento

1. Na fase, adicione um nó **KEEvent** (Ctrl+A e busque "KEEvent").
2. Ele já vem com um **Sensor** (CollisionShape2D 32×32): é a área em que o
   jogador pode interagir. Ajuste o tamanho como quiser. Pode mover o evento ou
   só o Sensor: o aviso "E · Ler" sempre aparece acima do sensor.
3. Para a imagem do objeto, coloque um **Sprite2D** ou **AnimatedSprite2D**
   como filho do evento (placa, NPC, baú...).
4. No Inspector, clique em **Editar evento…**.

![Inspector](images/editor_inspector.png)

### A janela do evento

![Editor](images/editor_event.png)

- **Páginas** (esquerda): lista de páginas, nome, ativação, verbo, repetição,
  imagem, condições e opções de conclusão.
- **Sequência de comandos** (meio): botões **+ Fala**, **+ Movimento**,
  **+ Espera**, **+ Switch** e **Mais comandos ▾**. Clique numa linha para
  editar. Del exclui, Ctrl+D duplica.
- **Editar** (direita): o formulário do comando. **Concluir comando** guarda a
  edição no rascunho; trocar de linha também guarda. **Descartar edição**
  desfaz só aquele comando.
- **Aplicar e fechar** grava no nó (com Ctrl+Z). **Cancelar** não muda nada.
  Depois, salve a cena com Ctrl+S.

Comandos novos entram logo **abaixo** da linha selecionada.

---

## 4. Páginas, condições e switches

**Regra principal:** vale a **última** página habilitada cujas condições são
todas atendidas. Ela decide a imagem, o verbo do aviso e o que acontece.

**Ativação**

| Opção | Começa quando |
| --- | --- |
| Apertar botão | o jogador está no sensor e aperta interagir (aparece "E / Y · Verbo") |
| Ao tocar | o jogador entra no sensor. Só dispara de novo depois que ele sair |
| Automático | a página fica ativa. Desligue-a no fim (ex.: switch local A) |
| Processo paralelo | a página fica ativa, e roda **em loop, ao fundo**, sem travar o jogador. Para junto com a pausa do jogo. Não mostra falas |

**Repetição:** Sempre, Uma vez ou um limite. Conta só execuções concluídas.

**Condições:** **+ Condição de switch** cria uma linha
`Local · A · Ligado` ou `Global · nome · Desligado`. Em **Outras condições**
há **Variável** (=, ≠, >, ≥, <, ≤) e **Método do código**.

- **Switch local** (A, B, C, D): pertence só a este evento. Ideal para "já
  abri este baú", "já falei com este NPC".
- **Switch global** (por nome): compartilhado entre eventos e fases, como
  `portao_aberto`.
- Um switch que nunca foi ligado conta como Desligado; variável nova vale 0.

**Switches "Ao terminar":** no **+ Switch**, escolha *Ao terminar toda a
página*. Eles aparecem no fim da lista e só são aplicados se a página terminar
inteira. Se o evento for interrompido, nada é aplicado. *Concluir ao pular as
falas* define se apertar Esc / B conta como concluído.

### Exemplo: baú que abre uma vez

![Baú](images/editor_chest.png)

- **Página 1 · Fechado**: Fala "Você encontrou 25 moedas!", Variável
  `ouro += 25`, e **Switch Ao terminar: Local A = Ligado**.
- **Página 2 · Aberto**: condição **Local · A · Ligado**; Imagem: *Trocar por
  outra imagem* (baú aberto); Fala "O baú está vazio.".

### Exemplo: conversa que muda depois

- **Página 1**: Ativação *Ao tocar*, condição **Local A Desligado**, três falas
  e **Ao terminar: Local A = Ligado**.
- **Página 2**: Ativação *Apertar botão*, verbo "Ler", condição **Local A
  Ligado**, a fala do aviso.

---

## 5. Comandos

| Comando | O que faz |
| --- | --- |
| **Fala** | Nome, texto e retrato. Falas seguidas formam uma conversa: Esc / B pula a conversa inteira e o evento segue nos comandos seguintes |
| **Movimento** | Jogador, este evento ou outro nó anda N pixels (direita, esquerda, cima, baixo, para o jogador, para longe) |
| **Espera** | Pausa em segundos |
| **Switch** | Liga, desliga ou inverte switches locais/globais, agora ou ao terminar |
| Escolhas | Opções, cada uma com a sua lista de comandos (aparece indentada) |
| Chamar evento comum | Executa um evento comum aqui (veja abaixo) |
| **Balão de emoção** | !, ?, ♪, coração, raiva, gota, reticências, ideia ou zZ acima de um personagem |
| Condição (se / senão) | Roda "Então" ou "Senão" conforme switches, variáveis ou métodos |
| Variável | `=`, `+`, `−`, `×`, `÷`, resto |
| Virar | Vira o jogador, este evento ou outro nó (inclusive para o jogador) |
| Animação | Toca uma animação (AnimatedSprite2D, AnimationPlayer ou contrato) |
| Câmera | Focar um alvo, zoom ou voltar. Volta sozinha no fim do evento |
| **Tela** | Escurecer, clarear, piscar, tremer, tingir (noite, entardecer) e remover a tinta |
| **Imagem** | Mostra uma imagem na tela (lugares 1 a 10) ou apaga, com fade |
| **Música** | Toca em loop com fade, para ou volta à música anterior |
| Som | Toca um som |
| Transferir | Vai para outra cena, até um nó (ex.: Marker2D). Encerra o evento |
| Encerrar evento | Para aqui; conta como concluído |
| Chamar método | Chama uma função do seu código (pode esperar se usar `await`) |
| Emitir sinal | Emite `command_signal(nome, argumentos)` do evento |

**Texto das falas:** aceita BBCode (`[b]negrito[/b]`,
`[color=gold]cor[/color]`) e `{v:ouro}` para mostrar uma variável.

### Eventos comuns

![Eventos comuns](images/editor_comuns.png)

Sequências criadas uma vez e chamadas por qualquer evento, em qualquer fase
(ex.: "Achou tesouro", "Dormir na pousada"). Abra pelo botão **Eventos
comuns…** no Inspector de um evento, ou em **Projeto > Ferramentas > Kitchen
Events: eventos comuns…**. É o mesmo editor, mas a coluna da esquerda mostra
só o nome. Depois, use **Mais comandos > Chamar evento comum**.

Switches locais dentro de um evento comum valem para o evento que chamou. Os
eventos comuns ficam em `res://kitchen_events_eventos_comuns.tres`.

### Movimento próprio

![Movimento próprio](images/editor_movimento.png)

Na página, o cartão **Movimento próprio** faz o evento andar sozinho:
**Ida e volta** (patrulha) ou **Ao acaso**, com distância, velocidade e pausa
entre as caminhadas. O NPC para enquanto alguém conversa com ele e para junto
com a pausa do jogo.

### Pacote de cinema

![Balões](images/baloes.png)

- **Balão de emoção** aparece acima da cabeça do personagem (jogador, este
  evento ou outro nó). Com "Esperar o balão sumir", o evento continua depois.
- **Escurecer** e **Tingir** continuam valendo depois que o evento termina:
  use **Clarear** e **Remover tinta** quando quiser voltar ao normal. Falas
  aparecem por cima da tela escura ("Anos depois..."). A tinta pinta só o
  mundo; o HUD do jogo continua com as cores normais.
- **Imagem** também continua na tela até um "Apagar imagem" com o mesmo número.
- **Música**: com "Pausar a música do jogo", a música que o jogo estiver
  tocando para durante a do evento e volta do mesmo ponto depois. "Voltar à
  anterior" retoma a música de antes.

**Personagens:** em **Escolher ▾ > Personagens…** cadastre nome, retrato e
cor do nome. Falas com retrato *Automático pelo personagem* usam esse cadastro
(arquivo `res://kitchen_events_personagens.tres`).

---

## 6. Salvando o jogo

O plugin não grava arquivos: o seu jogo guarda os dados onde quiser.

```gdscript
var dados := KitchenEvents.save_data()      # Dictionary pronto para JSON
KitchenEvents.load_data(dados)              # false = dados inválidos, nada muda
KitchenEvents.reset()                       # novo jogo
```

Cada evento tem um id fixo (`ev_...`). Switches locais e contadores ficam
guardados com *cena + id*, então mover ou renomear o nó não perde o progresso.
Ao duplicar um evento, a cópia ganha um id novo quando a cena é salva.

---

## 7. Integrando com o código

```gdscript
KitchenEvents.set_switch("ponte_consertada", true)
KitchenEvents.get_variable("ouro")
KitchenEvents.is_busy()                       # algum evento rodando?
KitchenEvents.event_started.connect(...)
KitchenEvents.event_finished.connect(...)
$MeuEvento.start()                            # inicia pelo código
$MeuEvento.command_signal.connect(func(nome, args): ...)
```

**Comando próprio:** um script que herda de `KECommand` aparece sozinho em
*Mais comandos ▾ > Seus comandos*:

```gdscript
@tool
class_name DarItemCommand
extends KECommand

@export var item := ""

func execute(ctx: KEContext) -> void:
    Inventario.adicionar(item)
    await ctx.wait(0.2)

func get_command_name() -> String: return "Dar item"
func get_summary() -> String: return item
func is_valid() -> bool: return not item.is_empty()
```

---

## 8. Configurações do projeto (Kitchen Events)

| Configuração | Padrão |
| --- | --- |
| Input > Interact Action | `interact` |
| Input > Cancel Action | `ui_cancel` (pular falas) |
| Player > Group | `player` |
| Runtime > Pause Mode | Pausar o jogo inteiro (padrão) ou Parar só o jogador e o evento |
| UI > Language | Automático (ou Português / English) |
| UI > Dialogue Scene | caixa padrão (pode usar a sua) |
| UI > Text Speed | 40 letras/s |
| UI > Prompt Font Size | 14 px |
| Editor > Cast | `res://kitchen_events_personagens.tres` |
| Editor > Common Events | `res://kitchen_events_eventos_comuns.tres` |

**Pause Mode:** se o seu jogo mostra o menu de pausa sempre que o jogo está
pausado (como The Forgotten Well), escolha **Parar só o jogador e o evento**.
Assim só o jogador e o evento param; inimigos e o resto da fase continuam.
Durante um evento, a caixa de fala recebe as teclas antes dos scripts da fase,
então Esc pula a fala em vez de abrir a pausa do jogo.

**Caixa de fala própria:** a cena precisa ter
`show_message(line, keep_open) -> bool`, `show_choices(opcoes, cancelar) -> int`
e `close()`.

---

## 9. Limitações conhecidas

- Um evento normal por vez. Processos paralelos e movimento próprio rodam
  junto com ele.
- Andar em cutscene no modo automático usa a física do corpo; personagens com
  controle muito próprio ficam melhores com o contrato de cutscene.
- A interface do plugin está em português e inglês. O texto dos seus eventos
  (falas, escolhas) aparece como você escreveu.
- Testado na Godot 4.7.2 no Windows, na demo e em cópias de O Último Verão,
  The Forgotten Well e The Last Mask. Exportação para outras plataformas não
  foi testada.


## Inventário: condições e comandos de item (2.4.0)

Na coluna da página, escolha **Outras condições > Item**. Selecione **Possui
item** ou **Não possui item**, escreva o ID (ex.: `chave_do_poco`) e a quantidade
mínima. “Não possui” significa ter menos que essa quantidade. A consulta não
consome itens. A mesma condição aparece em **Se / Senão > + Item**.

Em **Mais comandos > Lógica**, use **Dar item** e **Remover item**, preenchendo
ID e quantidade no formulário lateral. Uma remoção não permite estoque negativo.
Se o inventário estiver indisponível ou recusar a operação, a execução é
interrompida: os comandos seguintes e as alterações “Ao terminar” não rodam.
Alterações que já ocorreram antes da falha não são desfeitas.

### Conectar o inventário do jogo (uma vez)

Em **Projeto > Configurações do Projeto > Kitchen Events > Inventory > Provider
Path**, informe o caminho absoluto de um nó ou autoload, por exemplo
`/root/Inventario`. Esse nó deve implementar estes três métodos síncronos:

```gdscript
func get_item_count(item_id: String) -> int:
    return inventario_do_jogo.quantidade(item_id)

func add_item(item_id: String, quantity: int) -> bool:
    return inventario_do_jogo.adicionar(item_id, quantity)

func remove_item(item_id: String, quantity: int) -> bool:
    return inventario_do_jogo.remover(item_id, quantity)
```

Essas chamadas são exemplos: adapte os corpos aos métodos reais do seu jogo.
`get_item_count` deve retornar um inteiro não negativo; IDs desconhecidos retornam
0. `add_item` e `remove_item` devem retornar **bool**: true somente se alteraram a
quantidade inteira, false sem alterar nada. Verifique limites, capacidade e itens
válidos dentro do inventário. Métodos que retornam void não atendem ao contrato.

Se o nó só existe na fase, também é possível registrá-lo por código:

```gdscript
func _ready() -> void:
    KitchenEvents.set_inventory_provider(self)
```

Depois de mudanças fora dos comandos (coletar item, compra, carregar save), chame
`KitchenEvents.notify_inventory_changed()` para acordar páginas automáticas.
Os comandos do plugin já notificam. A condição sem inventário configurado sempre
é falsa, inclusive “Não possui”, para não liberar páginas por erro de integração.

O plugin não cria um inventário próprio. O jogo continua responsável pela lista
de itens, interface, capacidade e persistência. Os dados de itens **não** entram
em `KitchenEvents.save_data()`.

Exemplo de porta: página 1 explica que falta a chave; página 2 exige Possui item
`chave_do_poco` × 1, remove a chave e liga o switch local A; página 3 exige A
ligado e representa a porta aberta. A última página válida tem prioridade.


## Transferir jogador com chegada visual (2.5.0)

Dentro de **Editar evento… > Mais comandos > Cena e código**, escolha
**Transferir jogador**. A porta pode ter seus próprios comandos de animação e
som antes da transferência.

1. Escolha a **cena de destino** ou clique em **Este mapa** para teleportar na fase atual.
2. Com **Usar posição marcada no mapa** ligado, clique em **Marcar chegada no mapa…**.
3. Na prévia, clique no chão onde devem ficar os pés do personagem. Use a roda
   para aproximar/afastar e o botão do meio para arrastar a prévia. **Ver mapa
   inteiro** reenquadra o cenário. Confirme em **Usar este ponto**.
4. Escolha **Direita** ou **Esquerda** em **Virar para** (as opções anteriores
   Manter, Cima e Baixo também continuam disponíveis).
5. Marque **Usar fade na transferência** e ajuste a duração por etapa, ou
   desmarque para uma transferência instantânea.
6. Clique em **Concluir comando**, **Aplicar e fechar** e salve a fase.

O fade escurece a tela, o jogador é transferido e a tela é revelada no destino.
O jogador fica sob controle do plugin durante a transição. O serviço global
termina o fade mesmo que a troca de mapa remova a porta original.

**A transferência encerra a sequência de origem.** Coloque animações e sons da
porta antes dela. Comandos depois de Transferir jogador não rodam. Para uma cena
de chegada, crie um evento automático no destino.

Os comandos antigos que usam o nome de um Marker2D continuam funcionando.
Desmarcar **Usar posição marcada no mapa** mostra esse campo novamente.
Escolher outro mapa invalida o ponto anterior: marque uma nova chegada.

A prévia usa as imagens e os tiles salvos da cena, sem executar os scripts de
jogo. Na fase aberta no editor, ela usa os elementos que estão visíveis na cena
atual. Ela não simula colisões, movimento de plataformas ou elementos criados
por scripts: escolha um espaço livre. A posição é salva nas coordenadas locais
do mapa; não é necessário criar um Marker2D.

![Escolha visual da chegada](images/transfer_destination.png)
