extends Label
## The "E · Read" prompt above the event. It stays in screen pixels (does not grow with
## the camera zoom) and does not leave the screen.

const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")

var _anchor := Vector2.ZERO


func _ready() -> void:
	visible = false
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_priority = 100
	z_index = 100
	z_as_relative = false
	horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_theme_font_size_override("font_size", int(Settings.get_value("ui/prompt_font_size")))
	add_theme_color_override("font_color", Color("f1e9d9"))
	add_theme_color_override("font_outline_color", Color("0d1018"))
	add_theme_constant_override("outline_size", 2)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.08, 0.12, 0.88)
	style.border_color = Color("cdb579")
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.content_margin_left = 6
	style.content_margin_right = 6
	style.content_margin_top = 2
	style.content_margin_bottom = 2
	add_theme_stylebox_override("normal", style)


func show_text(value: String, offset: Vector2) -> void:
	text = value
	_anchor = offset
	visible = not value.is_empty()
	_sync()


func _process(_delta: float) -> void:
	if visible:
		_sync()


func _sync() -> void:
	var parent := get_parent() as CanvasItem
	if parent == null or not is_inside_tree():
		return
	var to_screen := get_viewport().get_stretch_transform() * parent.get_global_transform_with_canvas()
	if is_zero_approx(to_screen.determinant()):
		return
	var inverse := to_screen.affine_inverse()
	rotation = inverse.get_rotation()
	scale = inverse.get_scale()
	reset_size()
	var center := to_screen * _anchor
	var at := center - Vector2(size.x * 0.5, size.y)
	var screen := Vector2(get_window().size)
	at.x = clampf(at.x, 4.0, maxf(4.0, screen.x - size.x - 4.0))
	at.y = clampf(at.y, 4.0, maxf(4.0, screen.y - size.y - 4.0))
	position = inverse * at.round()
