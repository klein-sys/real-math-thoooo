class_name KEDialogueBox
extends CanvasLayer
## Default dialogue box: message with name and portrait, typewriter text and
## choices. Supports BBCode in the text.
##
## To use your own box, set Project Settings > Kitchen Events > UI > Dialogue
## Scene to a scene whose root has these methods:
## [codeblock]
## func show_message(line: KEDialogueLine, keep_open: bool) -> bool  # may await; true = skipped
## func show_choices(options: PackedStringArray, cancel_index: int) -> int  # may await
## func close() -> void
## [/codeblock]

signal _message_done(skipped: bool)
signal _choice_done(index: int)

const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

## Characters per second. 0 = show the whole text at once; -1 = Project Settings.
@export var characters_per_second: float = -1.0
## The cancel button skips the rest of the conversation.
@export var allow_skip: bool = true
## 0 = automatic, based on the game resolution.
@export var font_size: int = 0
@export var panel_color: Color = Color("181d29")
@export var border_color: Color = Color("cdb579")
@export var text_color: Color = Color("f1e9d9")
@export var name_color: Color = Color("e8c07c")
## Shows "E · Continue   Esc · Skip" in the corner of the box.
@export var show_hint: bool = true

var _root: Control
var _panel: PanelContainer
var _portrait: TextureRect
var _name: Label
var _text: RichTextLabel
var _arrow: Label
var _hint: Label
var _choice_panel: PanelContainer
var _choice_list: VBoxContainer
var _is_open := false
var _waiting_message := false
var _waiting_choice := false
var _cancel_index := -1
var _input_ready := false
var _revealed := 0.0
var _blink := 0.0
var _font := 16


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	_root.visible = false


func is_open() -> bool:
	return _is_open


## Shows one message and waits for the player. Returns true when skipped.
func show_message(line: Resource, keep_open: bool = false) -> bool:
	_open()
	_name.text = line.speaker
	_name.visible = not line.speaker.is_empty()
	var color: Color = line.get("name_color") if line.get("name_color") is Color else Color(0, 0, 0, 0)
	_name.add_theme_color_override("font_color", color if color.a > 0.0 else name_color)
	_update_hint()
	_portrait.texture = line.portrait
	_portrait.visible = line.portrait != null
	_text.text = line.text
	_revealed = 0.0
	_text.visible_characters = 0 if _speed() > 0.0 else -1
	_choice_panel.visible = false
	_waiting_message = true
	var skipped: bool = await _message_done
	_waiting_message = false
	if skipped or not keep_open:
		close()
	return skipped


## Shows options and returns the chosen index ([param cancel_index] on cancel).
func show_choices(options: PackedStringArray, cancel_index: int = -1) -> int:
	_open()
	_text.visible_characters = -1
	if _text.text.is_empty():
		_panel.visible = false
	for child in _choice_list.get_children():
		child.queue_free()
	var first: Button = null
	for i in options.size():
		var button := Button.new()
		button.text = options[i]
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_font_size_override("font_size", _font)
		button.add_theme_color_override("font_color", text_color)
		button.add_theme_color_override("font_focus_color", name_color)
		button.add_theme_color_override("font_hover_color", name_color)
		button.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
		button.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
		button.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
		var focus := StyleBoxFlat.new()
		focus.bg_color = Color(border_color, 0.18)
		focus.border_color = border_color
		focus.set_border_width_all(1)
		focus.set_corner_radius_all(3)
		focus.set_content_margin_all(maxi(_font / 4, 2))
		button.add_theme_stylebox_override("focus", focus)
		button.pressed.connect(_on_choice_pressed.bind(i))
		_choice_list.add_child(button)
		if first == null:
			first = button
	_choice_panel.visible = true
	_cancel_index = cancel_index
	_waiting_choice = true
	if first != null:
		first.grab_focus.call_deferred()
	var index: int = await _choice_done
	_waiting_choice = false
	close()
	return index


func close() -> void:
	_is_open = false
	_root.visible = false
	_text.text = ""
	_choice_panel.visible = false
	_panel.visible = true


func _open() -> void:
	if not _is_open:
		_input_ready = false
	_is_open = true
	_root.visible = true
	_panel.visible = true


func _speed() -> float:
	return characters_per_second if characters_per_second >= 0.0 else float(Settings.get_value("ui/text_speed"))


func _process(delta: float) -> void:
	if not _is_open:
		return
	if not _input_ready and not _any_pressed():
		_input_ready = true
	var total := _text.get_total_character_count()
	if _waiting_message and _text.visible_characters >= 0:
		_revealed += delta * _speed()
		_text.visible_characters = mini(int(_revealed), total)
		if _text.visible_characters >= total:
			_text.visible_characters = -1
	_blink += delta
	_arrow.visible = _waiting_message and _text.visible_characters < 0 and fmod(_blink, 0.8) < 0.5


func _update_hint() -> void:
	if _hint == null:
		return
	var advance := Settings.action_hint(Settings.interact_action())
	var skip := Settings.action_hint(Settings.cancel_action())
	var parts: Array[String] = []
	if not advance.is_empty():
		parts.append(advance + " · " + Text.t("Continuar"))
	if allow_skip and not skip.is_empty():
		parts.append(skip + " · " + Text.t("Pular"))
	_hint.text = "     ".join(parts)
	_hint.visible = show_hint and not parts.is_empty()


func _input(event: InputEvent) -> void:
	if not _is_open or not _input_ready:
		return
	if _waiting_choice:
		if _is_cancel(event) and _cancel_index >= 0:
			get_viewport().set_input_as_handled()
			_choice_done.emit(_cancel_index)
		elif event.is_action_pressed(Settings.interact_action()) and not event.is_echo():
			var focused := get_viewport().gui_get_focus_owner() as Button
			if focused != null and focused.get_parent() == _choice_list:
				get_viewport().set_input_as_handled()
				focused.pressed.emit()
		return
	if not _waiting_message:
		return
	if _is_advance(event):
		get_viewport().set_input_as_handled()
		if _text.visible_characters >= 0:
			_text.visible_characters = -1
		else:
			_message_done.emit(false)
	elif allow_skip and _is_cancel(event):
		get_viewport().set_input_as_handled()
		_message_done.emit(true)


func _is_advance(event: InputEvent) -> bool:
	if event.is_echo():
		return false
	if event.is_action_pressed(Settings.interact_action()) or event.is_action_pressed(&"ui_accept"):
		return true
	return event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT


func _is_cancel(event: InputEvent) -> bool:
	return event.is_action_pressed(Settings.cancel_action()) and not event.is_echo()


func _any_pressed() -> bool:
	for action in [Settings.interact_action(), &"ui_accept", Settings.cancel_action()]:
		if InputMap.has_action(action) and Input.is_action_pressed(action):
			return true
	return false


func _on_choice_pressed(index: int) -> void:
	if _waiting_choice:
		_choice_done.emit(index)


func _build() -> void:
	var height := get_viewport().get_visible_rect().size.y if get_viewport() != null else 720.0
	_font = font_size if font_size > 0 else clampi(roundi(height / 26.0), 8, 28)
	var space := maxi(_font / 2, 4)
	_root = Control.new()
	_root.name = "Root"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "bottom", "top"]:
		margin.add_theme_constant_override("margin_" + side, space)
	_root.add_child(margin)

	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_END
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(column)

	_choice_panel = PanelContainer.new()
	_choice_panel.size_flags_horizontal = Control.SIZE_SHRINK_END
	_choice_panel.add_theme_stylebox_override("panel", _style())
	_choice_list = VBoxContainer.new()
	_choice_list.add_theme_constant_override("separation", maxi(_font / 4, 2))
	_choice_panel.add_child(_choice_list)
	column.add_child(_choice_panel)

	_panel = PanelContainer.new()
	_panel.custom_minimum_size.y = _font * 5.5
	_panel.add_theme_stylebox_override("panel", _style())
	column.add_child(_panel)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", space)
	_panel.add_child(row)

	_portrait = TextureRect.new()
	_portrait.custom_minimum_size = Vector2(_font, _font) * 4.5
	_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_portrait.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_portrait.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(_portrait)

	var text_column := VBoxContainer.new()
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text_column)

	_name = Label.new()
	_name.add_theme_color_override("font_color", name_color)
	_name.add_theme_font_size_override("font_size", _font)
	text_column.add_child(_name)

	_name.add_theme_constant_override("outline_size", 0)
	_text = RichTextLabel.new()
	_text.add_theme_color_override("default_color", text_color)
	_text.bbcode_enabled = true
	_text.fit_content = true
	_text.scroll_active = false
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for font_type in ["normal_font_size", "bold_font_size", "italics_font_size", "bold_italics_font_size", "mono_font_size"]:
		_text.add_theme_font_size_override(font_type, _font)
	text_column.add_child(_text)

	var bottom := HBoxContainer.new()
	text_column.add_child(bottom)
	_hint = Label.new()
	_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hint.add_theme_color_override("font_color", Color(text_color, 0.55))
	_hint.add_theme_font_size_override("font_size", maxi(_font * 3 / 4, 6))
	bottom.add_child(_hint)
	_arrow = Label.new()
	_arrow.text = "▼"
	_arrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_arrow.add_theme_color_override("font_color", border_color)
	_arrow.add_theme_font_size_override("font_size", maxi(_font - 2, 6))
	bottom.add_child(_arrow)


func _style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = panel_color
	style.border_color = border_color
	style.set_border_width_all(maxi(_font / 8, 2))
	style.set_corner_radius_all(maxi(_font / 6, 2))
	style.set_content_margin_all(maxi(_font * 2 / 3, 4))
	return style
