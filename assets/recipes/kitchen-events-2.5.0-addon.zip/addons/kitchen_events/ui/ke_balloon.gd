extends Control
## Emotion balloon above a character: !, ?, ♪, heart, anger, sweat drop,
## ellipsis, idea and sleep. Drawn by code, in screen pixels.

signal finished

enum Kind { EXCLAMATION, QUESTION, MUSIC, HEART, ANGER, SWEAT, SILENCE, IDEA, SLEEP }

const SIZE := Vector2(30, 26)
const TAIL := 6.0

var kind: Kind = Kind.EXCLAMATION
var anchor := Vector2.ZERO
var hold_time := 1.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	z_index = 100
	z_as_relative = false
	size = SIZE + Vector2(0, TAIL)
	_sync()
	var tween := create_tween()
	tween.tween_method(_pop, 0.0, 1.0, 0.14)
	tween.tween_interval(hold_time)
	tween.tween_property(self, "modulate:a", 0.0, 0.2)
	tween.tween_callback(func() -> void:
		finished.emit()
		queue_free())


var _pop_amount := 0.0


func _pop(amount: float) -> void:
	_pop_amount = amount
	_sync()


func _process(_delta: float) -> void:
	_sync()


## Keeps the balloon in screen pixels, above the parent's [member anchor] point.
func _sync() -> void:
	var parent := get_parent() as CanvasItem
	if parent == null or not is_inside_tree():
		return
	var to_screen := get_viewport().get_stretch_transform() * parent.get_global_transform_with_canvas()
	if is_zero_approx(to_screen.determinant()):
		return
	var inverse := to_screen.affine_inverse()
	rotation = inverse.get_rotation()
	var pop := 1.0 + 0.25 * sin(_pop_amount * PI) if _pop_amount < 1.0 else 1.0
	scale = inverse.get_scale() * _pop_amount * pop
	var bottom := to_screen * anchor
	position = inverse * (bottom - Vector2(size.x * 0.5, size.y) * _pop_amount * pop).round()


func _draw() -> void:
	var body := Rect2(Vector2.ZERO, SIZE)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("fbf8ef")
	style.border_color = Color("1d1a26")
	style.set_border_width_all(2)
	style.set_corner_radius_all(8)
	draw_style_box(style, body)
	var mid := SIZE.x * 0.5
	draw_colored_polygon(PackedVector2Array([Vector2(mid - 5, SIZE.y - 2), Vector2(mid + 5, SIZE.y - 2), Vector2(mid, SIZE.y + TAIL)]), Color("fbf8ef"))
	draw_polyline(PackedVector2Array([Vector2(mid - 5, SIZE.y - 1), Vector2(mid, SIZE.y + TAIL), Vector2(mid + 5, SIZE.y - 1)]), Color("1d1a26"), 2.0)
	var c := SIZE * 0.5
	match kind:
		Kind.EXCLAMATION:
			var red := Color("e0383e")
			draw_rect(Rect2(c.x - 2, c.y - 8, 4, 11), red)
			draw_circle(Vector2(c.x, c.y + 7), 2.2, red)
		Kind.QUESTION:
			_text("?", Color("2f6fd6"), 20)
		Kind.MUSIC:
			var purple := Color("8a4fd1")
			draw_circle(Vector2(c.x - 3, c.y + 5), 3.2, purple)
			draw_rect(Rect2(c.x - 0.5, c.y - 8, 2, 13), purple)
			draw_colored_polygon(PackedVector2Array([Vector2(c.x + 1, c.y - 8), Vector2(c.x + 7, c.y - 5), Vector2(c.x + 7, c.y - 2), Vector2(c.x + 1, c.y - 5)]), purple)
		Kind.HEART:
			var pink := Color("e8456b")
			draw_circle(Vector2(c.x - 3.5, c.y - 2), 4.2, pink)
			draw_circle(Vector2(c.x + 3.5, c.y - 2), 4.2, pink)
			draw_colored_polygon(PackedVector2Array([Vector2(c.x - 7.6, c.y - 0.5), Vector2(c.x + 7.6, c.y - 0.5), Vector2(c.x, c.y + 8)]), pink)
		Kind.ANGER:
			var red := Color("d8323a")
			for corner in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
				var p: Vector2 = c + corner * 3.0
				draw_line(p, p + Vector2(corner.x * 5, 0), red, 2.5)
				draw_line(p, p + Vector2(0, corner.y * 5), red, 2.5)
		Kind.SWEAT:
			var blue := Color("4aa3e8")
			draw_circle(Vector2(c.x, c.y + 3), 4.5, blue)
			draw_colored_polygon(PackedVector2Array([Vector2(c.x - 4.2, c.y + 1.5), Vector2(c.x + 4.2, c.y + 1.5), Vector2(c.x, c.y - 8)]), blue)
		Kind.SILENCE:
			for x in [-7.0, 0.0, 7.0]:
				draw_circle(Vector2(c.x + x, c.y + 1), 2.2, Color("1d1a26"))
		Kind.IDEA:
			var yellow := Color("f3c21a")
			draw_circle(Vector2(c.x, c.y - 2), 6.0, yellow)
			draw_rect(Rect2(c.x - 3, c.y + 4, 6, 4), Color("8a8f99"))
		Kind.SLEEP:
			_text("zZ", Color("3a6fd0"), 15)


func _text(value: String, color: Color, font_size: int) -> void:
	var font := get_theme_default_font()
	var width := font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string(font, Vector2((SIZE.x - width) * 0.5, SIZE.y * 0.5 + font_size * 0.36), value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)
