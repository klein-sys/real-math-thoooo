@tool
class_name KESwitchCondition
extends "res://addons/kitchen_events/core/ke_condition.gd"
## A Local switch (A-D, of this event) or Global switch (by name) is On or Off.

const Names = preload("res://addons/kitchen_events/core/ke_names.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Scope { LOCAL, GLOBAL }

@export var scope: Scope = Scope.LOCAL:
	set(value):
		scope = value
		notify_property_list_changed()
@export_enum("A", "B", "C", "D") var local_switch: int = 0
## Name shared between events and maps, for example "gate_open".
@export var global_switch: String = ""
## On = true. A switch that was never turned on counts as Off.
@export var value: bool = true


static func local(id: String, on: bool = true) -> KESwitchCondition:
	var condition := KESwitchCondition.new()
	condition.scope = Scope.LOCAL
	condition.local_switch = maxi(Names.SELF_SWITCH_IDS.find(id), 0)
	condition.value = on
	return condition


static func global(name: String, on: bool = true) -> KESwitchCondition:
	var condition := KESwitchCondition.new()
	condition.scope = Scope.GLOBAL
	condition.global_switch = name
	condition.value = on
	return condition


func is_met(ctx: Context) -> bool:
	var current: bool
	if scope == Scope.LOCAL:
		current = ctx.state.get_self_switch(ctx.event_key, Names.SELF_SWITCH_IDS[clampi(local_switch, 0, 3)])
	else:
		current = ctx.state.get_switch(global_switch)
	return current == value


func is_valid() -> bool:
	if scope == Scope.LOCAL:
		return local_switch >= 0 and local_switch < Names.SELF_SWITCH_IDS.size()
	return Names.is_valid_name(global_switch)


func get_summary() -> String:
	var id := (Text.t("Local") + " " + Names.SELF_SWITCH_IDS[clampi(local_switch, 0, 3)]) if scope == Scope.LOCAL \
		else (Text.t("Global") + ": " + (global_switch if not global_switch.is_empty() else "?"))
	return id + " = " + (Text.t("Ligado") if value else Text.t("Desligado"))


func _validate_property(property: Dictionary) -> void:
	super(property)
	if (property.name == "local_switch" and scope != Scope.LOCAL) or (property.name == "global_switch" and scope != Scope.GLOBAL):
		property.usage &= ~PROPERTY_USAGE_EDITOR
