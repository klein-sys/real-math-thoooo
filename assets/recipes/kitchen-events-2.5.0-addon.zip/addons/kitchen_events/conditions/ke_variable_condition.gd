@tool
class_name KEVariableCondition
extends "res://addons/kitchen_events/core/ke_condition.gd"
## Compares an integer variable with a number.

const Names = preload("res://addons/kitchen_events/core/ke_names.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Comparison { EQUAL, NOT_EQUAL, GREATER, GREATER_OR_EQUAL, LESS, LESS_OR_EQUAL }
const SYMBOLS := ["=", "≠", ">", "≥", "<", "≤"]

@export var variable_name: String = ""
@export var comparison: Comparison = Comparison.GREATER_OR_EQUAL
@export var value: int = 0


static func create(name: String, compare: Comparison, amount: int) -> KEVariableCondition:
	var condition := KEVariableCondition.new()
	condition.variable_name = name
	condition.comparison = compare
	condition.value = amount
	return condition


func is_met(ctx: Context) -> bool:
	var current: int = ctx.state.get_variable(variable_name)
	match comparison:
		Comparison.EQUAL:
			return current == value
		Comparison.NOT_EQUAL:
			return current != value
		Comparison.GREATER:
			return current > value
		Comparison.GREATER_OR_EQUAL:
			return current >= value
		Comparison.LESS:
			return current < value
	return current <= value


func is_valid() -> bool:
	return Names.is_valid_name(variable_name)


func get_summary() -> String:
	return Text.t("Variável") + " %s %s %d" % [variable_name if not variable_name.is_empty() else "?", SYMBOLS[comparison], value]
