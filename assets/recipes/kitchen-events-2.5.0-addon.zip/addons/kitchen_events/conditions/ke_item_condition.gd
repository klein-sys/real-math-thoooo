@tool
class_name KEItemCondition
extends "res://addons/kitchen_events/core/ke_condition.gd"
const Inventory = preload("res://addons/kitchen_events/runtime/ke_inventory.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")
@export var item_id: String = ""
@export_range(1, 1000000, 1) var quantity: int = 1
## Negates the minimum quantity check; unavailable inventory always fails closed.
@export var negate: bool = false

func is_valid() -> bool:
	return not item_id.strip_edges().is_empty() and quantity >= 1 and quantity <= 1000000

func is_met(ctx: Context) -> bool:
	if not is_valid():
		return false
	var count := Inventory.count_item(ctx, item_id)
	if count < 0:
		return false
	return count < quantity if negate else count >= quantity

func get_summary() -> String:
	return "%s: %s × %d" % [Text.t("Não possui item" if negate else "Possui item"), item_id, quantity]
