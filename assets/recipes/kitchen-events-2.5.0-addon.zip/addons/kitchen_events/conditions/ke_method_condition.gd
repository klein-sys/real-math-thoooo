@tool
class_name KEMethodCondition
extends "res://addons/kitchen_events/core/ke_condition.gd"
## Calls a method of your code and checks whether it returns true.
## Use it to tie pages to inventory, quests, abilities...

const Text = preload("res://addons/kitchen_events/ke_text.gd")

## Path from the event. Absolute paths such as /root/Inventory also work.
@export var node_path: NodePath
@export var method: String = ""
@export var arguments: Array = []
## On: the condition is met when the method returns false.
@export var negate: bool = false


func is_met(ctx: Context) -> bool:
	var node := ctx.find_node(node_path)
	if node == null or not node.has_method(method):
		return false
	return bool(node.callv(method, arguments)) != negate


func is_valid() -> bool:
	return not node_path.is_empty() and not method.is_empty()


func get_summary() -> String:
	return (Text.t("não") + " " if negate else "") + "%s.%s()" % [node_path, method]
