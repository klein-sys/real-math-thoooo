@tool
extends "res://addons/kitchen_events/core/ke_command.gd"
## Shared part of the commands that act on a character (face, move, animation).

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Body = preload("res://addons/kitchen_events/runtime/ke_body.gd")

enum Direction { RIGHT, LEFT, UP, DOWN, TOWARD_PLAYER, AWAY_FROM_PLAYER }
const DIRECTION_NAMES := ["à direita", "à esquerda", "para cima", "para baixo", "para o jogador", "para longe do jogador"]

## Who: the player, this event or another node.
@export var target: Context.Target = Context.Target.PLAYER:
	set(value):
		target = value
		notify_property_list_changed()
## Path from the event, used when the target is another node.
@export var node_path: NodePath


func target_label() -> String:
	match target:
		Context.Target.PLAYER:
			return Text.t("Jogador")
		Context.Target.THIS_EVENT:
			return Text.t("Este evento")
	return str(node_path) if not node_path.is_empty() else "?"


func direction_label(choice: int) -> String:
	return Text.t(DIRECTION_NAMES[clampi(choice, 0, DIRECTION_NAMES.size() - 1)])


func resolve_direction(choice: int, body: Node2D, ctx: Context) -> Vector2:
	match choice:
		Direction.RIGHT:
			return Vector2.RIGHT
		Direction.LEFT:
			return Vector2.LEFT
		Direction.UP:
			return Vector2.UP
		Direction.DOWN:
			return Vector2.DOWN
	var player := ctx.player
	if not is_instance_valid(player) or player == body:
		return Vector2.ZERO
	var offset := player.global_position - body.global_position
	var toward := Vector2(signf(offset.x), 0.0) if absf(offset.x) >= absf(offset.y) else Vector2(0.0, signf(offset.y))
	return toward if choice == Direction.TOWARD_PLAYER else -toward


func is_valid() -> bool:
	return target != Context.Target.NODE or not node_path.is_empty()


func get_category() -> String:
	return CATEGORY_CHARACTER


func _validate_property(property: Dictionary) -> void:
	super(property)
	if property.name == "node_path" and target != Context.Target.NODE:
		property.usage &= ~PROPERTY_USAGE_EDITOR
