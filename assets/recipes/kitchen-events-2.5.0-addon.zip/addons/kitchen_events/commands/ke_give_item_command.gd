@tool
class_name KEGiveItemCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
const Inventory = preload("res://addons/kitchen_events/runtime/ke_inventory.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")
@export var item_id: String = ""
@export_range(1, 1000000, 1) var quantity: int = 1

func is_valid() -> bool:
	return not item_id.strip_edges().is_empty() and quantity >= 1 and quantity <= 1000000

func execute(ctx: Context) -> void:
	if not is_valid() or not Inventory.change(ctx, item_id, quantity, false):
		ctx.abort(Text.t("Inventário indisponível ou alteração de item recusada") + ": " + item_id)

func get_command_name() -> String:
	return Text.t("Dar item")

func get_category() -> String:
	return CATEGORY_STATE

func get_summary() -> String:
	return "%s × %d" % [item_id, quantity]
