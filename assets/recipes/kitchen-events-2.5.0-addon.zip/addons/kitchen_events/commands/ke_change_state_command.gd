@tool
class_name KEChangeStateCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Changes local switches, global switches and variables, all at once.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")

@export var changes: Array[StateChange] = []


static func create(list: Array) -> KEChangeStateCommand:
	var command := KEChangeStateCommand.new()
	for change in list:
		command.changes.append(change)
	return command


func execute(ctx: Context) -> void:
	if not ctx.apply_changes(changes):
		push_warning(Text.t("Kitchen Events: alteração inválida: ") + get_summary())


func is_valid() -> bool:
	if changes.is_empty():
		return false
	for change in changes:
		if change == null or not change.is_valid():
			return false
	return true


func is_variable_change() -> bool:
	return not changes.is_empty() and changes[0] != null and not changes[0].is_switch()


func get_command_name() -> String:
	return Text.t("Variável") if is_variable_change() else Text.t("Switch")


func get_category() -> String:
	return CATEGORY_STATE


func get_summary() -> String:
	if changes.size() == 1 and changes[0] != null:
		var summary: String = changes[0].get_summary()
		var prefix := Text.t("Variável") + " "
		return summary.trim_prefix(prefix) if is_variable_change() else summary
	return Text.t("%d alterações") % changes.size()
