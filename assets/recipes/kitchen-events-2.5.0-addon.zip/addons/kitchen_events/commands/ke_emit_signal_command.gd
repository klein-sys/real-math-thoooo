@tool
class_name KEEmitSignalCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Emits the event's [code]command_signal(name, arguments)[/code] signal.
## Connect this signal in the scene to react to the event from code.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

@export var signal_name: String = ""
@export var arguments: Array = []


func execute(ctx: Context) -> void:
	if is_instance_valid(ctx.event):
		ctx.event.command_signal.emit(StringName(signal_name), arguments.duplicate())


func is_valid() -> bool:
	return not signal_name.is_empty()


func get_command_name() -> String:
	return Text.t("Emitir sinal")


func get_summary() -> String:
	return "\"%s\"" % signal_name
