@tool
class_name KEBalloonCommand
extends "res://addons/kitchen_events/commands/ke_actor_command.gd"
## Shows an emotion balloon above a character (!, ?, ♪, heart...).

enum Kind { EXCLAMATION, QUESTION, MUSIC, HEART, ANGER, SWEAT, SILENCE, IDEA, SLEEP }
const KIND_NAMES := ["Exclamação !", "Interrogação ?", "Música ♪", "Coração", "Raiva", "Gota de suor", "Reticências ...", "Ideia", "Sono zZ"]

@export var balloon: Kind = Kind.EXCLAMATION
@export_range(0.2, 10.0, 0.1, "suffix:s") var duration: float = 1.0
## Waits for the balloon to disappear before the next command.
@export var wait: bool = true


static func create(who: Context.Target, kind: Kind, wait_until_done: bool = true) -> KEBalloonCommand:
	var command := KEBalloonCommand.new()
	command.target = who
	command.balloon = kind
	command.wait = wait_until_done
	return command


func execute(ctx: Context) -> void:
	var body := ctx.find_target(target, node_path)
	if body == null:
		push_warning(Text.t("Kitchen Events: personagem não encontrado para o balão: ") + target_label())
		return
	var done: Signal = ctx.runtime.show_balloon(body, balloon, duration)
	if wait:
		await done


func get_command_name() -> String:
	return Text.t("Balão de emoção")


func get_category() -> String:
	return CATEGORY_CHARACTER


func get_summary() -> String:
	return "%s · %s" % [target_label(), Text.t(KIND_NAMES[clampi(balloon, 0, KIND_NAMES.size() - 1)])]
