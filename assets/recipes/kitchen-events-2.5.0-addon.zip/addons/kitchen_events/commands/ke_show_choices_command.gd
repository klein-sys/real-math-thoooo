@tool
class_name KEShowChoicesCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Shows options; each option runs its own command list.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const ChoiceBranch = preload("res://addons/kitchen_events/core/ke_choice_branch.gd")

@export var choices: Array[ChoiceBranch] = []
## Option chosen when Esc / B is pressed. -1 = Esc does not close the choices.
@export var cancel_choice: int = -1


static func create(options: PackedStringArray, cancel_index: int = -1) -> KEShowChoicesCommand:
	var command := KEShowChoicesCommand.new()
	for option in options:
		command.choices.append(ChoiceBranch.create(option))
	command.cancel_choice = cancel_index
	return command


func execute(ctx: Context) -> void:
	if ctx.parallel:
		push_warning(Text.t("Kitchen Events: falas e escolhas não rodam em processo paralelo; use Apertar botão, Ao tocar ou Automático."))
		return
	var box := ctx.get_dialogue_box()
	if box == null:
		ctx.abort(Text.t("sem caixa de fala"))
		return
	var options := PackedStringArray()
	for choice in choices:
		options.append(ctx.format_text(choice.text if choice != null else ""))
	var cancel := cancel_choice if cancel_choice >= 0 and cancel_choice < choices.size() else -1
	var index: int = await box.show_choices(options, cancel)
	if index < 0 or index >= choices.size() or choices[index] == null:
		return
	ctx.skip_conversation = false
	await ctx.interpreter.run_list(choices[index].commands, ctx)


func is_valid() -> bool:
	if choices.is_empty():
		return false
	for choice in choices:
		if choice == null or choice.text.strip_edges().is_empty():
			return false
	return true


func get_command_name() -> String:
	return Text.t("Escolhas")


func get_category() -> String:
	return CATEGORY_MESSAGE


func get_summary() -> String:
	var options: Array[String] = []
	for choice in choices:
		options.append(choice.text if choice != null else "?")
	return " / ".join(options)


func get_branches() -> Array:
	var result: Array = []
	for i in choices.size():
		if choices[i] != null:
			var label := Text.t("Quando") + " [%s]" % choices[i].text
			if i == cancel_choice:
				label += " (Esc)"
			result.append({"label": label, "commands": choices[i].commands})
	return result


func continues_conversation() -> bool:
	return true
