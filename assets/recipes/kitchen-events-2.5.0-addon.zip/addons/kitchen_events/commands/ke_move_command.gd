@tool
class_name KEMoveCommand
extends "res://addons/kitchen_events/commands/ke_actor_command.gd"
## Makes a character walk a distance in pixels.

@export var direction: Direction = Direction.RIGHT
## Distance in pixels.
@export_range(1.0, 4096.0, 1.0, "or_greater", "suffix:px") var distance: float = 32.0
@export_range(1.0, 1000.0, 1.0, "suffix:px/s") var speed: float = 64.0
## Off: the event continues while the character walks.
@export var wait: bool = true


static func create(who: Context.Target, choice: Direction, pixels: float, pixels_per_second: float = 64.0, wait_until_done: bool = true) -> KEMoveCommand:
	var command := KEMoveCommand.new()
	command.target = who
	command.direction = choice
	command.distance = pixels
	command.speed = pixels_per_second
	command.wait = wait_until_done
	return command


func execute(ctx: Context) -> void:
	var body := ctx.find_target(target, node_path)
	if body == null:
		push_warning(Text.t("Kitchen Events: personagem não encontrado para mover: ") + target_label())
		return
	var vector := resolve_direction(direction, body, ctx)
	if vector == Vector2.ZERO:
		return
	if wait:
		await Body.walk(body, vector, distance, speed, ctx.parallel)
	else:
		Body.walk(body, vector, distance, speed, ctx.parallel)


func get_command_name() -> String:
	return Text.t("Movimento")


func get_summary() -> String:
	var text := "%s · %s px %s" % [target_label(), String.num(distance, 1).trim_suffix(".0"), direction_label(direction)]
	return text if wait else text + " · " + Text.t("sem esperar")
