@tool
class_name KEEndEventCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Ends the event here. Counts as completed.

const Text = preload("res://addons/kitchen_events/ke_text.gd")


func execute(ctx: Context) -> void:
	ctx.stop()


func get_command_name() -> String:
	return Text.t("Encerrar evento")


func get_category() -> String:
	return CATEGORY_FLOW


func get_summary() -> String:
	return Text.t("os comandos seguintes não rodam")
