@tool
class_name KEWaitCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Waits a few seconds.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

@export_range(0.0, 600.0, 0.05, "or_greater", "suffix:s") var seconds: float = 0.5


static func create(duration: float) -> KEWaitCommand:
	var command := KEWaitCommand.new()
	command.seconds = duration
	return command


func execute(ctx: Context) -> void:
	await ctx.wait(seconds)


func get_command_name() -> String:
	return Text.t("Esperar")


func get_category() -> String:
	return CATEGORY_FLOW


func get_summary() -> String:
	return "%s s" % String.num(seconds, 2)
