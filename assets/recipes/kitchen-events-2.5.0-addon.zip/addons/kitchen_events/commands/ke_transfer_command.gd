@tool
class_name KETransferCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Ends the event and takes the player to another scene (or another point of this one).

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Facing { KEEP, RIGHT, LEFT, UP, DOWN }

## Destination scene. Empty = stay in this scene.
@export_file("*.tscn", "*.scn") var scene: String = ""
## Name of a node in the scene (for example a Marker2D) where the player appears.
@export var spawn_point: String = ""
## Map-local position selected visually. False preserves legacy marker behavior.
@export var use_position: bool = false
@export var arrival_position: Vector2 = Vector2.ZERO
@export var facing: Facing = Facing.KEEP
@export_range(0.0, 3.0, 0.05, "suffix:s") var fade_time: float = 0.3


func execute(ctx: Context) -> void:
	ctx.transfer_request = {
		"scene": scene,
		"spawn": spawn_point,
		"position": arrival_position if use_position else null,
		"facing": [Vector2.ZERO, Vector2.RIGHT, Vector2.LEFT, Vector2.UP, Vector2.DOWN][facing],
		"fade": fade_time,
	}
	ctx.stop()


func is_valid() -> bool:
	return use_position or not scene.is_empty() or not spawn_point.is_empty()


func get_command_name() -> String:
	return Text.t("Transferir jogador")


func get_category() -> String:
	return CATEGORY_SCENE


func get_summary() -> String:
	var where := scene.get_file() if not scene.is_empty() else Text.t("esta cena")
	if use_position:
		where += " → (%.0f, %.0f)" % [arrival_position.x, arrival_position.y]
	elif not spawn_point.is_empty():
		where += " → " + spawn_point
	return where
