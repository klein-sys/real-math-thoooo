@tool
class_name KEPlayAnimationCommand
extends "res://addons/kitchen_events/commands/ke_actor_command.gd"
## Plays an animation on a character, AnimatedSprite2D or AnimationPlayer.

@export var animation: String = ""
@export_range(0.1, 4.0, 0.1) var speed: float = 1.0
## Waits for the animation to finish (one cycle, if it loops).
@export var wait: bool = true


func execute(ctx: Context) -> void:
	var node: Node = ctx.find_target(target, node_path) if target != Context.Target.NODE else ctx.find_node(node_path)
	var duration := Body.play_animation(node, StringName(animation), speed)
	if duration < 0.0:
		push_warning(Text.t("Kitchen Events: animação não encontrada: %s em %s") % [animation, target_label()])
		return
	if wait:
		await ctx.wait(duration)


func is_valid() -> bool:
	return super() and not animation.is_empty()


func get_command_name() -> String:
	return Text.t("Animação")


func get_summary() -> String:
	return "%s · %s" % [target_label(), animation]
