@tool
class_name KECallCommonEventCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Runs a common event here, as if its commands were part of this list.
## Local switches inside it belong to the event that called it.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")

const MAX_DEPTH := 32

## Identifier of the common event (does not change when the name changes).
@export var common_id: String = ""
## Name of the common event, kept for display in the list.
@export var common_name: String = ""


static func create(id: String, name: String = "") -> KECallCommonEventCommand:
	var command := KECallCommonEventCommand.new()
	command.common_id = id
	command.common_name = name
	return command


func execute(ctx: Context) -> void:
	var library := Settings.common_events()
	var common: Resource = library.find(common_id) if library != null else null
	if common == null and library != null and not common_name.is_empty():
		common = library.find_by_name(common_name)
	if common == null:
		push_warning(Text.t("Kitchen Events: evento comum não encontrado: ") + (common_name if not common_name.is_empty() else common_id))
		return
	var depth: int = ctx.data.get("_common_depth", 0)
	if depth >= MAX_DEPTH:
		push_warning(Text.t("Kitchen Events: eventos comuns chamando uns aos outros sem parar: ") + common.page_name)
		return
	ctx.data["_common_depth"] = depth + 1
	await ctx.interpreter.run_list(common.commands, ctx)
	ctx.data["_common_depth"] = depth


func is_valid() -> bool:
	return not common_id.is_empty() or not common_name.is_empty()


func get_command_name() -> String:
	return Text.t("Evento comum")


func get_category() -> String:
	return CATEGORY_FLOW


func get_summary() -> String:
	var library := Settings.common_events()
	var common: Resource = library.find(common_id) if library != null else null
	return common.page_name if common != null and not common.page_name.is_empty() else (common_name if not common_name.is_empty() else "?")
