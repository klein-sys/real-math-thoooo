@tool
class_name KEScreenCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Screen effects: fade out, fade in, flash, shake, tint and clear tint.
## Fade out and tint stay after the event, until a Fade in / Clear tint.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Effect { FADE_OUT, FADE_IN, FLASH, SHAKE, TINT, CLEAR_TINT }
const EFFECT_NAMES := ["Escurecer", "Clarear", "Piscar", "Tremer", "Tingir", "Remover tinta"]

@export var effect: Effect = Effect.FADE_OUT:
	set(value):
		effect = value
		notify_property_list_changed()
## Fade out: color of the covered screen. Flash: color of the flash. Tint: tint color.
@export var color: Color = Color.BLACK
## Shake strength in pixels.
@export_range(1.0, 64.0, 1.0, "suffix:px") var strength: float = 6.0
@export_range(0.0, 10.0, 0.05, "suffix:s") var duration: float = 0.6
@export var wait: bool = true


static func create(kind: Effect, seconds: float = 0.6, tone: Color = Color.BLACK) -> KEScreenCommand:
	var command := KEScreenCommand.new()
	command.effect = kind
	command.duration = seconds
	command.color = tone
	return command


func execute(ctx: Context) -> void:
	var screen: Node = ctx.runtime.screen
	var done: Variant = null
	match effect:
		Effect.FADE_OUT:
			done = screen.fade_out(color, duration)
		Effect.FADE_IN:
			done = screen.fade_in(duration)
		Effect.FLASH:
			done = screen.flash(color, duration)
		Effect.SHAKE:
			done = screen.shake(strength, duration)
		Effect.TINT:
			done = screen.tint(color, duration)
		Effect.CLEAR_TINT:
			done = screen.tint(Color.WHITE, duration)
	if wait and done is Signal:
		await done


func get_command_name() -> String:
	return Text.t("Tela")


func get_category() -> String:
	return CATEGORY_SCREEN


func get_summary() -> String:
	var name := Text.t(EFFECT_NAMES[effect])
	match effect:
		Effect.SHAKE:
			return "%s · %d px · %s s" % [name, int(strength), String.num(duration, 2)]
		Effect.FADE_OUT, Effect.FLASH, Effect.TINT:
			return "%s · #%s · %s s" % [name, color.to_html(false), String.num(duration, 2)]
	return "%s · %s s" % [name, String.num(duration, 2)]


func _validate_property(property: Dictionary) -> void:
	super(property)
	if (property.name == "color" and effect in [Effect.FADE_IN, Effect.SHAKE, Effect.CLEAR_TINT]) \
			or (property.name == "strength" and effect != Effect.SHAKE):
		property.usage &= ~PROPERTY_USAGE_EDITOR
