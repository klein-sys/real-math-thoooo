@tool
class_name KEMusicCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Plays music (looping), stops it, or returns to the previous music.
## While the event music plays, the game music can stay paused.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Action { PLAY, STOP, RESTORE }
const ACTION_NAMES := ["Tocar", "Parar", "Voltar à anterior"]

@export var action: Action = Action.PLAY:
	set(value):
		action = value
		notify_property_list_changed()
@export var music: AudioStream
@export_range(-40.0, 12.0, 0.5, "suffix:dB") var volume_db: float = 0.0
@export_range(0.0, 10.0, 0.1, "suffix:s") var fade_time: float = 1.0
## Pauses whatever music the game is playing and resumes it later.
@export var pause_game_music: bool = true
@export var wait: bool = false


func execute(ctx: Context) -> void:
	var player: Node = ctx.runtime.music
	var done: Variant
	match action:
		Action.PLAY:
			done = player.play(music, volume_db, fade_time, pause_game_music)
		Action.STOP:
			done = player.stop(fade_time)
		_:
			done = player.restore_previous(fade_time)
	if wait and done is Signal:
		await done


func is_valid() -> bool:
	return action != Action.PLAY or music != null


func get_command_name() -> String:
	return Text.t("Música")


func get_category() -> String:
	return CATEGORY_AUDIO


func get_summary() -> String:
	var name := Text.t(ACTION_NAMES[action])
	if action == Action.PLAY:
		name += " " + (music.resource_path.get_file() if music != null else "?")
	return "%s · fade %s s" % [name, String.num(fade_time, 1)]


func _validate_property(property: Dictionary) -> void:
	super(property)
	if property.name in ["music", "volume_db", "pause_game_music"] and action != Action.PLAY:
		property.usage &= ~PROPERTY_USAGE_EDITOR
