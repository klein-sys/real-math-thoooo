@tool
class_name KEShowImageCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Shows an image on screen (illustration, letter, map...) or erases an image.
## Each number (1 to 10) is a slot: showing on the same number replaces the image.
## The image stays on screen after the event, until it is erased.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Action { SHOW, ERASE }

@export var action: Action = Action.SHOW:
	set(value):
		action = value
		notify_property_list_changed()
@export_range(1, 10, 1) var slot: int = 1
@export var image: Texture2D
## Screen center, or a position in screen pixels.
@export var centered: bool = true:
	set(value):
		centered = value
		notify_property_list_changed()
@export var position: Vector2 = Vector2.ZERO
@export_range(0.1, 10.0, 0.05) var scale: float = 1.0
@export_range(0.0, 5.0, 0.05, "suffix:s") var fade_time: float = 0.4
@export var wait: bool = true


func execute(ctx: Context) -> void:
	var screen: Node = ctx.runtime.screen
	var done: Variant
	if action == Action.SHOW:
		done = screen.show_image(slot, image, Vector2(-1, -1) if centered else position, scale, fade_time)
	else:
		done = screen.erase_image(slot, fade_time)
	if wait and done is Signal:
		await done


func is_valid() -> bool:
	return action == Action.ERASE or image != null


func get_command_name() -> String:
	return Text.t("Imagem")


func get_category() -> String:
	return CATEGORY_SCREEN


func get_summary() -> String:
	if action == Action.ERASE:
		return Text.t("Apagar a imagem %d") % slot
	var file := image.resource_path.get_file() if image != null else "?"
	return Text.t("Mostrar %s no lugar %d") % [file, slot]


func _validate_property(property: Dictionary) -> void:
	super(property)
	var hidden := false
	match property.name:
		"image", "centered", "scale":
			hidden = action == Action.ERASE
		"position":
			hidden = action == Action.ERASE or centered
	if hidden:
		property.usage &= ~PROPERTY_USAGE_EDITOR
