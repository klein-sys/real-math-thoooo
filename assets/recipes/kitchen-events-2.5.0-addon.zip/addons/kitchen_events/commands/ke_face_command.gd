@tool
class_name KEFaceCommand
extends "res://addons/kitchen_events/commands/ke_actor_command.gd"
## Turns a character.

@export var direction: Direction = Direction.TOWARD_PLAYER


static func create(who: Context.Target, choice: Direction) -> KEFaceCommand:
	var command := KEFaceCommand.new()
	command.target = who
	command.direction = choice
	return command


func execute(ctx: Context) -> void:
	var body := ctx.find_target(target, node_path)
	if body == null:
		push_warning(Text.t("Kitchen Events: personagem não encontrado para virar: ") + target_label())
		return
	Body.face(body, resolve_direction(direction, body, ctx))


func get_command_name() -> String:
	return Text.t("Virar")


func get_summary() -> String:
	return "%s %s" % [target_label(), direction_label(direction)]
