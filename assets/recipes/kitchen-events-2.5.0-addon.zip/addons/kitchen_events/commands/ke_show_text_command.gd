@tool
class_name KEShowTextCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Shows a line of dialogue. Consecutive lines form a conversation: Esc / B skips the
## whole conversation and the event continues with the next commands. Use {v:name} to
## show a variable and BBCode such as [b]bold[/b] or [color=gold]color[/color].

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const DialogueLine = preload("res://addons/kitchen_events/core/ke_dialogue_line.gd")
const ShowChoices = preload("res://addons/kitchen_events/commands/ke_show_choices_command.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")

@export var speaker: String = ""
@export_multiline var text: String = ""
## Empty = automatic from the character (the project's character list).
@export var portrait: Texture2D


static func create(speaker_name: String, message: String, face: Texture2D = null) -> KEShowTextCommand:
	var command := KEShowTextCommand.new()
	command.speaker = speaker_name
	command.text = message
	command.portrait = face
	return command


func execute(ctx: Context) -> void:
	if ctx.parallel:
		push_warning(Text.t("Kitchen Events: falas e escolhas não rodam em processo paralelo; use Apertar botão, Ao tocar ou Automático."))
		return
	if ctx.skip_conversation:
		return
	var box := ctx.get_dialogue_box()
	if box == null:
		ctx.abort(Text.t("sem caixa de fala"))
		return
	var line := DialogueLine.create(ctx.format_text(speaker), ctx.format_text(text), portrait)
	var cast := Settings.cast()
	var member: Resource = cast.find(speaker) if cast != null and not speaker.is_empty() else null
	if member != null:
		if line.portrait == null:
			line.portrait = member.portrait
		line.name_color = member.name_color
	var next: Resource = ctx.interpreter.peek_next()
	var keep_open := next is KEShowTextCommand or next is ShowChoices
	var skipped: bool = await box.show_message(line, keep_open)
	if skipped:
		ctx.skipped_dialogue = true
		ctx.skip_conversation = true


func is_valid() -> bool:
	return not text.strip_edges().is_empty()


func get_command_name() -> String:
	return Text.t("Fala")


func get_category() -> String:
	return CATEGORY_MESSAGE


func get_summary() -> String:
	var who := speaker + ": " if not speaker.is_empty() else ""
	return who + text.strip_edges().replace("\n", " ")


func continues_conversation() -> bool:
	return true
