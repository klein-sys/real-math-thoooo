@tool
class_name KECameraCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Moves or zooms the camera. The camera goes back to normal when the event ends.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Mode { FOCUS, ZOOM, RESTORE }

@export var mode: Mode = Mode.FOCUS:
	set(value):
		mode = value
		notify_property_list_changed()
## Where the camera looks (Focus).
@export var target: Context.Target = Context.Target.THIS_EVENT:
	set(value):
		target = value
		notify_property_list_changed()
## Path from the event, used when the target is another node.
@export var node_path: NodePath
@export var offset: Vector2 = Vector2.ZERO
## Keeps following the target after arriving.
@export var follow: bool = true
## Multiplies the normal zoom: 2 = closer, 0.5 = farther (Zoom).
@export_range(0.25, 4.0, 0.05) var zoom: float = 1.5
@export_range(0.0, 10.0, 0.05, "suffix:s") var duration: float = 0.6
@export var wait: bool = true


func execute(ctx: Context) -> void:
	var camera: Node = ctx.runtime.camera
	var done: Variant = null
	match mode:
		Mode.FOCUS:
			var node := ctx.find_target(target, node_path)
			if node == null:
				push_warning(Text.t("Kitchen Events: alvo da câmera não encontrado."))
				return
			done = camera.focus(node, offset, duration, follow)
		Mode.ZOOM:
			done = camera.zoom_to(zoom, duration)
		Mode.RESTORE:
			done = camera.restore(duration)
	if wait and done is Signal:
		await done


func is_valid() -> bool:
	return mode != Mode.FOCUS or target != Context.Target.NODE or not node_path.is_empty()


func get_command_name() -> String:
	return Text.t("Câmera")


func get_category() -> String:
	return CATEGORY_CAMERA


func get_summary() -> String:
	match mode:
		Mode.FOCUS:
			var who: String = [Text.t("Jogador"), Text.t("Este evento"), str(node_path)][target]
			return Text.t("Focar") + " " + who
		Mode.ZOOM:
			return Text.t("Zoom") + " %s×" % String.num(zoom, 2)
	return Text.t("Restaurar")


func _validate_property(property: Dictionary) -> void:
	super(property)
	var hidden := false
	match property.name:
		"target", "offset", "follow":
			hidden = mode != Mode.FOCUS
		"node_path":
			hidden = mode != Mode.FOCUS or target != Context.Target.NODE
		"zoom":
			hidden = mode != Mode.ZOOM
	if hidden:
		property.usage &= ~PROPERTY_USAGE_EDITOR
