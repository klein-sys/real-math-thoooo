@tool
class_name KEPlaySoundCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Plays a sound once.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

@export var sound: AudioStream
@export_range(-40.0, 12.0, 0.5, "suffix:dB") var volume_db: float = 0.0
@export_range(0.25, 4.0, 0.05) var pitch: float = 1.0
@export var bus: String = "Master"
@export var wait: bool = false


func execute(ctx: Context) -> void:
	var player: AudioStreamPlayer = ctx.runtime.play_sound(sound, volume_db, pitch, bus)
	if wait and player != null:
		await player.finished


func is_valid() -> bool:
	return sound != null


func get_command_name() -> String:
	return Text.t("Som")


func get_category() -> String:
	return CATEGORY_AUDIO


func get_summary() -> String:
	return sound.resource_path.get_file() if sound != null else Text.t("sem arquivo")
