@tool
class_name KEConditionalCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Runs one list when the conditions are met and another when they are not.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Condition = preload("res://addons/kitchen_events/core/ke_condition.gd")
const CommandBase = preload("res://addons/kitchen_events/core/ke_command.gd")

@export var conditions: Array[Condition] = []
## On: all of them must be met. Off: any one is enough.
@export var require_all: bool = true
@export var has_else: bool = true
## Edited in the command list.
@export var then_commands: Array[CommandBase] = []
## Edited in the command list.
@export var else_commands: Array[CommandBase] = []


func execute(ctx: Context) -> void:
	if evaluate(ctx):
		await ctx.interpreter.run_list(then_commands, ctx)
	elif has_else:
		await ctx.interpreter.run_list(else_commands, ctx)


func evaluate(ctx: Context) -> bool:
	for condition in conditions:
		var met: bool = condition != null and condition.is_valid() and condition.is_met(ctx)
		if require_all and not met:
			return false
		if not require_all and met:
			return true
	return require_all


func is_valid() -> bool:
	if conditions.is_empty():
		return false
	for condition in conditions:
		if condition == null or not condition.is_valid():
			return false
	return true


func get_command_name() -> String:
	return Text.t("Se")


func get_category() -> String:
	return CATEGORY_FLOW


func get_summary() -> String:
	var parts: Array[String] = []
	for condition in conditions:
		parts.append(condition.get_summary() if condition != null else "?")
	if parts.is_empty():
		return "?"
	return (Text.t(" e ") if require_all else Text.t(" ou ")).join(parts)


func get_branches() -> Array:
	var result: Array = [{"label": Text.t("Então"), "commands": then_commands}]
	if has_else:
		result.append({"label": Text.t("Senão"), "commands": else_commands})
	return result


func _validate_property(property: Dictionary) -> void:
	super(property)
	if property.name in ["then_commands", "else_commands"]:
		property.usage = PROPERTY_USAGE_STORAGE
