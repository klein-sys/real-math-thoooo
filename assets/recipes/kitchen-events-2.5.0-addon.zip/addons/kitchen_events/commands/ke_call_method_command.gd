@tool
class_name KECallMethodCommand
extends "res://addons/kitchen_events/core/ke_command.gd"
## Calls a method on any node: the bridge between events and your code.
## If the method uses await (or returns a Signal), the event can wait for it.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

## Path from the event. Absolute paths such as /root/Inventory also work.
@export var node_path: NodePath
@export var method: String = ""
@export var arguments: Array = []
## Waits for the method to finish when it uses await.
@export var wait: bool = true


func execute(ctx: Context) -> void:
	var node := ctx.find_node(node_path)
	if node == null or not node.has_method(method):
		push_warning(Text.t("Kitchen Events: método não encontrado: %s.%s()") % [node_path, method])
		return
	if wait:
		await node.callv(method, arguments)
	else:
		node.callv(method, arguments)


func is_valid() -> bool:
	return not node_path.is_empty() and not method.is_empty()


func get_command_name() -> String:
	return Text.t("Chamar método")


func get_summary() -> String:
	var args: Array[String] = []
	for argument in arguments:
		args.append(var_to_str(argument))
	return "%s.%s(%s)" % [node_path, method, ", ".join(args)]
