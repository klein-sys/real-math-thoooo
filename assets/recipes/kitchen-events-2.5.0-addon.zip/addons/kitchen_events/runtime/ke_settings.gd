@tool
class_name KESettings
extends RefCounted
## Plugin settings (Project > Project Settings > Kitchen Events).

const Text = preload("res://addons/kitchen_events/ke_text.gd")

const PREFIX := "kitchen_events/"
const AUTOLOAD_NAME := "KitchenEvents"

## key: [default, type, hint, hint_string]
const DEFINITIONS := {
	"inventory/provider_path": ["", TYPE_STRING, PROPERTY_HINT_NONE, ""],
	"input/interact_action": ["interact", TYPE_STRING, PROPERTY_HINT_NONE, ""],
	"input/cancel_action": ["ui_cancel", TYPE_STRING, PROPERTY_HINT_NONE, ""],
	"player/group": ["player", TYPE_STRING, PROPERTY_HINT_NONE, ""],
	"runtime/pause_mode": [0, TYPE_INT, PROPERTY_HINT_ENUM, "Pausar o jogo inteiro,Parar só o jogador e o evento"],
	"ui/language": [0, TYPE_INT, PROPERTY_HINT_ENUM, "Automático,Português,English"],
	"ui/dialogue_scene": ["", TYPE_STRING, PROPERTY_HINT_FILE, "*.tscn,*.scn"],
	"ui/text_speed": [40.0, TYPE_FLOAT, PROPERTY_HINT_RANGE, "0,500,1,suffix:letras/s"],
	"ui/prompt_font_size": [14, TYPE_INT, PROPERTY_HINT_RANGE, "6,48,1,suffix:px"],
	"editor/cast": ["res://kitchen_events_personagens.tres", TYPE_STRING, PROPERTY_HINT_FILE, "*.tres"],
	"editor/common_events": ["res://kitchen_events_eventos_comuns.tres", TYPE_STRING, PROPERTY_HINT_FILE, "*.tres"],
}


static func get_value(key: String) -> Variant:
	return ProjectSettings.get_setting(PREFIX + key, DEFINITIONS[key][0])


## The interact action, or "ui_accept" when the configured one does not exist.
static func interact_action() -> StringName:
	return _existing_action(String(get_value("input/interact_action")), &"ui_accept")


static func cancel_action() -> StringName:
	return _existing_action(String(get_value("input/cancel_action")), &"ui_cancel")


## 0 = pauses the whole game during events; 1 = stops only the player and the event
## (for games that show the pause menu whenever the game is paused).
static func pauses_whole_game() -> bool:
	return int(get_value("runtime/pause_mode")) == 0


static func player_group() -> StringName:
	return StringName(String(get_value("player/group")))


## The KitchenEvents autoload, or null when the plugin is not enabled.
static func runtime() -> Node:
	var tree := Engine.get_main_loop() as SceneTree
	return tree.root.get_node_or_null(AUTOLOAD_NAME) if tree != null else null


## The character list (name, portrait, color), or null.
static func cast() -> Resource:
	var path := String(get_value("editor/cast"))
	return load(path) if not path.is_empty() and ResourceLoader.exists(path) else null


## The common event library, or null.
static func common_events() -> Resource:
	var path := String(get_value("editor/common_events"))
	return load(path) if not path.is_empty() and ResourceLoader.exists(path) else null


## Adds the settings to Project Settings (called by the plugin).
static func register_all() -> void:
	for key in DEFINITIONS:
		var definition: Array = DEFINITIONS[key]
		var path: String = PREFIX + key
		if not ProjectSettings.has_setting(path):
			ProjectSettings.set_setting(path, definition[0])
		ProjectSettings.set_initial_value(path, definition[0])
		ProjectSettings.add_property_info({
			"name": path, "type": definition[1], "hint": definition[2], "hint_string": Text.t(definition[3]),
		})
		ProjectSettings.set_as_basic(path, true)


static func _existing_action(name: String, fallback: StringName) -> StringName:
	return StringName(name) if not name.is_empty() and InputMap.has_action(name) else fallback


## Short text for the keys of an action: first key and first button, for example "E / Y".
static func action_hint(action: StringName) -> String:
	if not InputMap.has_action(action):
		return ""
	var key := ""
	var button := ""
	for input in InputMap.action_get_events(action):
		if input is InputEventKey and key.is_empty():
			var keycode: Key = input.keycode if input.keycode != KEY_NONE else input.physical_keycode
			key = OS.get_keycode_string(keycode)
		elif input is InputEventJoypadButton and button.is_empty() and input.button_index <= JOY_BUTTON_Y:
			button = ["A", "B", "X", "Y"][input.button_index]
	var parts: Array[String] = []
	for text in [key, button]:
		if not text.is_empty():
			parts.append(text)
	return " / ".join(parts)
