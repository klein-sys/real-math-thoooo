@tool
@icon("res://addons/kitchen_events/icons/event.svg")
class_name KEEvent
extends Area2D
## Map event: pages with conditions, a trigger and a command list.
##
## Add the node, adjust the sensor (CollisionShape2D) and click
## "Edit event…" in the Inspector. The player is the body in the "player" group
## (configurable). Add a Sprite2D or AnimatedSprite2D child as the object's
## image; each page can keep, replace or hide that image.

signal started
signal finished(completed: bool)
## Emitted by the "Emit signal" command.
signal command_signal(name: StringName, arguments: Array)

const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")
const Context = preload("res://addons/kitchen_events/core/ke_context.gd")
const Names = preload("res://addons/kitchen_events/core/ke_names.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const Prompt = preload("res://addons/kitchen_events/ui/ke_prompt.gd")
const Body = preload("res://addons/kitchen_events/runtime/ke_body.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

## Fixed identifier, created automatically. Local switches and run counters use it.
@export var event_id: String = ""
@export var pages: Array[Page] = []:
	set(value):
		pages = value
		if is_node_ready():
			refresh()
		update_configuration_warnings()

@export_group("Aviso")
## Extra offset of the "E · Read" prompt. It already appears just above the sensor.
@export var prompt_offset: Vector2 = Vector2.ZERO
@export var show_prompt: bool = true

@export_group("Detecção")
## Ignores the player when there is a wall between them and the event.
@export var check_line_of_sight: bool = false
@export_flags_2d_physics var line_of_sight_mask: int = 1

var _page_index := -1
var _eval_context: Context
var _autorun_revision := -1
var _running := false
var _scene_key_cache := ""
var _prompt: Control
var _image: CanvasItem
var _image_original: Dictionary = {}
var _replacement: Sprite2D
## Bodies that already triggered "On touch" and must leave the sensor before triggering again.
var touch_blocked: Dictionary = {}
## Auto move (used by the runtime).
var auto_walking := false
var auto_next_move := 0
var patrol_direction := 1.0


func _init() -> void:
	collision_layer = 0
	collision_mask = 0xFFFFFFFF
	monitorable = false


func _enter_tree() -> void:
	if Engine.is_editor_hint():
		if event_id.is_empty():
			event_id = Names.new_id("ev")
		_ensure_sensor.call_deferred()


func _ready() -> void:
	if Engine.is_editor_hint():
		return
	add_to_group(&"ke_events")
	_image = _find_image()
	if _image != null:
		_image_original = {"visible": _image.visible, "texture": _image.get("texture")}
	_prompt = Prompt.new()
	add_child(_prompt, false, INTERNAL_MODE_BACK)
	refresh()
	var runtime := Settings.runtime()
	if runtime == null:
		push_error(Text.t("Kitchen Events: o autoload KitchenEvents não existe. Ative o plugin em Projeto > Configurações do Projeto > Plugins."))
		return
	runtime.state_changed.connect(refresh)


func _notification(what: int) -> void:
	if what == NOTIFICATION_EDITOR_PRE_SAVE:
		_ensure_unique_id()


## Key of this event in the game state: scene + event id.
func get_event_key() -> String:
	var scene := _scene_key()
	return scene + "::" + event_id if not scene.is_empty() else event_id


func get_active_page() -> Page:
	return pages[_page_index] if _page_index >= 0 and _page_index < pages.size() else null


func get_active_page_index() -> int:
	return _page_index


## Key of a page in the run counters.
func get_page_key(index: int) -> String:
	var page: Page = pages[index] if index >= 0 and index < pages.size() else null
	var id := page.page_id if page != null and not page.page_id.is_empty() else str(index)
	return get_event_key() + "::page::" + id


func get_runnable_page(trigger: int) -> Page:
	var page := get_active_page()
	if page == null or page.trigger != trigger or not page.has_runnable_commands() or _running:
		return null
	var runtime := Settings.runtime()
	if page.max_executions > 0 and runtime != null and runtime.state.get_count(get_page_key(_page_index)) >= page.max_executions:
		return null
	return page


func can_start(trigger: int) -> bool:
	return get_runnable_page(trigger) != null


## Starts the event from code, as if the player had triggered it.
func start(trigger: int = Page.Trigger.ACTION) -> bool:
	var runtime := Settings.runtime()
	return runtime != null and runtime.start_event(self, runtime.get_player(), trigger)


func is_running() -> bool:
	return _running


func get_interaction_label() -> String:
	var page := get_active_page()
	return page.interaction_label if page != null else ""


func get_interaction_action() -> StringName:
	var page := get_active_page()
	if page != null and not page.interaction_action.is_empty() and InputMap.has_action(page.interaction_action):
		return StringName(page.interaction_action)
	return Settings.interact_action()


## Is the player inside the sensor (and in sight, if that option is on)?
func has_body(body: Node2D) -> bool:
	if not is_instance_valid(body) or not monitoring or not overlaps_body(body):
		return false
	if not check_line_of_sight:
		return true
	var query := PhysicsRayQueryParameters2D.create(body.global_position, get_center(), line_of_sight_mask)
	query.exclude = [body.get_rid()] if body is CollisionObject2D else []
	return get_world_2d().direct_space_state.intersect_ray(query).is_empty()


## Center of the event area: the sensor (even if it was moved) or the node itself.
func get_center() -> Vector2:
	var sensor := _sensor()
	return sensor.global_position if sensor != null else global_position


func _sensor() -> Node2D:
	for child in get_children():
		if child is CollisionShape2D or child is CollisionPolygon2D:
			return child
	return null


## Point just above the sensor, in event coordinates.
func _prompt_anchor() -> Vector2:
	var sensor := _sensor()
	if sensor == null:
		return Vector2(0, -24) + prompt_offset
	var top := -16.0
	if sensor is CollisionShape2D and sensor.shape != null:
		top = sensor.shape.get_rect().position.y * sensor.scale.y
	elif sensor is CollisionPolygon2D and not sensor.polygon.is_empty():
		top = INF
		for point in sensor.polygon:
			top = minf(top, point.y)
	return sensor.position + Vector2(0, top - 4.0) + prompt_offset


func set_prompt_visible(visible_now: bool) -> void:
	if _prompt == null:
		return
	if visible_now and show_prompt:
		var verb := get_interaction_label()
		var hint := Settings.action_hint(get_interaction_action())
		_prompt.show_text("%s · %s" % [hint, verb if not verb.is_empty() else Text.t("Interagir")] if not hint.is_empty() else verb, _prompt_anchor())
	else:
		_prompt.hide()


## Picks the active page again (called when the state changes).
func refresh() -> void:
	if not is_inside_tree() or Engine.is_editor_hint():
		return
	var previous := _page_index
	_page_index = _select_page()
	if previous != _page_index:
		_autorun_revision = -1
		_apply_image()


## Called by the runtime.
func _on_run_started() -> void:
	_running = true
	set_prompt_visible(false)
	started.emit()


## Called by the runtime.
func _on_run_finished(completed: bool) -> void:
	_running = false
	var runtime := Settings.runtime()
	if runtime != null:
		_autorun_revision = runtime.state.revision
	refresh()
	finished.emit(completed)


## Called by the runtime to decide Autorun.
func wants_autorun(revision: int) -> bool:
	var page := get_active_page()
	return page != null and page.trigger == Page.Trigger.AUTORUN and not _running and _autorun_revision != revision and can_start(Page.Trigger.AUTORUN)


func mark_autorun(revision: int) -> void:
	_autorun_revision = revision


func _select_page() -> int:
	var runtime := Settings.runtime()
	if runtime == null:
		return -1
	if _eval_context == null:
		_eval_context = Context.new()
		_eval_context.runtime = runtime
		_eval_context.state = runtime.state
		_eval_context.event = self
	_eval_context.event_key = get_event_key()
	for index in range(pages.size() - 1, -1, -1):
		var page: Page = pages[index]
		if page != null and page.matches(_eval_context):
			return index
	return -1


func _scene_key() -> String:
	if not _scene_key_cache.is_empty():
		return _scene_key_cache
	if not is_inside_tree():
		return ""
	var scene := get_tree().current_scene
	if scene == null or (scene != self and not scene.is_ancestor_of(self)) or scene.scene_file_path.is_empty():
		return ""
	var uid := ResourceLoader.get_resource_uid(scene.scene_file_path)
	_scene_key_cache = ResourceUID.id_to_text(uid) if uid != ResourceUID.INVALID_ID else scene.scene_file_path
	return _scene_key_cache


func _find_image() -> CanvasItem:
	for child in get_children():
		if child is Sprite2D or child is AnimatedSprite2D:
			return child
	return null


func _apply_image() -> void:
	var page := get_active_page()
	var mode: int = page.image_mode if page != null else Page.ImageMode.KEEP
	if page == null and not pages.is_empty():
		mode = Page.ImageMode.HIDE
	if _replacement != null:
		_replacement.visible = false
	if _image != null:
		_image.visible = _image_original.get("visible", true)
		if _image is Sprite2D:
			_image.texture = _image_original.get("texture")
	match mode:
		Page.ImageMode.HIDE:
			if _image != null:
				_image.visible = false
		Page.ImageMode.REPLACE:
			if _image is Sprite2D:
				_image.texture = page.image
				_image.visible = page.image != null
			else:
				if _image != null:
					_image.visible = false
				if _replacement == null:
					_replacement = Sprite2D.new()
					add_child(_replacement, false, INTERNAL_MODE_FRONT)
				_replacement.texture = page.image
				_replacement.visible = page.image != null


func _ensure_sensor() -> void:
	if not is_inside_tree():
		return
	for child in get_children():
		if child is CollisionShape2D or child is CollisionPolygon2D:
			return
	var root := get_tree().edited_scene_root
	if root == null or (root != self and not root.is_ancestor_of(self)) or (root != self and not scene_file_path.is_empty()):
		return
	var sensor := CollisionShape2D.new()
	sensor.name = "Sensor"
	var shape := RectangleShape2D.new()
	shape.size = Vector2(32, 32)
	sensor.shape = shape
	add_child(sensor)
	sensor.owner = root
	update_configuration_warnings()


func _validate_property(property: Dictionary) -> void:
	if property.usage & PROPERTY_USAGE_GROUP:
		property.name = Text.t(property.name)
	if property.name == "event_id":
		property.usage |= PROPERTY_USAGE_READ_ONLY


func _get_configuration_warnings() -> PackedStringArray:
	var warnings := PackedStringArray()
	if pages.is_empty():
		warnings.append(Text.t("Este evento não tem páginas. Use \"Editar evento…\" no Inspector."))
	var has_shape := false
	for child in get_children():
		has_shape = has_shape or child is CollisionShape2D or child is CollisionPolygon2D
	if not has_shape:
		warnings.append(Text.t("Adicione um CollisionShape2D: é a área em que o jogador pode interagir."))
	if not ProjectSettings.has_setting("autoload/" + Settings.AUTOLOAD_NAME):
		warnings.append(Text.t("O autoload KitchenEvents não existe. Ative o plugin Kitchen Events."))
	if Engine.is_editor_hint() and is_inside_tree() and get_tree().edited_scene_root != null:
		var root := get_tree().edited_scene_root
		var group := StringName(String(ProjectSettings.get_setting("kitchen_events/player/group", "player")))
		var in_group := false
		var nodes: Array[Node] = [root]
		while not nodes.is_empty() and not in_group:
			var node: Node = nodes.pop_back()
			in_group = node.is_in_group(group)
			nodes.append_array(node.get_children())
		if not in_group and Body.find_player(root) == null:
			warnings.append(Text.t("Não encontrei o jogador nesta cena. Coloque o nó do jogador no grupo \"%s\" (aba Nó > Grupos).") % group)
	return warnings


## Gives the event its own id when it was duplicated or inherited from another scene.
func _ensure_unique_id() -> void:
	if event_id.is_empty():
		event_id = Names.new_id("ev")
		return
	var root := get_tree().edited_scene_root if is_inside_tree() else null
	if root == null:
		return
	if root != self and not scene_file_path.is_empty() and _inherited_id() == event_id:
		event_id = Names.new_id("ev")
		return
	# Depth first, in tree order: the lower copy gets the new id.
	var nodes: Array[Node] = [root]
	while not nodes.is_empty():
		var node: Node = nodes.pop_back()
		if node == self:
			return
		if node is KEEvent and node.event_id == event_id:
			event_id = Names.new_id("ev")
			return
		var children := node.get_children()
		children.reverse()
		nodes.append_array(children)


func _inherited_id() -> String:
	var packed := load(scene_file_path) as PackedScene
	if packed == null:
		return ""
	var state := packed.get_state()
	for i in state.get_node_property_count(0):
		if state.get_node_property_name(0, i) == &"event_id":
			return String(state.get_node_property_value(0, i))
	return ""
