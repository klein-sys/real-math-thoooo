extends Node
## Moves and zooms the view during events using a temporary Camera2D, so the
## game camera itself is never changed. [method restore] returns to it.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

var _original: Camera2D
var _camera: Camera2D
var _follow: Node2D
var _follow_offset := Vector2.ZERO
var _tween: Tween


func is_overriding() -> bool:
	return is_instance_valid(_camera)


## Moves the view to [param target]. Returns a Signal to wait for, or null.
func focus(target: Node2D, offset: Vector2, duration: float, follow: bool) -> Variant:
	if not _ensure_camera():
		return null
	_follow = null
	var destination := target.global_position + offset
	var done: Variant = _animate("global_position", destination, duration)
	if follow:
		_follow_offset = offset
		if done is Signal:
			done.connect(func() -> void: _follow = target if is_instance_valid(target) else null, CONNECT_ONE_SHOT)
		else:
			_follow = target
	return done


## Multiplies the normal zoom by [param factor]. Returns a Signal or null.
func zoom_to(factor: float, duration: float) -> Variant:
	if not _ensure_camera():
		return null
	return _animate("zoom", _original.zoom * maxf(factor, 0.01), duration)


## Goes back to the game camera. Returns a Signal or null.
func restore(duration: float) -> Variant:
	if not is_overriding():
		return null
	_follow = null
	if not is_instance_valid(_original) or not _original.is_inside_tree() or duration <= 0.0:
		_release()
		return null
	_kill_tween()
	_tween = create_tween().set_parallel().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_tween.tween_property(_camera, "global_position", _original.get_screen_center_position(), duration)
	_tween.tween_property(_camera, "zoom", _original.zoom, duration)
	_tween.finished.connect(_release, CONNECT_ONE_SHOT)
	return _tween.finished


func _process(_delta: float) -> void:
	if is_instance_valid(_follow) and is_instance_valid(_camera) and (_tween == null or not _tween.is_running()):
		_camera.global_position = _follow.global_position + _follow_offset


func _ensure_camera() -> bool:
	if is_overriding():
		return true
	var viewport := get_viewport()
	_original = viewport.get_camera_2d() if viewport != null else null
	var scene := get_tree().current_scene
	if _original == null or scene == null:
		push_warning(Text.t("Kitchen Events: não há Camera2D ativa para mover."))
		return false
	_camera = Camera2D.new()
	_camera.name = "KitchenEventsCamera"
	_camera.zoom = _original.zoom
	# Keeps the level limits so the empty space outside the map is not shown.
	for side in ["limit_left", "limit_top", "limit_right", "limit_bottom"]:
		_camera.set(side, _original.get(side))
	_camera.process_callback = Camera2D.CAMERA2D_PROCESS_IDLE
	# Events pause the world; the event camera keeps moving.
	_camera.process_mode = Node.PROCESS_MODE_ALWAYS
	scene.add_child(_camera)
	_camera.global_position = _original.get_screen_center_position()
	_camera.make_current()
	return true


func _animate(property: String, value: Variant, duration: float) -> Variant:
	_kill_tween()
	if duration <= 0.0:
		_camera.set(property, value)
		return null
	_tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_tween.tween_property(_camera, property, value, duration)
	return _tween.finished


func _kill_tween() -> void:
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = null


func _release() -> void:
	_kill_tween()
	if is_instance_valid(_original) and _original.is_inside_tree() and _original.enabled:
		_original.make_current()
	if is_instance_valid(_camera):
		_camera.queue_free()
	_camera = null
	_original = null
	_follow = null
