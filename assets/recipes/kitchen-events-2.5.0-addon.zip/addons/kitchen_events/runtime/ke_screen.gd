extends Node
## Event screen effects: fade out/in, flash, tint, shake and on-screen
## images. Works with the game paused.
##
## Layers (CanvasLayer): images 85, fade 90, flash 95. The dialogue box
## is on 100, so lines can be shown over a black screen ("Years later...").
## The tint uses a CanvasModulate in the scene: it paints only the world, not the UI.

const IMAGE_SLOTS := 10

var _fade_layer: CanvasLayer
var _fade_rect: ColorRect
var _flash_layer: CanvasLayer
var _flash_rect: ColorRect
var _image_layer: CanvasLayer
var _images: Dictionary = {}
var _tint: CanvasModulate
var _tint_created := false
var _tint_original := Color.WHITE
var _shake_camera: Camera2D
var _shake_offset := Vector2.ZERO
var _shake_strength := 0.0
var _shake_time := 0.0
var _shake_total := 0.0


signal _shake_finished


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_fade_layer = _layer("Escurecer", 90)
	_fade_rect = _full_rect(_fade_layer)
	_flash_layer = _layer("Piscar", 95)
	_flash_rect = _full_rect(_flash_layer)
	_image_layer = _layer("Imagens", 85)


func _layer(layer_name: String, index: int) -> CanvasLayer:
	var layer := CanvasLayer.new()
	layer.name = layer_name
	layer.layer = index
	add_child(layer)
	return layer


func _full_rect(parent: Node) -> ColorRect:
	var rect := ColorRect.new()
	rect.color = Color(0, 0, 0, 0)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(rect)
	return rect


## Returns a tween's signal, or null when the duration is zero.
func _tween_property(target: Object, property: String, value: Variant, duration: float) -> Variant:
	if duration <= 0.0:
		target.set(property, value)
		return null
	var tween := create_tween()
	tween.tween_property(target, property, value, duration)
	return tween.finished


## Covers the screen with [param color] (fade out).
func fade_out(color: Color, duration: float) -> Variant:
	_fade_rect.color = Color(color, _fade_rect.color.a)
	return _tween_property(_fade_rect, "color:a", 1.0, duration)


## Removes the cover (fade in).
func fade_in(duration: float) -> Variant:
	return _tween_property(_fade_rect, "color:a", 0.0, duration)


func is_faded() -> bool:
	return _fade_rect.color.a > 0.01


## Flashes the screen with [param color] and returns to normal.
func flash(color: Color, duration: float) -> Variant:
	_flash_rect.color = color
	return _tween_property(_flash_rect, "color:a", 0.0, maxf(duration, 0.05))


## Tints the world (e.g. blue for night). White = no tint.
func tint(color: Color, duration: float) -> Variant:
	var scene := get_tree().current_scene
	if scene == null:
		return null
	if not is_instance_valid(_tint) or not scene.is_ancestor_of(_tint):
		_tint = null
		for child in scene.get_children():
			if child is CanvasModulate:
				_tint = child
				_tint_created = false
				_tint_original = child.color
		if _tint == null:
			_tint = CanvasModulate.new()
			_tint.name = "KitchenEventsTinta"
			_tint.color = Color.WHITE
			_tint.process_mode = Node.PROCESS_MODE_ALWAYS
			scene.add_child(_tint)
			_tint_created = true
			_tint_original = Color.WHITE
	var target := color if color != Color.WHITE else _tint_original
	return _tween_property(_tint, "color", target, duration)


## Shakes the camera for [param duration] seconds.
func shake(strength: float, duration: float) -> Variant:
	var camera := get_viewport().get_camera_2d()
	if camera == null or duration <= 0.0 or strength <= 0.0:
		return null
	_stop_shake()
	_shake_camera = camera
	_shake_offset = camera.offset
	_shake_strength = strength
	_shake_time = duration
	_shake_total = duration
	return _shake_finished


func _process(delta: float) -> void:
	if not is_instance_valid(_shake_camera) or _shake_time <= 0.0:
		return
	_shake_time -= delta
	if _shake_time <= 0.0:
		_stop_shake()
		_shake_finished.emit()
		return
	var power := _shake_strength * (_shake_time / _shake_total)
	_shake_camera.offset = _shake_offset + Vector2(randf_range(-power, power), randf_range(-power, power))


func _stop_shake() -> void:
	if is_instance_valid(_shake_camera):
		_shake_camera.offset = _shake_offset
	_shake_camera = null
	_shake_time = 0.0


## Shows an image on screen. [param slot] 1-10; the same slot replaces the image.
## [param center] in screen pixels; Vector2(-1, -1) = center.
func show_image(slot: int, texture: Texture2D, center: Vector2, scale: float, duration: float) -> Variant:
	erase_image(slot, 0.0)
	var image := TextureRect.new()
	image.name = "Imagem%d" % slot
	image.texture = texture
	image.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	image.mouse_filter = Control.MOUSE_FILTER_IGNORE
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_SCALE
	image.size = texture.get_size() * scale if texture != null else Vector2.ZERO
	var screen := get_viewport().get_visible_rect().size
	var at := screen * 0.5 if center.x < 0.0 else center
	image.position = at - image.size * 0.5
	image.z_index = slot
	image.modulate.a = 0.0 if duration > 0.0 else 1.0
	_image_layer.add_child(image)
	_images[slot] = image
	return _tween_property(image, "modulate:a", 1.0, duration)


func erase_image(slot: int, duration: float) -> Variant:
	var image: Variant = _images.get(slot)
	_images.erase(slot)
	if not is_instance_valid(image):
		return null
	if duration <= 0.0:
		image.queue_free()
		return null
	var tween := create_tween()
	tween.tween_property(image, "modulate:a", 0.0, duration)
	tween.tween_callback(image.queue_free)
	return tween.finished


func get_image(slot: int) -> TextureRect:
	var image: Variant = _images.get(slot)
	return image if is_instance_valid(image) else null


## Puts everything back to normal (new game).
func reset() -> void:
	_fade_rect.color.a = 0.0
	_flash_rect.color.a = 0.0
	for slot in _images.keys():
		erase_image(slot, 0.0)
	_stop_shake()
	if is_instance_valid(_tint):
		if _tint_created:
			_tint.queue_free()
		else:
			_tint.color = _tint_original
	_tint = null
