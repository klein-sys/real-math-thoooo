@tool
class_name KEBody
extends RefCounted
## Lets any body (the player or an event) take part in cutscenes.
##
## If the character has the methods below, they are used. All of them are optional:
## [codeblock]
## func can_interact() -> bool          # may it press the button now?
## func can_travel() -> bool            # may an "On touch" event take it away?
## func begin_cutscene(controller: Node) -> bool
## func end_cutscene(controller: Node) -> void
## func cutscene_face(left: bool) -> void
## func cutscene_motion(direction: float, speed: float, delta: float) -> void  # called every frame
## func cutscene_stop() -> void
## func cutscene_play_animation(animation: StringName, speed: float) -> float
## [/codeblock]
## Without them, the plugin freezes the character, moves the body with physics and picks
## animations by name (walk/run/andar, idle/parado).

const META := &"_kitchen_events_cutscene"
## Set on the body to interrupt a walk in progress.
const CANCEL_WALK := &"_kitchen_events_cancel_walk"
const VISUAL_TYPES := ["AnimatedSprite2D", "Sprite2D", "AnimationPlayer", "AnimationTree", "Camera2D", "AudioStreamPlayer2D", "AudioStreamPlayer"]


## The character that looks like the player, when nobody is in the "player" group.
## From strongest to weakest: has can_interact() or begin_cutscene(); is named
## Player / Jogador / Hero / Herói (node name or class_name); has the active
## Camera2D as a child.
static func find_player(root: Node) -> Node2D:
	if root == null:
		return null
	var best: Node2D = null
	var best_score := 0
	var names := RegEx.create_from_string("(?i)player|jogador|hero|her[oó]i|protagonist")
	var nodes: Array[Node] = [root]
	while not nodes.is_empty():
		var node: Node = nodes.pop_front()
		nodes.append_array(node.get_children())
		if not node is CharacterBody2D:
			continue
		var score := 0
		if node.has_method("can_interact") or node.has_method("begin_cutscene"):
			score = 3
		else:
			var script: Script = node.get_script()
			var class_text := String(script.get_global_name()) if script != null else ""
			if names.search(String(node.name)) != null or names.search(class_text) != null:
				score = 2
			else:
				for child in node.get_children():
					if child is Camera2D and child.enabled:
						score = 1
		if score > best_score:
			best = node
			best_score = score
	return best


static func can_interact(body: Node) -> bool:
	if not is_instance_valid(body) or not body.is_inside_tree():
		return false
	return body.can_interact() if body.has_method("can_interact") else true


static func can_travel(body: Node) -> bool:
	if not is_instance_valid(body) or not body.is_inside_tree():
		return false
	if body.has_method("can_travel"):
		return body.can_travel()
	return can_interact(body)


## Takes control of the body. Returns false if the character refuses.
static func begin(body: Node, controller: Node) -> bool:
	if not is_instance_valid(body):
		return false
	if body.has_meta(META):
		return true
	if body.has_method("begin_cutscene") and not body.begin_cutscene(controller):
		return false
	var saved := {
		"physics": body.is_physics_processing(), "process": body.is_processing(),
		"input": body.is_processing_input(), "unhandled": body.is_processing_unhandled_input(),
		"modes": {},
	}
	if not body.has_method("begin_cutscene"):
		# No contract: the character script stops (movement and keys).
		body.set_physics_process(false)
		body.set_process_input(false)
		body.set_process_unhandled_input(false)
		if body is CharacterBody2D:
			body.velocity = Vector2.ZERO
	# With the world paused, the character visuals keep animating.
	for node in _visual_nodes(body):
		saved["modes"][node] = node.process_mode
		node.process_mode = Node.PROCESS_MODE_ALWAYS
	body.set_meta(META, saved)
	return true


## Gives control back, also when the event was interrupted.
static func end(body: Node, controller: Node) -> void:
	if not is_instance_valid(body) or not body.has_meta(META):
		return
	var saved: Dictionary = body.get_meta(META)
	body.remove_meta(META)
	for node in saved["modes"]:
		if is_instance_valid(node):
			node.process_mode = saved["modes"][node]
	if body.has_method("end_cutscene"):
		body.end_cutscene(controller)
	else:
		body.set_physics_process(saved["physics"])
		body.set_process_input(saved["input"])
		body.set_process_unhandled_input(saved["unhandled"])
		if body is CharacterBody2D:
			body.velocity = Vector2.ZERO
		_play_named(body, ["idle", "parado", "stand"])


static func face(body: Node, direction: Vector2) -> void:
	if not is_instance_valid(body) or direction == Vector2.ZERO:
		return
	if absf(direction.x) >= absf(direction.y):
		if body.has_method("cutscene_face"):
			body.cutscene_face(direction.x < 0.0)
			return
		var sprite := _sprite(body)
		if sprite != null:
			sprite.set("flip_h", direction.x < 0.0)
	body.set_meta(&"_kitchen_events_facing", direction)


static func facing(body: Node) -> Vector2:
	if body.has_meta(&"_kitchen_events_facing"):
		return body.get_meta(&"_kitchen_events_facing")
	var sprite := _sprite(body)
	return Vector2.LEFT if sprite != null and sprite.get("flip_h") else Vector2.RIGHT


## Walks [param distance] pixels. Returns false when the way is blocked.
## [param respect_pause]: waits while the game is paused (parallel processes
## and auto move).
static func walk(body: Node2D, direction: Vector2, distance: float, speed: float, respect_pause: bool = false) -> bool:
	if not is_instance_valid(body) or direction == Vector2.ZERO or distance <= 0.0:
		return true
	direction = direction.normalized()
	face(body, direction)
	var tree := body.get_tree()
	var delta := 1.0 / maxf(Engine.physics_ticks_per_second, 1)
	var walked := 0.0
	var stuck := 0.0
	var horizontal := absf(direction.x) > absf(direction.y)
	var contract := horizontal and body.has_method("cutscene_motion")
	if not contract:
		_play_named(body, ["walk", "run", "andar", "correr", "caminhar"])
	body.remove_meta(CANCEL_WALK)
	while walked < distance - 0.01:
		if not is_instance_valid(body) or not body.is_inside_tree():
			return false
		if body.has_meta(CANCEL_WALK):
			body.remove_meta(CANCEL_WALK)
			stop(body)
			return false
		if respect_pause and tree.paused:
			await tree.physics_frame
			continue
		var step := minf(speed * delta, distance - walked)
		var before := body.global_position
		if contract:
			body.cutscene_motion(signf(direction.x), step / delta, delta)
		elif body is CharacterBody2D:
			var character := body as CharacterBody2D
			if horizontal and character.motion_mode == CharacterBody2D.MOTION_MODE_GROUNDED:
				# Platformer: walks on the ground and stays under gravity.
				var fall := 0.0 if character.is_on_floor() else character.velocity.y
				character.velocity = Vector2(direction.x * step / delta, fall + _gravity() * delta)
			else:
				character.velocity = direction * (step / delta)
			character.move_and_slide()
		else:
			body.global_position += direction * step
		var moved := (body.global_position - before).dot(direction)
		walked += maxf(moved, 0.0)
		stuck = stuck + delta if moved < step * 0.2 else 0.0
		if stuck > 0.2:
			stop(body)
			return false
		await tree.physics_frame
	stop(body)
	return true


static func stop(body: Node) -> void:
	if not is_instance_valid(body):
		return
	if body.has_method("cutscene_stop"):
		body.cutscene_stop()
		return
	if body is CharacterBody2D:
		body.velocity = Vector2.ZERO
	_play_named(body, ["idle", "parado", "stand"])


## Plays an animation and returns its length in seconds, or -1 if it does not exist.
static func play_animation(node: Node, animation: StringName, speed: float = 1.0) -> float:
	if not is_instance_valid(node):
		return -1.0
	if node.has_method("cutscene_play_animation"):
		return node.cutscene_play_animation(animation, speed)
	for child in [node] + node.get_children():
		if child is AnimationPlayer and child.has_animation(animation):
			child.play(animation, -1, speed)
			return child.get_animation(animation).length / maxf(speed, 0.01)
	var sprite := (node if node is AnimatedSprite2D else _sprite(node)) as AnimatedSprite2D
	if sprite == null or sprite.sprite_frames == null or not sprite.sprite_frames.has_animation(animation):
		return -1.0
	sprite.play(animation, speed)
	var frames := sprite.sprite_frames
	var total := 0.0
	for i in frames.get_frame_count(animation):
		total += frames.get_frame_duration(animation, i)
	var fps := frames.get_animation_speed(animation)
	return total / (fps * speed) if fps > 0.0 else 0.0


## Point just above the character's head, in the body's local coordinates.
static func top_point(body: Node2D) -> Vector2:
	var sprite := _sprite(body) as Node2D
	if sprite != null and sprite.visible:
		var rect := _sprite_rect(sprite)
		if rect.has_area():
			var top_of_sprite := Vector2(rect.get_center().x, rect.position.y)
			return body.global_transform.affine_inverse() * (sprite.global_transform * top_of_sprite)
	if body.has_method("get_center"):
		var center: Vector2 = body.get_center()
		return body.to_local(center) + Vector2(0, -20)
	return Vector2(0, -24)


static func _sprite_rect(sprite: Node2D) -> Rect2:
	if sprite is Sprite2D:
		return sprite.get_rect()
	var animated := sprite as AnimatedSprite2D
	if animated == null or animated.sprite_frames == null or not animated.sprite_frames.has_animation(animated.animation):
		return Rect2()
	if animated.sprite_frames.get_frame_count(animated.animation) == 0:
		return Rect2()
	var texture := animated.sprite_frames.get_frame_texture(animated.animation, animated.frame)
	var frame_size := texture.get_size() if texture != null else Vector2(16, 16)
	var origin := -frame_size * 0.5 if animated.centered else Vector2.ZERO
	return Rect2(origin + animated.offset, frame_size)


static func teleport(body: Node2D, point: Vector2, direction: Vector2 = Vector2.ZERO) -> void:
	if not is_instance_valid(body):
		return
	body.global_position = point
	if body is CharacterBody2D:
		body.velocity = Vector2.ZERO
	face(body, direction)


static func _sprite(body: Node) -> CanvasItem:
	if body is AnimatedSprite2D or body is Sprite2D:
		return body
	for child in body.get_children():
		if child is AnimatedSprite2D or child is Sprite2D:
			return child
	return null


static func _play_named(body: Node, keywords: Array) -> void:
	var sprite := _sprite(body) as AnimatedSprite2D
	if sprite == null or sprite.sprite_frames == null:
		return
	var names := sprite.sprite_frames.get_animation_names()
	for keyword in keywords:
		for name in names:
			if keyword in String(name).to_lower():
				if sprite.animation != name or not sprite.is_playing():
					sprite.play(name)
				return


static func _visual_nodes(body: Node) -> Array[Node]:
	var result: Array[Node] = []
	for child in body.get_children():
		if child.get_class() in VISUAL_TYPES:
			result.append(child)
	return result


static func _gravity() -> float:
	return float(ProjectSettings.get_setting("physics/2d/default_gravity", 980.0))
