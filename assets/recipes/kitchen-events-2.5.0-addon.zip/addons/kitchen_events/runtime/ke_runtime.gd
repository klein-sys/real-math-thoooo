extends Node
## The KitchenEvents autoload: runs the events and keeps the game state.
##
## Use from game code:
## [codeblock]
## KitchenEvents.set_switch("bridge_fixed", true)
## KitchenEvents.get_variable("gold")
## var data := KitchenEvents.save_data()   # store it in your save file
## KitchenEvents.load_data(data)
## KitchenEvents.reset()                   # new game
## [/codeblock]

signal state_changed
signal event_started(event: Node)
signal event_finished(event: Node, completed: bool)
signal transfer_finished

const State = preload("res://addons/kitchen_events/core/ke_state.gd")
const Context = preload("res://addons/kitchen_events/core/ke_context.gd")
const Interpreter = preload("res://addons/kitchen_events/core/ke_interpreter.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const Body = preload("res://addons/kitchen_events/runtime/ke_body.gd")
const CameraDirector = preload("res://addons/kitchen_events/runtime/ke_camera_director.gd")
const DialogueBox = preload("res://addons/kitchen_events/ui/ke_dialogue_box.gd")
const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")
const Screen = preload("res://addons/kitchen_events/runtime/ke_screen.gd")
const Music = preload("res://addons/kitchen_events/runtime/ke_music.gd")
const Balloon = preload("res://addons/kitchen_events/ui/ke_balloon.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

## Switches, local switches, variables and counters.
var state := State.new()
## Camera helper, used by the Camera command.
var camera: Node
## Screen effects (fade, flash, tint, shake, images).
var screen: Node
## Event music.
var music: Node

var _run: Dictionary = {}
var _dialogue_box: Node
var _fade: CanvasLayer
var _fade_rect: ColorRect
var _transfer: Dictionary = {}
var _prompted: Node
var _owns_pause := false
var _player_ref: WeakRef = weakref(null)
var _player_scene_ref: WeakRef = weakref(null)
var _next_player_search := 0
## After an event, the button must be released before starting another.
var _wait_release := false
var _parallel: Dictionary = {}
var _cooldown_until := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_physics_priority = 100
	state.changed.connect(state_changed.emit)
	camera = CameraDirector.new()
	camera.name = "Camera"
	add_child(camera)
	screen = Screen.new()
	screen.name = "Tela"
	add_child(screen)
	music = Music.new()
	music.name = "Musica"
	add_child(music)


## True while an event runs or the player is being transferred.
func is_busy() -> bool:
	return not _run.is_empty() or not _transfer.is_empty()


## The running event, or null.
func get_running_event() -> Node:
	return _run.get("event")


## The player: the first node of the configured group (default "player"). If nobody
## is in the group, the character that looks like the player (see KEBody.find_player).
func get_player() -> Node2D:
	if not is_inside_tree():
		return null
	var in_group := get_tree().get_first_node_in_group(Settings.player_group()) as Node2D
	if in_group != null:
		return in_group
	var scene := get_tree().current_scene
	var lost: bool = not is_instance_valid(_player_ref.get_ref()) and Time.get_ticks_msec() > _next_player_search
	if scene != _player_scene_ref.get_ref() or lost:
		_player_scene_ref = weakref(scene)
		_player_ref = weakref(_find_player(scene))
		_next_player_search = Time.get_ticks_msec() + 500
	var cached: Variant = _player_ref.get_ref()
	return cached as Node2D if is_instance_valid(cached) and cached.is_inside_tree() else null


func _find_player(root: Node) -> Node2D:
	return Body.find_player(root)


func _physics_process(_delta: float) -> void:
	var player := get_player()
	if not get_tree().paused:
		_update_background(player)
	var target: Node = null
	if not is_busy() and not get_tree().paused and player != null:
		target = _update_events(player)
	if target != _prompted:
		if is_instance_valid(_prompted):
			_prompted.set_prompt_visible(false)
		_prompted = target
	if is_instance_valid(_prompted):
		_prompted.set_prompt_visible(true)
		# Also reads the button from the keyboard state: works even when a
		# game script consumes the input event before the plugin.
		var action: StringName = _prompted.get_interaction_action()
		if _wait_release and not Input.is_action_pressed(action):
			_wait_release = false
		if _can_take_button() and Input.is_action_just_pressed(action):
			start_event(_prompted, player, Page.Trigger.ACTION)


## Parallel processes and auto move: they run in the background, outside normal
## events, and stop while the game is paused.
func _update_background(player: Node2D) -> void:
	for event in get_tree().get_nodes_in_group(&"ke_events"):
		if event.is_queued_for_deletion():
			continue
		var id: int = event.get_instance_id()
		if not _parallel.has(id) and event.can_start(Page.Trigger.PARALLEL):
			_start_parallel(event, player)
		var page: Resource = event.get_active_page()
		if page != null and page.auto_move != Page.AutoMove.NONE and not event.auto_walking \
				and not event.has_meta(Body.META) and Time.get_ticks_msec() >= event.auto_next_move:
			_auto_step(event, page)


func _start_parallel(event: Node, player: Node2D) -> void:
	var page: Resource = event.get_runnable_page(Page.Trigger.PARALLEL)
	if page == null:
		return
	var ctx := Context.new()
	ctx.runtime = self
	ctx.state = state
	ctx.event = event
	ctx.player = player
	ctx.parallel = true
	ctx.event_key = event.get_event_key()
	var interpreter := Interpreter.new()
	var id: int = event.get_instance_id()
	_parallel[id] = {"context": ctx, "page": page, "count_key": event.get_page_key(event.get_active_page_index())}
	interpreter.finished.connect(_on_parallel_finished.bind(id, event), CONNECT_ONE_SHOT)
	interpreter.run(page.commands, ctx)


func _on_parallel_finished(completed: bool, id: int, event: Variant) -> void:
	var run: Dictionary = _parallel.get(id, {})
	_parallel.erase(id)
	if run.is_empty() or not completed:
		return
	var changes: Array = []
	for change in run["page"].finish_changes:
		if change != null and change.is_valid():
			changes.append(change.to_change())
	changes.append({"type": "count", "id": run["count_key"], "value": 1})
	state.apply(changes, run["context"].event_key)


## How many parallel processes are running now.
func parallel_count() -> int:
	return _parallel.size()


func _auto_step(event: Node, page: Resource) -> void:
	var direction := Vector2.ZERO
	if page.auto_move == Page.AutoMove.PATROL:
		direction = Vector2(event.patrol_direction, 0.0)
		event.patrol_direction = -event.patrol_direction
	else:
		var options: Array[Vector2] = [Vector2.RIGHT, Vector2.LEFT]
		if page.auto_move_vertical:
			options.append_array([Vector2.UP, Vector2.DOWN])
		direction = options.pick_random()
	event.auto_walking = true
	await Body.walk(event, direction, page.auto_move_distance, page.auto_move_speed, true)
	if is_instance_valid(event):
		event.auto_walking = false
		event.auto_next_move = Time.get_ticks_msec() + int(page.auto_move_pause * 1000.0)


## Touch, Autorun and picking the nearest event for the button.
func _update_events(player: Node2D) -> Node:
	var best: Node = null
	var best_distance := INF
	var player_id := player.get_instance_id()
	for event in get_tree().get_nodes_in_group(&"ke_events"):
		if event.is_queued_for_deletion():
			continue
		var inside: bool = event.has_body(player)
		if not inside:
			event.touch_blocked.erase(player_id)
		if event.wants_autorun(state.revision):
			event.mark_autorun(state.revision)
			if start_event(event, player, Page.Trigger.AUTORUN):
				return null
		if not inside:
			continue
		if event.can_start(Page.Trigger.TOUCH) and not event.touch_blocked.has(player_id) and Body.can_travel(player):
			if start_event(event, player, Page.Trigger.TOUCH):
				# Triggers again only after the player leaves the sensor.
				event.touch_blocked[player_id] = true
				return null
		if event.can_start(Page.Trigger.ACTION) and Body.can_interact(player):
			var distance: float = player.global_position.distance_squared_to(event.get_center())
			if distance < best_distance:
				best = event
				best_distance = distance
	return best


## While an event prompt is on screen, the interact button belongs to the event: the
## plugin gets the press before the game scripts and marks it as handled.
func _input(input: InputEvent) -> void:
	if not _can_take_button() or input.is_echo():
		return
	if input.is_action_pressed(_prompted.get_interaction_action()):
		if start_event(_prompted, get_player(), Page.Trigger.ACTION):
			get_viewport().set_input_as_handled()


func _can_take_button() -> bool:
	if is_busy() or not is_instance_valid(_prompted) or get_tree().paused:
		return false
	return not _wait_release and Time.get_ticks_msec() >= _cooldown_until


## Starts [param event] if its active page has this trigger and nothing else is running.
func start_event(event: Node, player: Node2D, trigger: int) -> bool:
	if is_busy() or not is_instance_valid(event):
		return false
	var page: Resource = event.get_runnable_page(trigger)
	if page == null:
		return false
	var pause := Settings.pauses_whole_game() and not get_tree().paused
	if is_instance_valid(player) and not Body.begin(player, self):
		return false
	if event.auto_walking:
		# The NPC stops its auto move while talking.
		event.set_meta(Body.CANCEL_WALK, true)
	Body.begin(event, self)
	if pause:
		get_tree().paused = true
		_owns_pause = true
	if is_instance_valid(_prompted):
		_prompted.set_prompt_visible(false)
	_prompted = null
	var ctx := Context.new()
	ctx.runtime = self
	ctx.state = state
	ctx.event = event
	ctx.player = player
	ctx.event_key = event.get_event_key()
	var interpreter := Interpreter.new()
	_run = {
		"event": event, "player": player, "page": page, "context": ctx, "interpreter": interpreter,
		"count_key": event.get_page_key(event.get_active_page_index()),
	}
	_attach_dialogue_box()
	event._on_run_started()
	event_started.emit(event)
	interpreter.finished.connect(_on_run_finished, CONNECT_ONE_SHOT)
	interpreter.run(page.commands, ctx)
	return true


func _on_run_finished(completed: bool) -> void:
	var run := _run
	var ctx: Context = run["context"]
	var page: Resource = run["page"]
	var event: Variant = run["event"]
	if completed and (not ctx.skipped_dialogue or page.finish_on_skip):
		var changes: Array = []
		for change in page.finish_changes:
			if change != null and change.is_valid():
				changes.append(change.to_change())
		changes.append({"type": "count", "id": run["count_key"], "value": 1})
		if not state.apply(changes, ctx.event_key):
			push_warning(Text.t("Kitchen Events: alterações \"Ao terminar\" inválidas no evento ") + ctx.event_key)
	if is_instance_valid(_dialogue_box):
		_dialogue_box.close()
	_detach_dialogue_box()
	if camera.is_overriding():
		var restored: Variant = camera.restore(0.3)
		if restored is Signal:
			await restored
	var player: Variant = run["player"]
	if is_instance_valid(player):
		Body.end(player, self)
	if is_instance_valid(event):
		Body.end(event, self)
	if _owns_pause:
		_owns_pause = false
		get_tree().paused = false
	_wait_release = true
	_cooldown_until = Time.get_ticks_msec() + 250
	_run = {}
	var alive := is_instance_valid(event)
	if alive:
		event._on_run_finished(completed)
	event_finished.emit(event if alive else null, completed)
	if completed and not ctx.transfer_request.is_empty():
		var request := ctx.transfer_request
		transfer(request["scene"], request["spawn"], request["facing"], request["fade"], request.get("position"))


## Takes the player to [param spawn_point] (a node name) in [param scene_path].
## Empty scene = stay in the current scene.
func transfer(scene_path: String, spawn_point: String = "", facing: Vector2 = Vector2.ZERO, fade_time: float = 0.3, arrival_position: Variant = null) -> void:
	if not _transfer.is_empty():
		return
	_transfer = {"spawn": spawn_point, "facing": facing, "position": arrival_position}
	var departing: Variant = get_player()
	if is_instance_valid(departing):
		Body.begin(departing, self)
	if fade_time > 0.0:
		await _fade_to(1.0, fade_time)
	if not scene_path.is_empty():
		if get_tree().change_scene_to_file(scene_path) != OK:
			push_error(Text.t("Kitchen Events: não foi possível abrir a cena ") + scene_path)
			if is_instance_valid(departing):
				Body.end(departing, self)
			await _fade_to(0.0, fade_time)
			_transfer = {}
			return
		await get_tree().scene_changed
		await get_tree().physics_frame
	var arriving := get_player()
	if arriving != null:
		Body.begin(arriving, self)
	_place_player()
	# Whoever arrives on top of an "On touch" event must leave and enter again.
	await get_tree().physics_frame
	await get_tree().physics_frame
	var player := get_player()
	if player != null:
		for event in get_tree().get_nodes_in_group(&"ke_events"):
			if event.has_body(player):
				event.touch_blocked[player.get_instance_id()] = true
	if fade_time > 0.0:
		await _fade_to(0.0, fade_time)
	if is_instance_valid(arriving):
		Body.end(arriving, self)
	_transfer = {}
	transfer_finished.emit()


func _place_player() -> void:
	var player := get_player()
	var spawn_name: String = _transfer.get("spawn", "")
	if player == null:
		return
	var scene := get_tree().current_scene
	var point: Variant = _transfer.get("position")
	if point is Vector2:
		var global_point: Vector2 = scene.to_global(point) if scene is Node2D else point
		Body.teleport(player, global_point, _transfer.get("facing", Vector2.ZERO))
		player.reset_physics_interpolation()
		var camera_2d := get_viewport().get_camera_2d()
		if camera_2d != null:
			camera_2d.reset_smoothing()
		return
	if spawn_name.is_empty():
		Body.face(player, _transfer.get("facing", Vector2.ZERO))
		return
	var spawn := scene.find_child(spawn_name, true, false) as Node2D if scene != null else null
	if spawn == null:
		push_warning(Text.t("Kitchen Events: ponto de chegada não encontrado: ") + spawn_name)
		return
	Body.teleport(player, spawn.global_position, _transfer.get("facing", Vector2.ZERO))


func _fade_to(alpha: float, duration: float) -> void:
	if _fade == null:
		_fade = CanvasLayer.new()
		_fade.layer = 120
		_fade_rect = ColorRect.new()
		_fade_rect.color = Color.BLACK
		_fade_rect.modulate.a = 0.0
		_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
		_fade.add_child(_fade_rect)
		add_child(_fade)
	var tween := create_tween()
	tween.tween_property(_fade_rect, "modulate:a", alpha, duration)
	await tween.finished


## The dialogue box used by Text and Choices.
func get_dialogue_box() -> Node:
	if is_instance_valid(_dialogue_box):
		return _dialogue_box
	var path := String(Settings.get_value("ui/dialogue_scene"))
	if not path.is_empty() and ResourceLoader.exists(path):
		_dialogue_box = (load(path) as PackedScene).instantiate()
	else:
		_dialogue_box = DialogueBox.new()
	add_child(_dialogue_box)
	return _dialogue_box


## During an event, the dialogue box sits at the end of the current scene: this way it
## gets the keys (E, Esc...) before the level scripts, which often use the same
## keys to pause or interact.
func _attach_dialogue_box() -> void:
	var box := get_dialogue_box()
	var scene := get_tree().current_scene
	if scene != null and box.get_parent() != scene:
		box.reparent(scene, false)
	elif scene != null:
		scene.move_child(box, -1)


func _detach_dialogue_box() -> void:
	if is_instance_valid(_dialogue_box) and _dialogue_box.get_parent() != self:
		_dialogue_box.reparent(self, false)


## Replaces the dialogue box (for example with your own, or with a test one).
func set_dialogue_box(box: Node) -> void:
	if is_instance_valid(_dialogue_box) and _dialogue_box != box:
		_dialogue_box.queue_free()
	_dialogue_box = box
	if box != null and box.get_parent() == null:
		add_child(box)


## Plays a sound once and returns the player (or null).
func play_sound(stream: AudioStream, volume_db: float = 0.0, pitch: float = 1.0, bus: String = "Master") -> AudioStreamPlayer:
	if stream == null:
		return null
	var audio := AudioStreamPlayer.new()
	audio.stream = stream.duplicate()
	if audio.stream is AudioStreamMP3 or audio.stream is AudioStreamOggVorbis:
		audio.stream.loop = false
	elif audio.stream is AudioStreamWAV:
		audio.stream.loop_mode = AudioStreamWAV.LOOP_DISABLED
	audio.volume_db = volume_db
	audio.pitch_scale = pitch
	audio.bus = bus if AudioServer.get_bus_index(bus) >= 0 else &"Master"
	add_child(audio)
	audio.finished.connect(audio.queue_free)
	audio.play()
	return audio


# --- State shortcuts ----------------------------------------------------------

func get_switch(name: String) -> bool:
	return state.get_switch(name)


func set_switch(name: String, value: bool) -> bool:
	return state.set_switch(name, value)


func get_variable(name: String) -> int:
	return state.get_variable(name)


func set_variable(name: String, value: int) -> bool:
	return state.set_variable(name, value)


func get_self_switch(event_key: String, id: String) -> bool:
	return state.get_self_switch(event_key, id)


func set_self_switch(event_key: String, id: String, value: bool) -> bool:
	return state.set_self_switch(event_key, id, value)


## Data for your save file.
func save_data() -> Dictionary:
	return state.to_dict()


## Restores data from [method save_data]. Returns false (and keeps the current state)
## when the data is invalid.
func load_data(data: Variant) -> bool:
	return state.from_dict(data)


## Clears everything (new game): state, screen and event music.
func reset() -> void:
	state.clear()
	screen.reset()
	music.reset()


## Shows an emotion balloon above [param body]. Returns the signal emitted when it disappears.
func show_balloon(body: Node2D, kind: int, hold_seconds: float = 1.0) -> Signal:
	var balloon := Balloon.new()
	balloon.kind = kind
	balloon.hold_time = hold_seconds
	balloon.anchor = Body.top_point(body) + Vector2(0, -2)
	body.add_child(balloon, false, Node.INTERNAL_MODE_BACK)
	return balloon.finished


## Optional inventory integration; the inventory remains owned/saved by the game.
var _inventory_provider: WeakRef = weakref(null)

func set_inventory_provider(node: Node) -> void:
	_inventory_provider = weakref(node)
	notify_inventory_changed()

func get_inventory_provider() -> Node:
	var node: Variant = _inventory_provider.get_ref()
	if is_instance_valid(node):
		return node
	var path := String(Settings.get_value("inventory/provider_path"))
	if path.is_empty() or not NodePath(path).is_absolute():
		return null
	return get_node_or_null(NodePath(path))

## Call after external changes (pickups, purchases, loading inventory).
## Also wakes autorun pages waiting for items.
func notify_inventory_changed() -> void:
	state.revision += 1
	state.changed.emit()
