class_name KEInventory
extends RefCounted
## Synchronous adapter contract: get_item_count(id) -> int,
## add_item(id, quantity) -> bool, remove_item(id, quantity) -> bool.
## Mutations must be atomic: false means nothing was changed.
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")

static func provider(ctx: RefCounted) -> Node:
	if not is_instance_valid(ctx.runtime):
		return null
	return ctx.runtime.get_inventory_provider()

## -1 means unavailable/invalid, never an empty inventory.
static func count_item(ctx: RefCounted, item_id: String) -> int:
	var node := provider(ctx)
	if node == null or not node.has_method("get_item_count"):
		return -1
	var result: Variant = node.call("get_item_count", item_id)
	return result if result is int and result >= 0 else -1

static func change(ctx: RefCounted, item_id: String, quantity: int, remove: bool) -> bool:
	var node := provider(ctx)
	var method := "remove_item" if remove else "add_item"
	if node == null or not node.has_method(method):
		return false
	if remove:
		var current := count_item(ctx, item_id)
		if current < quantity:
			return false
	var result: Variant = node.call(method, item_id, quantity)
	if not result is bool or not result:
		return false
	ctx.runtime.notify_inventory_changed()
	return true
