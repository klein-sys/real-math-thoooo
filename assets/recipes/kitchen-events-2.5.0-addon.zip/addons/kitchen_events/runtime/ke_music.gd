extends Node
## Event music: play with fade, stop, and return to the previous music.
## While the event music plays, the game's music (looping AudioStreamPlayer)
## is paused and later resumes from the same point.

var _player: AudioStreamPlayer
var _previous: Dictionary = {}
var _paused_game_music: Array = []
var _volume := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_player = AudioStreamPlayer.new()
	_player.name = "MusicaDoEvento"
	add_child(_player)


func is_playing() -> bool:
	return _player.playing


func current_stream() -> AudioStream:
	return _player.stream if _player.playing else null


## Plays [param stream] looping. The current event music becomes the "previous" one.
func play(stream: AudioStream, volume_db: float, fade: float, pause_game_music: bool) -> Variant:
	if stream == null:
		return null
	if _player.playing and _player.stream != null:
		_previous = {"stream": _player.stream, "position": _player.get_playback_position(), "volume": _volume}
	if pause_game_music:
		_pause_game_music()
	_volume = volume_db
	_player.stream = _looping(stream)
	_player.volume_db = -60.0 if fade > 0.0 else volume_db
	_player.play()
	return _fade_to(volume_db, fade)


## Stops the event music and gives the game music back.
func stop(fade: float) -> Variant:
	_previous = {}
	if not _player.playing:
		_resume_game_music()
		return null
	var done: Variant = _fade_to(-60.0, fade)
	if done is Signal:
		done.connect(_finish_stop, CONNECT_ONE_SHOT)
	else:
		_finish_stop()
	return done


## Returns to the music that played before (from the event or from the game).
func restore_previous(fade: float) -> Variant:
	if _previous.is_empty():
		return stop(fade)
	var previous := _previous
	_previous = {}
	_volume = previous["volume"]
	_player.stream = previous["stream"]
	_player.volume_db = -60.0 if fade > 0.0 else _volume
	_player.play(previous["position"])
	return _fade_to(_volume, fade)


func _finish_stop() -> void:
	_player.stop()
	_resume_game_music()


func _fade_to(volume_db: float, duration: float) -> Variant:
	if duration <= 0.0:
		_player.volume_db = volume_db
		return null
	var tween := create_tween()
	tween.tween_property(_player, "volume_db", volume_db, duration)
	return tween.finished


func _pause_game_music() -> void:
	if not _paused_game_music.is_empty():
		return
	var nodes: Array[Node] = [get_tree().root]
	while not nodes.is_empty():
		var node: Node = nodes.pop_back()
		nodes.append_array(node.get_children())
		# has_stream_playback is also true for music stopped by the game pause.
		# The music is stopped keeping its position: Godot resumes a music that is
		# only "paused" by itself when the game unpauses.
		if node is AudioStreamPlayer and node != _player and node.has_stream_playback() and _is_looping(node.stream):
			_paused_game_music.append({"player": node, "position": node.get_playback_position()})
			node.stop()


func _resume_game_music() -> void:
	for entry in _paused_game_music:
		var node: Variant = entry["player"]
		if is_instance_valid(node) and node.is_inside_tree() and not node.has_stream_playback():
			node.play(entry["position"])
	_paused_game_music.clear()


func paused_game_music_count() -> int:
	return _paused_game_music.size()


static func _is_looping(stream: AudioStream) -> bool:
	if stream is AudioStreamOggVorbis or stream is AudioStreamMP3:
		return stream.loop
	if stream is AudioStreamWAV:
		return stream.loop_mode != AudioStreamWAV.LOOP_DISABLED
	return false


static func _looping(stream: AudioStream) -> AudioStream:
	var copy: AudioStream = stream.duplicate()
	if copy is AudioStreamOggVorbis or copy is AudioStreamMP3:
		copy.loop = true
	elif copy is AudioStreamWAV and copy.loop_mode == AudioStreamWAV.LOOP_DISABLED:
		copy.loop_mode = AudioStreamWAV.LOOP_FORWARD
		copy.loop_end = int(copy.get_length() * copy.mix_rate)
	return copy


func reset() -> void:
	_player.stop()
	_previous = {}
	_resume_game_music()
