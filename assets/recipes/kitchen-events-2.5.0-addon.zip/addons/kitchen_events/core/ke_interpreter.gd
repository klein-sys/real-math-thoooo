class_name KEInterpreter
extends RefCounted
## Runs a list of commands in order, waiting for each one to finish.

signal finished(completed: bool)

## After this many commands in the same frame, the interpreter waits one frame
## so long instant lists never freeze the game.
const MAX_COMMANDS_PER_FRAME := 200

var running := false
var _stack: Array[Dictionary] = []
var _instant_count := 0


## Runs [param commands] and emits [signal finished]. [code]completed[/code] is
## false when the event was aborted.
func run(commands: Array, ctx: RefCounted) -> void:
	running = true
	ctx.interpreter = self
	await run_list(commands, ctx)
	running = false
	finished.emit(not ctx.aborted)


## Runs a nested list (used by branches and choices).
func run_list(commands: Array, ctx: RefCounted) -> void:
	var frame := {"list": commands, "index": 0}
	_stack.push_back(frame)
	while frame["index"] < commands.size() and ctx.is_running():
		var command = commands[frame["index"]]
		frame["index"] += 1
		if command == null:
			continue
		if not command.is_valid():
			push_warning("Kitchen Events: skipped incomplete command: " + command.get_summary())
			continue
		if not command.continues_conversation():
			ctx.skip_conversation = false
		var start_frame := Engine.get_process_frames()
		await command.execute(ctx)
		if Engine.get_process_frames() != start_frame:
			_instant_count = 0
			continue
		_instant_count += 1
		if _instant_count >= MAX_COMMANDS_PER_FRAME:
			_instant_count = 0
			await ctx.get_tree().process_frame
	_stack.pop_back()


## The command after the one running now, in the same list (or null).
func peek_next() -> Resource:
	if _stack.is_empty():
		return null
	var frame: Dictionary = _stack.back()
	return frame["list"][frame["index"]] if frame["index"] < frame["list"].size() else null
