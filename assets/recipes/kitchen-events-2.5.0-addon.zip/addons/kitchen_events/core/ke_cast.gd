@tool
@icon("res://addons/kitchen_events/icons/actor.svg")
class_name KECast
extends Resource
## Character list: name, portrait and name color in the dialogue box.
## Lines whose portrait is "Automatic from the character" use the portrait from here.

const Member = preload("res://addons/kitchen_events/core/ke_cast_member.gd")

@export var members: Array[Member] = []


func find(speaker: String) -> Resource:
	for member in members:
		if member != null and member.name.strip_edges().to_lower() == speaker.strip_edges().to_lower():
			return member
	return null


func names() -> Array[String]:
	var result: Array[String] = []
	for member in members:
		if member != null and not member.name.is_empty():
			result.append(member.name)
	return result
