@tool
class_name KEData
extends Resource
## Base class of every Kitchen Events resource (pages, commands, conditions...).

## Set by the event editor while it edits draft copies. The inspector then
## changes drafts directly instead of filling the editor Undo history.
static var editor_draft_mode := false


func _dont_undo_redo() -> bool:
	return editor_draft_mode


## Hides the generic Resource fields (path, name, local to scene) in the Inspector.
## Subclasses that override this must call super(property).
func _validate_property(property: Dictionary) -> void:
	if property.name in ["resource_local_to_scene", "resource_path", "resource_name", "resource_scene_unique_id"]:
		property.usage &= ~PROPERTY_USAGE_EDITOR
