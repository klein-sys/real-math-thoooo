@tool
class_name KEDialogueLine
extends "res://addons/kitchen_events/core/ke_data.gd"
## One line shown by the dialogue box.

@export var speaker: String = ""
@export_multiline var text: String = ""
@export var portrait: Texture2D
## Name color. Transparent = the box's default color.
@export var name_color: Color = Color(0, 0, 0, 0)


static func create(speaker_name: String, message: String, face: Texture2D = null) -> KEDialogueLine:
	var line := KEDialogueLine.new()
	line.speaker = speaker_name
	line.text = message
	line.portrait = face
	return line
