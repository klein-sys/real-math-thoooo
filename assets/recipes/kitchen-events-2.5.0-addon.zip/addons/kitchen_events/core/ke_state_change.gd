@tool
class_name KEStateChange
extends "res://addons/kitchen_events/core/ke_data.gd"
## One change: Local switch (A-D of this event), Global switch or variable.

const Names = preload("res://addons/kitchen_events/core/ke_names.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Target { SWITCH, SELF_SWITCH, VARIABLE }
enum SwitchValue { ON, OFF, TOGGLE }
enum Operation { SET, ADD, SUBTRACT, MULTIPLY, DIVIDE, MODULO }

const OPERATION_KEYS := ["set", "add", "sub", "mul", "div", "mod"]
const OPERATION_SYMBOLS := ["=", "+=", "-=", "×=", "÷=", "resto"]

## SWITCH = Global (by name). SELF_SWITCH = Local (A-D of this event).
@export var target: Target = Target.SELF_SWITCH:
	set(value):
		target = value
		notify_property_list_changed()
## Name of the global switch or of the variable.
@export var name: String = ""
@export_enum("A", "B", "C", "D") var self_switch: int = 0
@export var switch_value: SwitchValue = SwitchValue.ON
@export var operation: Operation = Operation.SET
@export var value: int = 0


static func make_switch(switch_name: String, on: bool = true) -> KEStateChange:
	var change := KEStateChange.new()
	change.target = Target.SWITCH
	change.name = switch_name
	change.switch_value = SwitchValue.ON if on else SwitchValue.OFF
	return change


static func make_self_switch(id: String, on: bool = true) -> KEStateChange:
	var change := KEStateChange.new()
	change.target = Target.SELF_SWITCH
	change.self_switch = maxi(Names.SELF_SWITCH_IDS.find(id), 0)
	change.switch_value = SwitchValue.ON if on else SwitchValue.OFF
	return change


static func make_variable(variable_name: String, op: Operation, amount: int) -> KEStateChange:
	var change := KEStateChange.new()
	change.target = Target.VARIABLE
	change.name = variable_name
	change.operation = op
	change.value = amount
	return change


func is_switch() -> bool:
	return target != Target.VARIABLE


func is_valid() -> bool:
	match target:
		Target.SWITCH:
			return Names.is_valid_name(name)
		Target.SELF_SWITCH:
			return self_switch >= 0 and self_switch < Names.SELF_SWITCH_IDS.size()
		Target.VARIABLE:
			return Names.is_valid_name(name) and not (value == 0 and operation in [Operation.DIVIDE, Operation.MODULO])
	return false


## Dictionary accepted by [method KEState.apply].
func to_change() -> Dictionary:
	match target:
		Target.SWITCH:
			return {"type": "switch", "id": name, "value": _flag_value()}
		Target.SELF_SWITCH:
			return {"type": "self_switch", "id": Names.SELF_SWITCH_IDS[clampi(self_switch, 0, 3)], "value": _flag_value()}
	return {"type": "variable", "id": name, "op": OPERATION_KEYS[operation], "value": value}


func get_summary() -> String:
	var flag: String = [Text.t("Ligado"), Text.t("Desligado"), Text.t("Inverter")][switch_value]
	match target:
		Target.SWITCH:
			return Text.t("Global") + ": %s = %s" % [name if not name.is_empty() else "?", flag]
		Target.SELF_SWITCH:
			return Text.t("Local") + " %s = %s" % [Names.SELF_SWITCH_IDS[clampi(self_switch, 0, 3)], flag]
	var symbol: String = OPERATION_SYMBOLS[operation]
	if operation == Operation.MODULO:
		symbol = Text.t("resto")
	return Text.t("Variável") + " %s %s %d" % [name if not name.is_empty() else "?", symbol, value]


func _flag_value() -> Variant:
	return "toggle" if switch_value == SwitchValue.TOGGLE else switch_value == SwitchValue.ON


func _validate_property(property: Dictionary) -> void:
	super(property)
	var hidden := false
	match property.name:
		"name":
			hidden = target == Target.SELF_SWITCH
		"self_switch":
			hidden = target != Target.SELF_SWITCH
		"switch_value":
			hidden = target == Target.VARIABLE
		"operation", "value":
			hidden = target != Target.VARIABLE
	if hidden:
		property.usage &= ~PROPERTY_USAGE_EDITOR
