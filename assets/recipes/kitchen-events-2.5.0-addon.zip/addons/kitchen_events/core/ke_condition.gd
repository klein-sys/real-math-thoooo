@tool
@icon("res://addons/kitchen_events/icons/condition.svg")
class_name KECondition
extends "res://addons/kitchen_events/core/ke_data.gd"
## Base class of page and branch conditions.
##
## Create your own by extending it and overriding [method is_met]:
## [codeblock]
## @tool
## class_name HasItemCondition
## extends KECondition
## @export var item_id := ""
## func is_met(ctx: KEContext) -> bool:
##     return Inventory.has(item_id)
## [/codeblock]

const Context = preload("res://addons/kitchen_events/core/ke_context.gd")


## True when the condition holds. [param ctx] gives access to the state and the event.
func is_met(_ctx: Context) -> bool:
	return true


## False when the condition is incomplete (the editor marks it).
func is_valid() -> bool:
	return true


## Short text shown in the editor.
func get_summary() -> String:
	var script: Script = get_script()
	var global_name := script.get_global_name() if script != null else &""
	return String(global_name) if global_name != &"" else "Condition"
