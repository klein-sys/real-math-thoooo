@tool
class_name KECastMember
extends Resource
## One character of the list: name, portrait and name color.

@export var name: String = ""
@export var portrait: Texture2D
@export var name_color: Color = Color("e8c07c")
