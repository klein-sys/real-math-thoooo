@tool
class_name KENames
extends RefCounted
## Validation shared by the state, the conditions and the editor.

const MAX_NAME_LENGTH := 128
const MAX_KEY_LENGTH := 4096
const SELF_SWITCH_IDS: Array[String] = ["A", "B", "C", "D"]


## Switch and variable names: not empty, no line breaks, no spaces at the ends.
static func is_valid_name(value: Variant) -> bool:
	if not value is String:
		return false
	var text: String = value
	return not text.is_empty() and text.length() <= MAX_NAME_LENGTH \
		and text == text.strip_edges() and not "\n" in text and not "\r" in text


static func is_valid_key(value: Variant) -> bool:
	return value is String and not String(value).is_empty() and String(value).length() <= MAX_KEY_LENGTH


static func is_valid_self_switch(value: Variant) -> bool:
	return value is String and value in SELF_SWITCH_IDS


## Creates a random identifier such as "ev_3fa91c0d2e".
static func new_id(prefix: String) -> String:
	return prefix + "_" + Crypto.new().generate_random_bytes(5).hex_encode()
