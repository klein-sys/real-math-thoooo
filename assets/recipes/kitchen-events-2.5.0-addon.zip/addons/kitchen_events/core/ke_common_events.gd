@tool
@icon("res://addons/kitchen_events/icons/page.svg")
class_name KECommonEvents
extends "res://addons/kitchen_events/core/ke_data.gd"
## Common events: command sequences created once and called by any event,
## in any level ("Call common event" command).
## They live in a project file (Project Settings > Kitchen Events >
## Editor > Common Events). Each common event is a page: name + commands.

const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")

@export var events: Array[Page] = []


func find(id: String) -> Resource:
	for event in events:
		if event != null and event.page_id == id:
			return event
	return null


func find_by_name(event_name: String) -> Resource:
	for event in events:
		if event != null and event.page_name.strip_edges().to_lower() == event_name.strip_edges().to_lower():
			return event
	return null
