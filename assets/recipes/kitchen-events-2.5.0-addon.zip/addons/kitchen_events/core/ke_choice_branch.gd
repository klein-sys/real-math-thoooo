@tool
class_name KEChoiceBranch
extends "res://addons/kitchen_events/core/ke_data.gd"
## One option of a "Show choices" command and the commands it runs.

const Command = preload("res://addons/kitchen_events/core/ke_command.gd")

@export var text: String = ""
## Edited in the event editor command list.
@export var commands: Array[Command] = []


static func create(option: String) -> KEChoiceBranch:
	var branch := KEChoiceBranch.new()
	branch.text = option
	return branch


func _validate_property(property: Dictionary) -> void:
	super(property)
	if property.name == "commands":
		property.usage = PROPERTY_USAGE_STORAGE
