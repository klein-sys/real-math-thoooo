class_name KEContext
extends RefCounted
## Everything a running command can access: the event, the player, the state
## and the services (dialogue box, camera, sound).

const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Target { PLAYER, THIS_EVENT, NODE }

## The KitchenEvents autoload.
var runtime: Node
## The game's [KEState].
var state: RefCounted
## The [KEEvent] running the commands.
var event: Node
## The player's body (the node in the "player" group), when there is one.
var player: Node2D
## The [KEInterpreter] running the commands.
var interpreter: RefCounted
## Key of the event in the state (local switches and counters).
var event_key: String = ""

## True when the player skipped part of the conversation.
var skipped_dialogue := false
## True while the next consecutive lines should be skipped.
var skip_conversation := false
## Set by "End event" and "Transfer": the event ends normally.
var stopped := false
## Set when the event cannot continue (removed from the scene). Nothing is applied.
var aborted := false
var abort_reason := ""
## Filled by the transfer command; runs when the event ends.
var transfer_request: Dictionary = {}
## Free space for custom commands during a run.
var data: Dictionary = {}
## If true, the run is cancelled when the event leaves the scene.
var requires_event := true
## Parallel process: runs in the background, without controlling the player, and
## stops while the game is paused.
var parallel := false


func is_running() -> bool:
	if not stopped and not aborted and requires_event and not _is_event_alive():
		abort(Text.t("o evento foi removido da cena"))
	return not stopped and not aborted


## Ends the event normally (the "On finish" changes are applied).
func stop() -> void:
	stopped = true


## Cancels the event. "On finish" changes and counters are not applied.
func abort(reason: String = "") -> void:
	if aborted:
		return
	aborted = true
	abort_reason = reason
	if not reason.is_empty():
		push_warning(Text.t("Kitchen Events: evento interrompido: ") + reason)


func get_tree() -> SceneTree:
	if is_instance_valid(runtime) and runtime.is_inside_tree():
		return runtime.get_tree()
	return Engine.get_main_loop() as SceneTree


## Waits [param seconds] seconds. Normal events wait even with the world
## paused; parallel processes stop while the game is paused.
func wait(seconds: float) -> void:
	if seconds <= 0.0:
		if parallel:
			await get_tree().physics_frame
		return
	await get_tree().create_timer(seconds, not parallel).timeout


## Applies a list of [KEStateChange] at once.
func apply_changes(changes: Array) -> bool:
	var batch: Array = []
	for change in changes:
		if change == null or not change.is_valid():
			return false
		batch.append(change.to_change())
	return state.apply(batch, event_key)


## Replaces {v:name} with the variable value and {s:name} with ON/OFF.
func format_text(text: String) -> String:
	if not "{" in text or state == null:
		return text
	var regex := RegEx.create_from_string("\\{(v|s):([^{}\\n]+)\\}")
	var result := ""
	var last := 0
	for found in regex.search_all(text):
		result += text.substr(last, found.get_start() - last)
		var name := found.get_string(2)
		if found.get_string(1) == "v":
			result += str(state.get_variable(name))
		else:
			result += "ON" if state.get_switch(name) else "OFF"
		last = found.get_end()
	return result + text.substr(last)


## Node from the event ([param path] relative to the event, or absolute).
func find_node(path: NodePath) -> Node:
	if path.is_empty():
		return null
	if _is_event_alive():
		return event.get_node_or_null(path)
	var tree := get_tree()
	return tree.root.get_node_or_null(path) if path.is_absolute() and tree != null else null


## The body a command acts on: the player, this event or another node.
func find_target(target: int, path: NodePath = NodePath()) -> Node2D:
	match target:
		Target.PLAYER:
			return player if is_instance_valid(player) else null
		Target.THIS_EVENT:
			return event if _is_event_alive() else null
	return find_node(path) as Node2D


func get_dialogue_box() -> Node:
	return runtime.get_dialogue_box() if is_instance_valid(runtime) else null


func _is_event_alive() -> bool:
	return is_instance_valid(event) and event.is_inside_tree()
