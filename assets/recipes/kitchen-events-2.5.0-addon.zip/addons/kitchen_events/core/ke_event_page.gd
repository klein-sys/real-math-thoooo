@tool
@icon("res://addons/kitchen_events/icons/page.svg")
class_name KEEventPage
extends "res://addons/kitchen_events/core/ke_data.gd"
## One page of the event. The last enabled page whose conditions are all met
## is the active page.

const Command = preload("res://addons/kitchen_events/core/ke_command.gd")
const Condition = preload("res://addons/kitchen_events/core/ke_condition.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")

enum Trigger { ACTION, TOUCH, AUTORUN, PARALLEL }
enum ImageMode { KEEP, REPLACE, HIDE }
enum AutoMove { NONE, PATROL, RANDOM }

## Name shown in the editor, for example "First talk".
@export var page_name: String = ""
@export var enabled: bool = true
## Stable page identifier, created by the editor. Used to count runs.
@export var page_id: String = ""
## All of them must be met. Without conditions, the page is always available.
@export var conditions: Array[Condition] = []

@export_group("Ativação")
## Action button, On touch, Autorun (once, as soon as the page becomes
## active) or Parallel process (looping, in the background, without locking the player).
@export var trigger: Trigger = Trigger.ACTION
## Verb shown in the prompt, for example "Read" or "Talk".
@export var interaction_label: String = ""
## Empty = the action from Project Settings (Kitchen Events > Input).
@export var interaction_action: String = ""
## 0 = always. Counts only completed runs of this page.
@export_range(0, 9999, 1, "or_greater") var max_executions: int = 0

@export_group("Imagem")
## Keep the event image, replace it with another or hide it on this page.
@export var image_mode: ImageMode = ImageMode.KEEP
@export var image: Texture2D

@export_group("Movimento próprio")
## The event walks on its own while nobody talks to it: back and forth or at random.
@export var auto_move: AutoMove = AutoMove.NONE
## Distance of each walk, in pixels.
@export_range(1.0, 4096.0, 1.0, "or_greater", "suffix:px") var auto_move_distance: float = 32.0
@export_range(1.0, 1000.0, 1.0, "suffix:px/s") var auto_move_speed: float = 32.0
## Pause between one walk and the next.
@export_range(0.0, 30.0, 0.1, "suffix:s") var auto_move_pause: float = 1.0
## Random: also up and down (top-down games).
@export var auto_move_vertical: bool = false

@export_group("Ao terminar")
## Applied together, only after the whole page completes.
@export var finish_changes: Array[StateChange] = []
## Skipping the lines (Esc / B) also completes the page.
@export var finish_on_skip: bool = true

## The command list, edited in the event editor.
@export var commands: Array[Command] = []


func has_runnable_commands() -> bool:
	for command in commands:
		if command != null and command.is_valid():
			return true
	return false


func matches(ctx: RefCounted) -> bool:
	if not enabled:
		return false
	for condition in conditions:
		if condition == null or not condition.is_valid() or not condition.is_met(ctx):
			return false
	return true


func _validate_property(property: Dictionary) -> void:
	super(property)
	if property.usage & PROPERTY_USAGE_GROUP:
		property.name = Text.t(property.name)
	if property.name == "commands":
		property.usage = PROPERTY_USAGE_STORAGE
	elif property.name == "page_id":
		property.usage |= PROPERTY_USAGE_READ_ONLY
