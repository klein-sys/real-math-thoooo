class_name KEState
extends RefCounted
## Game state used by events: switches, self switches, variables and run counts.
##
## Missing switches are OFF and missing variables are 0. Changes are applied in
## batches: either the whole batch is valid and applied, or nothing changes.
## [method to_dict] and [method from_dict] let the game store it in its own save.

signal changed

const Names = preload("res://addons/kitchen_events/core/ke_names.gd")

const SCHEMA_VERSION := 1
const MAX_ENTRIES := 10000
## Largest integer that survives a JSON round trip without losing precision.
const MAX_VARIABLE := 9007199254740991

## Increases on every applied change. Events use it to know the state moved on.
var revision := 0

var _switches: Dictionary = {}
var _self_switches: Dictionary = {}
var _variables: Dictionary = {}
var _counts: Dictionary = {}


func get_switch(name: String) -> bool:
	return _switches.has(name)


func get_self_switch(event_key: String, id: String) -> bool:
	return _self_switches.get(event_key, {}).has(id)


func get_variable(name: String) -> int:
	return _variables.get(name, 0)


func get_count(key: String) -> int:
	return _counts.get(key, 0)


func set_switch(name: String, value: bool) -> bool:
	return apply([{"type": "switch", "id": name, "value": value}])


func set_self_switch(event_key: String, id: String, value: bool) -> bool:
	return apply([{"type": "self_switch", "id": id, "value": value}], event_key)


func set_variable(name: String, value: int) -> bool:
	return apply([{"type": "variable", "id": name, "op": "set", "value": value}])


## Applies a batch of changes. Each change is a Dictionary:
## [codeblock]
## {"type": "switch", "id": "door_open", "value": true}        # value: true, false or "toggle"
## {"type": "self_switch", "id": "A", "value": true}           # uses event_key
## {"type": "variable", "id": "gold", "op": "add", "value": 5} # op: set add sub mul div mod
## {"type": "count", "id": "some_key", "value": 1}             # adds to a run counter
## [/codeblock]
## Returns false, without changing anything, if any change is invalid.
func apply(changes: Array, event_key: String = "") -> bool:
	var switches := _switches.duplicate()
	var self_switches := _self_switches.duplicate(true)
	var variables := _variables.duplicate()
	var counts := _counts.duplicate()
	for change in changes:
		if not change is Dictionary:
			return false
		var id: Variant = change.get("id")
		var value: Variant = change.get("value")
		match change.get("type"):
			"switch":
				if not Names.is_valid_name(id) or not _is_switch_value(value):
					return false
				_write_flag(switches, id, _resolve_flag(value, switches.has(id)))
			"self_switch":
				var key: Variant = change.get("event", event_key)
				if not Names.is_valid_key(key) or not Names.is_valid_self_switch(id) or not _is_switch_value(value):
					return false
				var flags: Dictionary = self_switches.get(key, {})
				_write_flag(flags, id, _resolve_flag(value, flags.has(id)))
				if flags.is_empty():
					self_switches.erase(key)
				else:
					self_switches[key] = flags
			"variable":
				if not Names.is_valid_name(id) or not value is int:
					return false
				var result: Variant = _operate(variables.get(id, 0), String(change.get("op", "set")), value)
				if result == null:
					return false
				if result == 0:
					variables.erase(id)
				else:
					variables[id] = result
			"count":
				if not Names.is_valid_key(id) or not value is int or value < 0:
					return false
				counts[id] = mini(int(counts.get(id, 0)) + value, MAX_VARIABLE)
			_:
				return false
	if switches.size() > MAX_ENTRIES or self_switches.size() > MAX_ENTRIES \
			or variables.size() > MAX_ENTRIES or counts.size() > MAX_ENTRIES:
		return false
	if switches == _switches and self_switches == _self_switches and variables == _variables and counts == _counts:
		return true
	_switches = switches
	_self_switches = self_switches
	_variables = variables
	_counts = counts
	revision += 1
	changed.emit()
	return true


## Clears everything (new game).
func clear() -> void:
	_switches.clear()
	_self_switches.clear()
	_variables.clear()
	_counts.clear()
	revision += 1
	changed.emit()


## Data ready to be stored by the game (for example with JSON).
func to_dict() -> Dictionary:
	return {
		"schema": SCHEMA_VERSION,
		"switches": _switches.keys(),
		"self_switches": _self_switches_to_lists(),
		"variables": _variables.duplicate(),
		"counts": _counts.duplicate(),
	}


## Loads data made by [method to_dict]. Accepts numbers parsed from JSON
## (floats with integer values). Invalid data is refused and the current state
## is kept.
func from_dict(data: Variant) -> bool:
	if not data is Dictionary:
		return false
	var schema: Variant = _as_int(data.get("schema", SCHEMA_VERSION))
	if schema == null or schema < 1 or schema > SCHEMA_VERSION:
		return false
	var switches := {}
	var raw_switches: Variant = data.get("switches", [])
	if not raw_switches is Array or raw_switches.size() > MAX_ENTRIES:
		return false
	for name in raw_switches:
		if not Names.is_valid_name(name):
			return false
		switches[name] = true
	var self_switches := {}
	var raw_self: Variant = data.get("self_switches", {})
	if not raw_self is Dictionary or raw_self.size() > MAX_ENTRIES:
		return false
	for key in raw_self:
		var ids: Variant = raw_self[key]
		if not Names.is_valid_key(key) or not ids is Array:
			return false
		var flags := {}
		for id in ids:
			if not Names.is_valid_self_switch(id):
				return false
			flags[id] = true
		if not flags.is_empty():
			self_switches[key] = flags
	var variables: Variant = _read_numbers(data.get("variables", {}), Callable(Names, "is_valid_name"), -MAX_VARIABLE)
	var counts: Variant = _read_numbers(data.get("counts", {}), Callable(Names, "is_valid_key"), 0)
	if variables == null or counts == null:
		return false
	_switches = switches
	_self_switches = self_switches
	_variables = variables
	_counts = counts
	revision += 1
	changed.emit()
	return true


func _self_switches_to_lists() -> Dictionary:
	var result := {}
	for key in _self_switches:
		result[key] = _self_switches[key].keys()
	return result


static func _is_switch_value(value: Variant) -> bool:
	return value is bool or (value is String and value == "toggle")


static func _resolve_flag(value: Variant, current: bool) -> bool:
	return not current if value is String else bool(value)


static func _write_flag(target: Dictionary, id: String, on: bool) -> void:
	if on:
		target[id] = true
	else:
		target.erase(id)


## Returns the new value, or null when the operation is invalid.
static func _operate(current: int, op: String, value: int) -> Variant:
	var exact: float
	match op:
		"set":
			exact = value
		"add":
			exact = float(current) + value
		"sub":
			exact = float(current) - value
		"mul":
			exact = float(current) * value
		"div":
			if value == 0:
				return null
			return clampi(current / value, -MAX_VARIABLE, MAX_VARIABLE)
		"mod":
			if value == 0:
				return null
			return current % value
		_:
			return null
	if absf(exact) > MAX_VARIABLE:
		return MAX_VARIABLE if exact > 0 else -MAX_VARIABLE
	match op:
		"add":
			return current + value
		"sub":
			return current - value
		"mul":
			return current * value
	return value


static func _as_int(value: Variant) -> Variant:
	if value is int:
		return value
	if value is float and is_finite(value) and value == floorf(value) and absf(value) <= MAX_VARIABLE:
		return int(value)
	return null


static func _read_numbers(raw: Variant, is_valid_key: Callable, minimum: int) -> Variant:
	if not raw is Dictionary or raw.size() > MAX_ENTRIES:
		return null
	var result := {}
	for key in raw:
		var number: Variant = _as_int(raw[key])
		if not is_valid_key.call(key) or number == null or number < minimum or number > MAX_VARIABLE:
			return null
		if number != 0:
			result[key] = number
	return result
