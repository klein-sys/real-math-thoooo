@tool
@icon("res://addons/kitchen_events/icons/command.svg")
class_name KECommand
extends "res://addons/kitchen_events/core/ke_data.gd"
## Base class of event commands.
##
## Create your own command by extending it. The editor finds it automatically:
## [codeblock]
## @tool
## class_name GiveGoldCommand
## extends KECommand
## @export var amount := 10
## func execute(ctx: KEContext) -> void:
##     Inventory.gold += amount
##     await ctx.wait(0.2)   # commands may use await
## func get_command_name() -> String: return "Give gold"
## func get_summary() -> String: return "Give %d gold" % amount
## [/codeblock]
## Do not store run data in the command itself: the same resource can run in
## several events at the same time. Keep it in local variables or in [param ctx].

const Context = preload("res://addons/kitchen_events/core/ke_context.gd")

## Category names used by the editor menu. Custom commands may use any text.
const CATEGORY_MESSAGE := "Message"
const CATEGORY_FLOW := "Flow"
const CATEGORY_STATE := "State"
const CATEGORY_CHARACTER := "Character"
const CATEGORY_CAMERA := "Camera"
const CATEGORY_SCREEN := "Screen"
const CATEGORY_AUDIO := "Audio"
const CATEGORY_SCENE := "Scene"
const CATEGORY_ADVANCED := "Advanced"


## Runs the command. It may use await; the event waits for it to return.
func execute(_ctx: Context) -> void:
	pass


## Name shown in the "Add command" menu.
func get_command_name() -> String:
	var script: Script = get_script()
	var global_name := script.get_global_name() if script != null else &""
	return String(global_name) if global_name != &"" else "Command"


## Menu category (see the CATEGORY_* constants).
func get_category() -> String:
	return CATEGORY_ADVANCED


## One line shown in the command list.
func get_summary() -> String:
	return get_command_name()


## False when the command is incomplete. Invalid commands are skipped with a warning.
func is_valid() -> bool:
	return true


## Nested command lists, for commands such as branches and choices.
## Each item: {"label": String, "commands": Array[KECommand]}.
func get_branches() -> Array:
	return []


## True for commands that are part of a conversation (text and choices).
## Pressing "skip" skips the following conversation commands.
func continues_conversation() -> bool:
	return false
