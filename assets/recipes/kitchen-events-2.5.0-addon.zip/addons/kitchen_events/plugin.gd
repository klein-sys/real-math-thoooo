@tool
extends EditorPlugin
## Kitchen Events editor plugin: autoload, Project Settings and the event editor.

## The addon only works from this folder (its scripts reference each other by path).
const ADDON_DIR := "res://addons/kitchen_events"
const RUNTIME_PATH := "res://addons/kitchen_events/runtime/ke_runtime.gd"
const EDITOR_TEST_PATH := "res://tests/editor_tests.gd"
const EDITOR_CAPTURE_PATH := "res://tests/editor_capture.gd"

var show_raw_data := false
var dialog: ConfirmationDialog

var _inspector: EditorInspectorPlugin
var _target: WeakRef
## Tools menu item text, in the editor language.
var _common_menu := ""
var _target_root: WeakRef

# Loaded at run time (not preloaded) so a wrong install folder gives a clear
# message instead of a compile error.
var Settings
var InspectorPlugin
var EventDialog
var Names
var Text
var EditorModel


func _init() -> void:
	if not _is_in_addon_folder():
		return
	Settings = load(ADDON_DIR + "/runtime/ke_settings.gd")
	InspectorPlugin = load(ADDON_DIR + "/editor/ke_inspector_plugin.gd")
	EventDialog = load(ADDON_DIR + "/editor/ke_event_dialog.gd")
	Names = load(ADDON_DIR + "/core/ke_names.gd")
	Text = load(ADDON_DIR + "/ke_text.gd")
	EditorModel = load(ADDON_DIR + "/editor/ke_editor_model.gd")


func _is_in_addon_folder() -> bool:
	return (get_script() as Script).resource_path.get_base_dir() == ADDON_DIR


func _report_wrong_folder() -> void:
	var folder := (get_script() as Script).resource_path.get_base_dir()
	push_error("Kitchen Events: a pasta do plugin precisa ficar em %s/ (agora está em %s/). Mova a pasta kitchen_events para dentro de addons e ative o plugin de novo." % [ADDON_DIR, folder])
	push_error("Kitchen Events: the plugin folder must be %s/ (it is %s/). Move the kitchen_events folder into addons and enable the plugin again." % [ADDON_DIR, folder])


func _enable_plugin() -> void:
	if not _is_in_addon_folder():
		_report_wrong_folder()
		return
	if not ProjectSettings.has_setting("autoload/" + Settings.AUTOLOAD_NAME):
		add_autoload_singleton(Settings.AUTOLOAD_NAME, RUNTIME_PATH)
	_add_default_interact_action()


func _disable_plugin() -> void:
	if not _is_in_addon_folder():
		return
	if ProjectSettings.has_setting("autoload/" + Settings.AUTOLOAD_NAME):
		remove_autoload_singleton(Settings.AUTOLOAD_NAME)


func _enter_tree() -> void:
	if not _is_in_addon_folder():
		_report_wrong_folder()
		return
	Settings.register_all()
	_inspector = InspectorPlugin.new()
	_inspector.plugin = self
	add_inspector_plugin(_inspector)
	dialog = EventDialog.new()
	dialog.apply_requested.connect(_on_apply_requested)
	EditorInterface.get_base_control().add_child(dialog)
	_common_menu = Text.t("Kitchen Events: eventos comuns…")
	add_tool_menu_item(_common_menu, open_common_events)
	# Development hooks, used only by this repository's tests.
	for hook in [["--ke-editor-test", EDITOR_TEST_PATH], ["--ke-editor-capture", EDITOR_CAPTURE_PATH]]:
		if hook[0] in OS.get_cmdline_user_args() and ResourceLoader.exists(hook[1]):
			var test: Node = load(hook[1]).new()
			add_child(test)
			test.run.call_deferred(self)


func _exit_tree() -> void:
	if _inspector == null:
		return
	remove_tool_menu_item(_common_menu)
	remove_inspector_plugin(_inspector)
	_inspector = null
	if is_instance_valid(dialog):
		dialog.queue_free()
	dialog = null


func _get_plugin_name() -> String:
	return "Kitchen Events"


func open_event(reference: WeakRef) -> void:
	var event: Node = reference.get_ref()
	var root := EditorInterface.get_edited_scene_root()
	if not is_instance_valid(event) or root == null or (root != event and not root.is_ancestor_of(event)):
		return
	_target = reference
	_target_root = weakref(root)
	dialog.open_for(event, _scene_names(root))


## Switches, variables and characters used by the other events in the scene (▾ suggestions).
func _scene_names(root: Node) -> Dictionary:
	var model = EditorModel.new()
	var all_pages: Array = []
	var nodes: Array[Node] = [root]
	while not nodes.is_empty():
		var node: Node = nodes.pop_back()
		nodes.append_array(node.get_children())
		if node.get_script() != null and node.has_method("get_event_key"):
			all_pages.append_array(node.pages)
	model.pages = all_pages
	return model.used_names()


## Opens the project's common events window.
func open_common_events() -> void:
	var root := EditorInterface.get_edited_scene_root()
	dialog.open_common(_scene_names(root) if root != null else {})


func set_show_raw_data(reference: WeakRef, value: bool) -> void:
	show_raw_data = value
	var event: Node = reference.get_ref()
	if is_instance_valid(event):
		event.notify_property_list_changed()


func regenerate_id(reference: WeakRef) -> void:
	var event: Node = reference.get_ref()
	if not is_instance_valid(event):
		return
	var history := get_undo_redo()
	history.create_action(Text.t("Novo id do evento"), UndoRedo.MERGE_DISABLE, event)
	history.add_do_property(event, &"event_id", Names.new_id("ev"))
	history.add_undo_property(event, &"event_id", event.event_id)
	history.add_do_method(event, &"notify_property_list_changed")
	history.add_undo_method(event, &"notify_property_list_changed")
	history.commit_action()


func _on_apply_requested(pages: Array) -> void:
	var event: Node = _target.get_ref() if _target != null else null
	var root: Node = _target_root.get_ref() if _target_root != null else null
	if not is_instance_valid(event) or not is_instance_valid(root) or root != EditorInterface.get_edited_scene_root() \
			or (root != event and not root.is_ancestor_of(event)):
		push_warning(Text.t("A cena mudou. Feche esta janela e selecione o evento de novo."))
		return
	var history := get_undo_redo()
	history.create_action(Text.t("Editar evento %s") % event.name, UndoRedo.MERGE_DISABLE, event)
	history.add_do_property(event, &"pages", _typed(event, pages))
	history.add_undo_property(event, &"pages", event.pages)
	history.add_do_method(event, &"notify_property_list_changed")
	history.add_undo_method(event, &"notify_property_list_changed")
	history.commit_action()
	dialog.hide()


## Copy of [param pages] typed with the element type of the event property.
func _typed(event: Node, pages: Array) -> Array:
	var result: Array = event.pages.duplicate()
	result.clear()
	result.assign(pages)
	return result


## Creates the "interact" action (E, Space, Enter, A button) when it does not exist.
func _add_default_interact_action() -> void:
	var path := "input/" + String(Settings.get_value("input/interact_action"))
	if ProjectSettings.has_setting(path):
		return
	var events: Array = []
	for keycode in [KEY_E, KEY_SPACE, KEY_ENTER]:
		var key := InputEventKey.new()
		key.physical_keycode = keycode
		events.append(key)
	var button := InputEventJoypadButton.new()
	button.button_index = JOY_BUTTON_A
	events.append(button)
	ProjectSettings.set_setting(path, {"deadzone": 0.5, "events": events})
	ProjectSettings.save()
