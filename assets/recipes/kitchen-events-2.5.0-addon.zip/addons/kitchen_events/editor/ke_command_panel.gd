@tool
extends VBoxContainer
## "Edit command" column: one form for each command type.
## Edits a copy; "Done" sends the result back to the draft.

signal accepted(result: Dictionary)
signal discarded
signal cast_requested

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Theme_ = preload("res://addons/kitchen_events/editor/ke_panel_theme.gd")
const Model = preload("res://addons/kitchen_events/editor/ke_editor_model.gd")
const SwitchRow = preload("res://addons/kitchen_events/editor/ke_switch_row.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const Context = preload("res://addons/kitchen_events/core/ke_context.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")
const ChoiceBranch = preload("res://addons/kitchen_events/core/ke_choice_branch.gd")
const ItemCondition = preload("res://addons/kitchen_events/conditions/ke_item_condition.gd")
const GiveItem = preload("res://addons/kitchen_events/commands/ke_give_item_command.gd")
const RemoveItem = preload("res://addons/kitchen_events/commands/ke_remove_item_command.gd")
const SwitchCondition = preload("res://addons/kitchen_events/conditions/ke_switch_condition.gd")
const VariableCondition = preload("res://addons/kitchen_events/conditions/ke_variable_condition.gd")
const MethodCondition = preload("res://addons/kitchen_events/conditions/ke_method_condition.gd")
const ShowText = preload("res://addons/kitchen_events/commands/ke_show_text_command.gd")
const ShowChoices = preload("res://addons/kitchen_events/commands/ke_show_choices_command.gd")
const Conditional = preload("res://addons/kitchen_events/commands/ke_conditional_command.gd")
const Wait = preload("res://addons/kitchen_events/commands/ke_wait_command.gd")
const EndEvent = preload("res://addons/kitchen_events/commands/ke_end_event_command.gd")
const ChangeState = preload("res://addons/kitchen_events/commands/ke_change_state_command.gd")
const Face = preload("res://addons/kitchen_events/commands/ke_face_command.gd")
const Move = preload("res://addons/kitchen_events/commands/ke_move_command.gd")
const PlayAnimation = preload("res://addons/kitchen_events/commands/ke_play_animation_command.gd")
const CameraCommand = preload("res://addons/kitchen_events/commands/ke_camera_command.gd")
const PlaySound = preload("res://addons/kitchen_events/commands/ke_play_sound_command.gd")
const Transfer = preload("res://addons/kitchen_events/commands/ke_transfer_command.gd")
const CallMethod = preload("res://addons/kitchen_events/commands/ke_call_method_command.gd")
const EmitSignal = preload("res://addons/kitchen_events/commands/ke_emit_signal_command.gd")
const BalloonCommand = preload("res://addons/kitchen_events/commands/ke_balloon_command.gd")
const ScreenCommand = preload("res://addons/kitchen_events/commands/ke_screen_command.gd")
const ImageCommand = preload("res://addons/kitchen_events/commands/ke_show_image_command.gd")
const MusicCommand = preload("res://addons/kitchen_events/commands/ke_music_command.gd")
const CallCommon = preload("res://addons/kitchen_events/commands/ke_call_common_event_command.gd")

const DIRECTIONS := ["Direita", "Esquerda", "Cima", "Baixo", "Para o jogador", "Para longe do jogador"]
const TARGETS := ["Jogador", "Este evento", "Outro nó"]

var active := false
var kind := ""
var names: Dictionary = {"switches": [], "variables": [], "speakers": []}

var _heading: Label
var _empty: Label
var _content: VBoxContainer
var _scroll: ScrollContainer
var _form: VBoxContainer
var _error: Label
var _confirm: Button
var _discard: Button
var _resource: Resource
var _finish_mode := false
var _is_new := true
var _initial: Variant
var _collect: Callable
var _inspector: EditorInspector
var _file_dialog: EditorFileDialog
var _file_target: Callable
# Fala
var _speaker: LineEdit
var _speech: TextEdit
var _portrait: Texture2D
var _portrait_mode: OptionButton
var _portrait_preview: TextureRect
var _portrait_caption: Label


func _init() -> void:
	add_theme_constant_override("separation", 10)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	_heading = Label.new()
	_heading.add_theme_font_size_override("font_size", 17)
	_heading.add_theme_color_override("font_color", Theme_.HEADING)
	add_child(_heading)
	_empty = Label.new()
	_empty.text = Text.t("Selecione um comando na coluna do meio para editar.\n\nPara começar uma sequência, use + Fala, + Movimento, + Espera ou + Switch.")
	_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_empty.custom_minimum_size.x = 200
	_empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(_empty)
	_content = VBoxContainer.new()
	_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(_content)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.custom_minimum_size.y = 100
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll.follow_focus = true
	_content.add_child(_scroll)
	_error = Label.new()
	_error.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_error.custom_minimum_size.x = 200
	_error.add_theme_color_override("font_color", Theme_.ERROR)
	_content.add_child(_error)
	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 8)
	_content.add_child(footer)
	_confirm = Button.new()
	_confirm.text = Text.t("Concluir comando")
	_confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_confirm.pressed.connect(_accept)
	footer.add_child(_confirm)
	_discard = Button.new()
	_discard.text = Text.t("Descartar edição")
	_discard.pressed.connect(func() -> void:
		clear_editor()
		discarded.emit())
	footer.add_child(_discard)
	clear_editor()
	tree_exiting.connect(func() -> void:
		if is_instance_valid(_inspector):
			_inspector.edit(null))


func get_ok_button() -> Button:
	return _confirm


func get_cancel_button() -> Button:
	return _discard


func clear_editor() -> void:
	active = false
	if is_instance_valid(_inspector):
		_inspector.edit(null)
	_content.hide()
	_empty.show()
	_heading.text = Text.t("Editar comando")


## Finishes the edit in progress. Returns false if the form is incomplete.
func flush() -> bool:
	return _accept() if active else true


## Opens the form for a new command.
func open_new(command: Resource, known: Dictionary, finish: bool = false) -> void:
	_open(command, known, true, finish)


## Opens the form to edit an existing row (a copy is edited).
func open_row(row: Dictionary, known: Dictionary) -> void:
	if row["kind"] == "finish":
		_open(ChangeState.create([Model.copy_value(row["data"])]), known, false, true)
	else:
		_open(Model.copy_value(row["data"]), known, false, false)


func _open(resource: Resource, known: Dictionary, creating: bool, finish: bool) -> void:
	if is_instance_valid(_inspector):
		_inspector.edit(null)
	_resource = resource
	_is_new = creating
	_finish_mode = finish
	names = known
	kind = kind_of(resource)
	_clear_form()
	var title: String = resource.get_command_name()
	match kind:
		"item":
			_build_item()
		"text":
			_build_text()
		"move":
			_build_move()
		"face":
			_build_face()
		"wait":
			_build_wait()
		"switch":
			title = Text.t("Alterar switch")
			_build_switch()
		"variable":
			title = Text.t("Alterar variável")
			_build_variable()
		"choices":
			_build_choices()
		"branch":
			title = Text.t("Condição (se / senão)")
			_build_branch()
		"camera":
			_build_camera()
		"animation":
			_build_animation()
		"sound":
			_build_sound()
		"transfer":
			_build_transfer()
		"call":
			_build_call()
		"signal":
			_build_signal()
		"balloon":
			_build_balloon()
		"screen":
			_build_screen()
		"image":
			_build_image()
		"music":
			_build_music()
		"common":
			_build_common()
		_:
			_build_inspector()
	_heading.text = (Text.t("Novo: ") if creating else Text.t("Editar: ")) + title
	_error.text = ""
	_initial = Model.copy_value(resource)
	active = true
	_content.show()
	_empty.hide()
	_scroll.scroll_vertical = 0
	if kind == "text":
		_speech.grab_focus.call_deferred()


static func kind_of(resource: Resource) -> String:
	if resource is GiveItem or resource is RemoveItem:
		return "item"
	if resource is ShowText:
		return "text"
	if resource is Move:
		return "move"
	if resource is Face:
		return "face"
	if resource is Wait:
		return "wait"
	if resource is ChangeState:
		return "variable" if resource.is_variable_change() else "switch"
	if resource is ShowChoices:
		return "choices"
	if resource is Conditional:
		return "branch"
	if resource is CameraCommand:
		return "camera"
	if resource is PlayAnimation:
		return "animation"
	if resource is PlaySound:
		return "sound"
	if resource is Transfer:
		return "transfer"
	if resource is CallMethod:
		return "call"
	if resource is EmitSignal:
		return "signal"
	if resource is EndEvent:
		return "end"
	if resource is BalloonCommand:
		return "balloon"
	if resource is ScreenCommand:
		return "screen"
	if resource is ImageCommand:
		return "image"
	if resource is MusicCommand:
		return "music"
	if resource is CallCommon:
		return "common"
	return "custom"


# --- Form parts ---------------------------------------------------------------

func _clear_form() -> void:
	if is_instance_valid(_form):
		_scroll.remove_child(_form)
		_form.queue_free()
	_form = VBoxContainer.new()
	_form.add_theme_constant_override("separation", 8)
	_form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_form)
	_inspector = null


func _label(text: String, parent: Control = null) -> Label:
	var result := Label.new()
	result.text = text
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	result.custom_minimum_size.x = 120
	(parent if parent != null else _form).add_child(result)
	return result


func _hint(text: String) -> Label:
	var result := _label(text)
	result.add_theme_color_override("font_color", Theme_.MUTED)
	return result


func _line(text: String, value: String, placeholder: String = "") -> LineEdit:
	_label(text)
	var edit := LineEdit.new()
	edit.text = value
	edit.placeholder_text = placeholder
	_form.add_child(edit)
	return edit


func _number(text: String, value: float, minimum: float, maximum: float, step: float, suffix: String = "") -> SpinBox:
	_label(text)
	var spin := SpinBox.new()
	spin.min_value = minimum
	spin.max_value = maximum
	spin.step = step
	spin.allow_greater = true
	spin.value = value
	spin.suffix = suffix
	_form.add_child(spin)
	return spin


func _option(text: String, items: Array, selected: int) -> OptionButton:
	if not text.is_empty():
		_label(text)
	var option := OptionButton.new()
	for item in items:
		option.add_item(Text.t(item))
	option.select(clampi(selected, 0, items.size() - 1))
	_form.add_child(option)
	return option


func _check(text: String, value: bool) -> CheckBox:
	var box := CheckBox.new()
	box.text = text
	box.button_pressed = value
	_form.add_child(box)
	return box


## "Who?" with Player / This event / Other node + path.
func _target_picker(text: String, target: int, path: NodePath) -> Array:
	var option := _option(text, TARGETS, target)
	var edit := LineEdit.new()
	edit.placeholder_text = Text.t("Caminho a partir do evento, ex.: ../Npc")
	edit.text = str(path)
	edit.visible = target == Context.Target.NODE
	_form.add_child(edit)
	option.item_selected.connect(func(index: int) -> void: edit.visible = index == Context.Target.NODE)
	return [option, edit]


func _name_field(parent: Control, value: String, placeholder: String, suggestions: Array) -> LineEdit:
	var edit := LineEdit.new()
	edit.text = value
	edit.placeholder_text = placeholder
	edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	edit.custom_minimum_size.x = 90
	parent.add_child(edit)
	var known := MenuButton.new()
	known.text = "▾"
	known.disabled = suggestions.is_empty()
	for item in suggestions:
		known.get_popup().add_item(item)
	known.get_popup().index_pressed.connect(func(index: int) -> void: edit.text = known.get_popup().get_item_text(index))
	parent.add_child(known)
	return edit


func _remove_button(parent: Control, callback: Callable) -> void:
	var button := Button.new()
	button.text = "×"
	button.tooltip_text = Text.t("Remover")
	button.pressed.connect(callback)
	parent.add_child(button)


func _rows_box() -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	_form.add_child(box)
	return box


func _clear_box(box: Control) -> void:
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()


# --- Forms --------------------------------------------------------------------

func _build_text() -> void:
	_label(Text.t("Quem está falando?"))
	var row := HBoxContainer.new()
	_form.add_child(row)
	_speaker = LineEdit.new()
	_speaker.text = _resource.speaker
	_speaker.placeholder_text = Text.t("Nome do personagem (vazio = sem nome)")
	_speaker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(_speaker)
	var preset := MenuButton.new()
	preset.text = Text.t("Escolher") + " ▾"
	row.add_child(preset)
	var people: Array[String] = []
	var cast := Settings.cast()
	if cast != null:
		people.append_array(cast.names())
	for speaker in names.get("speakers", []):
		if not speaker in people:
			people.append(speaker)
	for person in people:
		preset.get_popup().add_item(person)
	if not people.is_empty():
		preset.get_popup().add_separator()
	preset.get_popup().add_item(Text.t("Personagens…"), 10000)
	preset.get_popup().id_pressed.connect(func(id: int) -> void:
		if id == 10000:
			cast_requested.emit()
			return
		_speaker.text = preset.get_popup().get_item_text(preset.get_popup().get_item_index(id))
		_refresh_portrait())
	_label(Text.t("Texto da fala"))
	_speech = TextEdit.new()
	_speech.text = _resource.text
	_speech.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_speech.custom_minimum_size.y = 120
	_form.add_child(_speech)
	_hint(Text.t("Dicas: {v:ouro} mostra uma variável; [b]negrito[/b] e [color=gold]cor[/color] funcionam."))
	_label(Text.t("Retrato"))
	var portrait_row := HBoxContainer.new()
	portrait_row.add_theme_constant_override("separation", 12)
	_form.add_child(portrait_row)
	_portrait_preview = TextureRect.new()
	_portrait_preview.custom_minimum_size = Vector2(72, 72)
	_portrait_preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_portrait_preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_portrait_preview.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_portrait_preview.tooltip_text = Text.t("Arraste uma imagem aqui ou use Escolher imagem…")
	_portrait_preview.set_drag_forwarding(Callable(), _can_drop_texture, _drop_texture)
	portrait_row.add_child(_portrait_preview)
	var fields := VBoxContainer.new()
	fields.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	portrait_row.add_child(fields)
	_portrait_mode = OptionButton.new()
	_portrait_mode.add_item(Text.t("Automático pelo personagem"))
	_portrait_mode.add_item(Text.t("Personalizado"))
	fields.add_child(_portrait_mode)
	var buttons := HBoxContainer.new()
	fields.add_child(buttons)
	var browse := Button.new()
	browse.text = Text.t("Escolher imagem…")
	browse.pressed.connect(func() -> void: _browse(["*.png,*.webp,*.jpg,*.jpeg,*.svg,*.tres;Imagens"], func(path: String) -> void:
		var texture := load(path) as Texture2D
		if texture == null:
			_error.text = Text.t("Escolha uma imagem ou um recurso Texture2D.")
			return
		_set_portrait(texture)))
	buttons.add_child(browse)
	var automatic := Button.new()
	automatic.text = Text.t("Automático")
	automatic.pressed.connect(func() -> void: _set_portrait(null))
	buttons.add_child(automatic)
	_portrait_caption = Label.new()
	_portrait_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_portrait_caption.custom_minimum_size.x = 120
	_portrait_caption.add_theme_color_override("font_color", Theme_.MUTED)
	fields.add_child(_portrait_caption)
	_portrait_mode.item_selected.connect(func(index: int) -> void:
		if index == 0:
			_set_portrait(null))
	_speaker.text_changed.connect(func(_value: String) -> void: _refresh_portrait())
	_set_portrait(_resource.portrait)
	_collect = func() -> Variant:
		if _speech.text.strip_edges().is_empty():
			return Text.t("Escreva a fala ou use Descartar edição.")
		_resource.speaker = _speaker.text.strip_edges()
		_resource.text = _speech.text
		_resource.portrait = _portrait
		return {"command": _resource}


func _set_portrait(texture: Texture2D) -> void:
	_portrait = texture
	_portrait_mode.select(0 if texture == null else 1)
	_refresh_portrait()


func _refresh_portrait() -> void:
	if _portrait_preview == null:
		return
	var texture := _portrait
	var cast := Settings.cast()
	var member: Resource = cast.find(_speaker.text) if cast != null else null
	if texture == null and member != null:
		texture = member.portrait
	_portrait_preview.texture = texture
	if _portrait != null:
		_portrait_caption.text = Text.t("Retrato: ") + (_portrait.resource_path.get_file() if not _portrait.resource_path.is_empty() else "Texture2D")
	elif member != null and member.portrait != null:
		_portrait_caption.text = Text.t("Usa o retrato de %s da lista de personagens.") % member.name
	else:
		_portrait_caption.text = Text.t("Sem retrato. Cadastre o personagem em Escolher ▾ > Personagens… ou escolha uma imagem.")


func _can_drop_texture(_at: Vector2, data: Variant) -> bool:
	if not data is Dictionary:
		return false
	if data.get("type") == "resource":
		return data.get("resource") is Texture2D
	var files: Array = data.get("files", [])
	return data.get("type") == "files" and files.size() == 1 and ResourceLoader.exists(files[0], "Texture2D")


func _drop_texture(at: Vector2, data: Variant) -> void:
	if not _can_drop_texture(at, data):
		return
	_set_portrait(data["resource"] if data.get("type") == "resource" else load(data["files"][0]))


func _build_move() -> void:
	var who := _target_picker(Text.t("Quem se move?"), _resource.target, _resource.node_path)
	var direction := _option(Text.t("Direção"), DIRECTIONS, _resource.direction)
	var distance := _number(Text.t("Distância (um tile costuma ter 16 pixels)"), _resource.distance, 1, 100000, 1, "px")
	var speed := _number(Text.t("Velocidade"), _resource.speed, 1, 10000, 1, "px/s")
	var wait := _check(Text.t("Esperar terminar antes do próximo comando"), _resource.wait)
	_collect = func() -> Variant:
		if who[0].selected == Context.Target.NODE and who[1].text.strip_edges().is_empty():
			return Text.t("Escreva o caminho do nó que vai se mover.")
		_resource.target = who[0].selected
		_resource.node_path = NodePath(who[1].text.strip_edges())
		_resource.direction = direction.selected
		_resource.distance = distance.value
		_resource.speed = speed.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_face() -> void:
	var who := _target_picker(Text.t("Quem vira?"), _resource.target, _resource.node_path)
	var direction := _option(Text.t("Direção"), DIRECTIONS, _resource.direction)
	_collect = func() -> Variant:
		if who[0].selected == Context.Target.NODE and who[1].text.strip_edges().is_empty():
			return Text.t("Escreva o caminho do nó.")
		_resource.target = who[0].selected
		_resource.node_path = NodePath(who[1].text.strip_edges())
		_resource.direction = direction.selected
		return {"command": _resource}


func _build_wait() -> void:
	var seconds := _number(Text.t("Tempo de espera"), _resource.seconds, 0, 600, 0.05, "s")
	_collect = func() -> Variant:
		_resource.seconds = seconds.value
		return {"command": _resource}


func _build_switch() -> void:
	_label(Text.t("Quando aplicar?"))
	var timing := OptionButton.new()
	timing.add_item(Text.t("Neste ponto da lista de comandos"))
	timing.add_item(Text.t("Ao terminar toda a página"))
	timing.select(1 if _finish_mode else 0)
	_form.add_child(timing)
	_hint(Text.t("Local: só deste evento (A, B, C, D). Global: compartilhado por eventos e mapas."))
	var changes: Array = []
	for change in _resource.changes:
		if change != null and change.is_switch():
			changes.append(change)
	if changes.is_empty():
		changes.append(StateChange.make_self_switch("A"))
	var box := _rows_box()
	var rebuild := func(self_ref: Callable) -> void:
		_clear_box(box)
		for i in changes.size():
			var row := SwitchRow.new()
			box.add_child(row)
			row.configure(changes[i], names.get("switches", []), changes.size() > 1)
			row.removed.connect(func() -> void:
				changes.remove_at(i)
				self_ref.call(self_ref))
	rebuild.call(rebuild)
	var add := Button.new()
	add.text = Text.t("+ Outra alteração neste comando")
	add.pressed.connect(func() -> void:
		changes.append(StateChange.make_self_switch("A"))
		rebuild.call(rebuild))
	_form.add_child(add)
	_collect = func() -> Variant:
		for change in changes:
			if not change.is_valid():
				return Text.t("Escreva o nome do switch global ou use Descartar edição.")
		if timing.selected == 1:
			return {"finish": changes}
		_resource.changes.assign(changes)
		return {"command": _resource}


func _build_variable() -> void:
	_hint(Text.t("Variáveis guardam números inteiros, como ouro ou pontos. Uma variável nova começa em 0."))
	var changes: Array = []
	for change in _resource.changes:
		if change != null and not change.is_switch():
			changes.append(change)
	if changes.is_empty():
		changes.append(StateChange.make_variable("", StateChange.Operation.ADD, 1))
	var box := _rows_box()
	var rebuild := func(self_ref: Callable) -> void:
		_clear_box(box)
		for i in changes.size():
			var change: Resource = changes[i]
			var row := HBoxContainer.new()
			box.add_child(row)
			var name_edit := _name_field(row, change.name, "nome_da_variavel", names.get("variables", []))
			name_edit.text_changed.connect(func(text: String) -> void: change.name = text.strip_edges())
			var op := OptionButton.new()
			for label in ["=", "+", "−", "×", "÷", Text.t("resto")]:
				op.add_item(label)
			op.select(change.operation)
			op.item_selected.connect(func(index: int) -> void: change.operation = index)
			row.add_child(op)
			var amount := SpinBox.new()
			amount.min_value = -1000000000
			amount.max_value = 1000000000
			amount.allow_greater = true
			amount.allow_lesser = true
			amount.value = change.value
			amount.value_changed.connect(func(value: float) -> void: change.value = int(value))
			row.add_child(amount)
			if changes.size() > 1:
				_remove_button(row, func() -> void:
					changes.remove_at(i)
					self_ref.call(self_ref))
	rebuild.call(rebuild)
	var add := Button.new()
	add.text = Text.t("+ Outra variável")
	add.pressed.connect(func() -> void:
		changes.append(StateChange.make_variable("", StateChange.Operation.ADD, 1))
		rebuild.call(rebuild))
	_form.add_child(add)
	_collect = func() -> Variant:
		for change in changes:
			if not change.is_valid():
				return Text.t("Escreva o nome de cada variável (e não divida por zero).")
		_resource.changes.assign(changes)
		return {"command": _resource}


func _build_choices() -> void:
	_hint(Text.t("Cada opção ganha a sua própria lista de comandos, mostrada abaixo dela na sequência."))
	var branches: Array = _resource.choices.duplicate()
	if branches.is_empty():
		branches.append(ChoiceBranch.create(Text.t("Sim")))
		branches.append(ChoiceBranch.create(Text.t("Não")))
	var texts: Array[String] = []
	for branch in branches:
		texts.append(branch.text)
	var box := _rows_box()
	var cancel := OptionButton.new()
	var refresh_cancel := func() -> void:
		var current := cancel.selected
		cancel.clear()
		cancel.add_item(Text.t("Esc / B não fecha as escolhas"))
		for i in texts.size():
			cancel.add_item(Text.t("Esc / B escolhe a opção %d") % (i + 1))
		cancel.select(clampi(current, 0, texts.size()))
	var rebuild := func(self_ref: Callable) -> void:
		_clear_box(box)
		for i in texts.size():
			var row := HBoxContainer.new()
			box.add_child(row)
			var number := Label.new()
			number.text = "%d." % (i + 1)
			row.add_child(number)
			var edit := LineEdit.new()
			edit.text = texts[i]
			edit.placeholder_text = Text.t("Texto da opção")
			edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			edit.text_changed.connect(func(text: String) -> void: texts[i] = text)
			row.add_child(edit)
			if texts.size() > 1:
				_remove_button(row, func() -> void:
					texts.remove_at(i)
					branches.remove_at(i)
					refresh_cancel.call()
					self_ref.call(self_ref))
	rebuild.call(rebuild)
	var add := Button.new()
	add.text = Text.t("+ Opção")
	add.pressed.connect(func() -> void:
		texts.append("")
		branches.append(ChoiceBranch.new())
		refresh_cancel.call()
		rebuild.call(rebuild))
	_form.add_child(add)
	_label(Text.t("Cancelar"))
	_form.add_child(cancel)
	cancel.add_item("")
	refresh_cancel.call()
	cancel.select(_resource.cancel_choice + 1 if _resource.cancel_choice >= 0 and _resource.cancel_choice < texts.size() else 0)
	_collect = func() -> Variant:
		for text in texts:
			if text.strip_edges().is_empty():
				return Text.t("Escreva o texto de todas as opções.")
		for i in branches.size():
			branches[i].text = texts[i].strip_edges()
		_resource.choices.assign(branches)
		_resource.cancel_choice = cancel.selected - 1
		return {"command": _resource}


func _build_branch() -> void:
	_label(Text.t("Condições"))
	var conditions: Array = _resource.conditions.duplicate()
	if conditions.is_empty():
		conditions.append(SwitchCondition.new())
	var box := _rows_box()
	var rebuild := func(self_ref: Callable) -> void:
		_clear_box(box)
		for i in conditions.size():
			var row := condition_row(conditions[i], names, conditions.size() > 1)
			box.add_child(row)
			row.set_meta(&"index", i)
			if row.has_signal("removed"):
				row.removed.connect(func() -> void:
					conditions.remove_at(i)
					self_ref.call(self_ref))
	rebuild.call(rebuild)
	var adds := HFlowContainer.new()
	_form.add_child(adds)
	for pair in [[Text.t("+ Switch"), SwitchCondition], [Text.t("+ Variável"), VariableCondition], [Text.t("+ Item"), ItemCondition], [Text.t("+ Método do código"), MethodCondition]]:
		var button := Button.new()
		button.text = pair[0]
		var script: Script = pair[1]
		button.pressed.connect(func() -> void:
			conditions.append(script.new())
			rebuild.call(rebuild))
		adds.add_child(button)
	var mode := _option(Text.t("Precisa valer"), ["Todas as condições", "Qualquer uma"], 0 if _resource.require_all else 1)
	var has_else := _check(Text.t("Ter \"Senão\" (comandos para quando não vale)"), _resource.has_else)
	_collect = func() -> Variant:
		for condition in conditions:
			if not condition.is_valid():
				return Text.t("Complete todas as condições (nomes de switch, variável ou método).")
		_resource.conditions.assign(conditions)
		_resource.require_all = mode.selected == 0
		_resource.has_else = has_else.button_pressed
		return {"command": _resource}


## Condition row: switch, variable or method. Emits "removed" and "edited".
static func condition_row(condition: Resource, known: Dictionary, removable: bool) -> Control:
	if condition is SwitchCondition:
		var switch_row := SwitchRow.new()
		switch_row.configure(condition, known.get("switches", []), removable)
		return switch_row
	var row := ConditionRow.new()
	row.setup(condition, known, removable)
	return row


class ConditionRow extends HBoxContainer:
	signal edited
	signal removed

	func setup(condition: Resource, known: Dictionary, removable: bool) -> void:
		add_theme_constant_override("separation", 5)
		if condition is VariableCondition:
			var label := Label.new()
			label.text = Text.t("Variável")
			add_child(label)
			var name_edit := LineEdit.new()
			name_edit.text = condition.variable_name
			name_edit.placeholder_text = "nome_da_variavel"
			name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			name_edit.custom_minimum_size.x = 80
			name_edit.text_changed.connect(func(text: String) -> void:
				condition.variable_name = text.strip_edges()
				edited.emit())
			add_child(name_edit)
			var known_menu := MenuButton.new()
			known_menu.text = "▾"
			var variables: Array = known.get("variables", [])
			known_menu.disabled = variables.is_empty()
			for item in variables:
				known_menu.get_popup().add_item(item)
			known_menu.get_popup().index_pressed.connect(func(index: int) -> void:
				name_edit.text = known_menu.get_popup().get_item_text(index)
				condition.variable_name = name_edit.text
				edited.emit())
			add_child(known_menu)
			var op := OptionButton.new()
			for symbol in VariableCondition.SYMBOLS:
				op.add_item(symbol)
			op.select(condition.comparison)
			op.item_selected.connect(func(index: int) -> void:
				condition.comparison = index
				edited.emit())
			add_child(op)
			var amount := SpinBox.new()
			amount.min_value = -1000000000
			amount.max_value = 1000000000
			amount.allow_greater = true
			amount.allow_lesser = true
			amount.value = condition.value
			amount.value_changed.connect(func(value: float) -> void:
				condition.value = int(value)
				edited.emit())
			add_child(amount)
		elif condition is ItemCondition:
			var fields := VBoxContainer.new()
			fields.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			add_child(fields)
			var mode := OptionButton.new()
			mode.add_item(Text.t("Possui item"))
			mode.add_item(Text.t("Não possui item"))
			mode.select(1 if condition.negate else 0)
			mode.item_selected.connect(func(index: int) -> void:
				condition.negate = index == 1
				edited.emit())
			fields.add_child(mode)
			var id := LineEdit.new()
			id.placeholder_text = Text.t("ID do item")
			id.text = condition.item_id
			id.text_changed.connect(func(value: String) -> void:
				condition.item_id = value.strip_edges()
				edited.emit())
			fields.add_child(id)
			var amount := SpinBox.new()
			amount.min_value = 1
			amount.max_value = 1000000
			amount.value = condition.quantity
			amount.tooltip_text = Text.t("Quantidade mínima")
			amount.value_changed.connect(func(value: float) -> void:
				condition.quantity = int(value)
				edited.emit())
			fields.add_child(amount)
		elif condition is MethodCondition:
			var path := LineEdit.new()
			path.text = str(condition.node_path)
			path.placeholder_text = Text.t("Nó, ex.: /root/Inventario")
			path.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			path.custom_minimum_size.x = 80
			path.text_changed.connect(func(text: String) -> void:
				condition.node_path = NodePath(text.strip_edges())
				edited.emit())
			add_child(path)
			var method := LineEdit.new()
			method.text = condition.method
			method.placeholder_text = Text.t("método")
			method.custom_minimum_size.x = 80
			method.text_changed.connect(func(text: String) -> void:
				condition.method = text.strip_edges()
				edited.emit())
			add_child(method)
			var negate := CheckBox.new()
			negate.text = Text.t("não")
			negate.tooltip_text = Text.t("Vale quando o método retorna false")
			negate.button_pressed = condition.negate
			negate.toggled.connect(func(value: bool) -> void:
				condition.negate = value
				edited.emit())
			add_child(negate)
		else:
			var label := Label.new()
			label.text = condition.get_summary()
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			add_child(label)
		if removable:
			var remove := Button.new()
			remove.text = "×"
			remove.tooltip_text = Text.t("Remover")
			remove.pressed.connect(func() -> void: removed.emit())
			add_child(remove)


func _build_camera() -> void:
	var mode := _option(Text.t("O que a câmera faz?"), ["Focar um alvo", "Zoom", "Voltar ao normal"], _resource.mode)
	var focus_box := VBoxContainer.new()
	_form.add_child(focus_box)
	var form_backup := _form
	_form = focus_box
	var who := _target_picker(Text.t("Alvo"), _resource.target, _resource.node_path)
	_label(Text.t("Deslocamento (pixels)"))
	var offset_row := HBoxContainer.new()
	_form.add_child(offset_row)
	var offset_x := SpinBox.new()
	var offset_y := SpinBox.new()
	for spin in [offset_x, offset_y]:
		spin.min_value = -10000
		spin.max_value = 10000
		spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		offset_row.add_child(spin)
	offset_x.prefix = "x"
	offset_y.prefix = "y"
	offset_x.value = _resource.offset.x
	offset_y.value = _resource.offset.y
	var follow := _check(Text.t("Continuar acompanhando o alvo"), _resource.follow)
	_form = form_backup
	var zoom_box := VBoxContainer.new()
	_form.add_child(zoom_box)
	_form = zoom_box
	var zoom := _number(Text.t("Zoom (1 = normal, 2 = mais perto)"), _resource.zoom, 0.25, 4, 0.05, "×")
	_form = form_backup
	var duration := _number(Text.t("Duração da transição"), _resource.duration, 0, 10, 0.05, "s")
	var wait := _check(Text.t("Esperar a câmera chegar"), _resource.wait)
	var refresh := func(index: int) -> void:
		focus_box.visible = index == 0
		zoom_box.visible = index == 1
	mode.item_selected.connect(refresh)
	refresh.call(mode.selected)
	_collect = func() -> Variant:
		_resource.mode = mode.selected
		_resource.target = who[0].selected
		_resource.node_path = NodePath(who[1].text.strip_edges())
		_resource.offset = Vector2(offset_x.value, offset_y.value)
		_resource.follow = follow.button_pressed
		_resource.zoom = zoom.value
		_resource.duration = duration.value
		_resource.wait = wait.button_pressed
		if not _resource.is_valid():
			return Text.t("Escreva o caminho do nó alvo.")
		return {"command": _resource}


func _build_animation() -> void:
	var who := _target_picker(Text.t("Em quem?"), _resource.target, _resource.node_path)
	var animation := _line(Text.t("Nome da animação"), _resource.animation, "ex.: acenar")
	_hint(Text.t("Funciona com AnimatedSprite2D, AnimationPlayer ou o método cutscene_play_animation do personagem."))
	var speed := _number(Text.t("Velocidade"), _resource.speed, 0.1, 4, 0.1, "×")
	var wait := _check(Text.t("Esperar a animação terminar"), _resource.wait)
	_collect = func() -> Variant:
		if animation.text.strip_edges().is_empty():
			return Text.t("Escreva o nome da animação.")
		_resource.target = who[0].selected
		_resource.node_path = NodePath(who[1].text.strip_edges())
		_resource.animation = animation.text.strip_edges()
		_resource.speed = speed.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_sound() -> void:
	_label(Text.t("Arquivo de som"))
	var picker := EditorResourcePicker.new()
	picker.base_type = "AudioStream"
	picker.edited_resource = _resource.sound
	picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_form.add_child(picker)
	var volume := _number(Text.t("Volume"), _resource.volume_db, -40, 12, 0.5, "dB")
	var pitch := _number(Text.t("Tom"), _resource.pitch, 0.25, 4, 0.05, "×")
	var wait := _check(Text.t("Esperar o som terminar"), _resource.wait)
	_collect = func() -> Variant:
		if picker.edited_resource == null:
			return Text.t("Escolha um arquivo de som.")
		_resource.sound = picker.edited_resource
		_resource.volume_db = volume.value
		_resource.pitch = pitch.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_transfer() -> void:
	_label(Text.t("Cena de destino (vazio = esta cena)"))
	var row := HBoxContainer.new()
	_form.add_child(row)
	var scene := LineEdit.new()
	scene.name = "DestinationScene"
	scene.text = _resource.scene
	scene.placeholder_text = "res://fases/floresta.tscn"
	scene.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(scene)
	var browse := Button.new()
	browse.text = Text.t("Escolher…")
	browse.pressed.connect(func() -> void: _browse(["*.tscn,*.scn;Cenas"], func(path: String) -> void: scene.text = path))
	row.add_child(browse)
	var same_map := Button.new()
	same_map.text = Text.t("Este mapa")
	same_map.pressed.connect(func() -> void: scene.text = "")
	row.add_child(same_map)
	var visual := _check(Text.t("Usar posição marcada no mapa"), _resource.use_position or _resource.spawn_point.is_empty())
	visual.name = "UsePosition"
	var position_box := VBoxContainer.new()
	_form.add_child(position_box)
	var mark := Button.new()
	mark.name = "ChooseArrival"
	mark.text = Text.t("Marcar chegada no mapa…")
	position_box.add_child(mark)
	var status := Label.new()
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	position_box.add_child(status)
	var draft := {"configured": _resource.use_position, "point": _resource.arrival_position}
	var update := func() -> void:
		status.text = ("X: %.0f   Y: %.0f" % [draft.point.x, draft.point.y]) if draft.configured else Text.t("Nenhum ponto marcado. Clique em Marcar chegada no mapa.")
	update.call()
	var spawn := _line(Text.t("Ponto de chegada (nome de um nó da cena, ex.: um Marker2D)"), _resource.spawn_point, "Entrada")
	var spawn_label: Node = _form.get_child(_form.get_child_count() - 2)
	var switch_mode := func() -> void:
		position_box.visible = visual.button_pressed
		spawn.visible = not visual.button_pressed
		spawn_label.visible = not visual.button_pressed
	visual.toggled.connect(func(_value: bool) -> void: switch_mode.call())
	switch_mode.call()
	var facing := _option(Text.t("Virar para"), ["Manter", "Direita", "Esquerda", "Cima", "Baixo"], _resource.facing)
	facing.name = "ArrivalFacing"
	var use_fade := _check(Text.t("Usar fade na transferência"), _resource.fade_time > 0.0)
	use_fade.name = "UseFade"
	var fade := _number(Text.t("Duração do fade (cada etapa)"), _resource.fade_time if _resource.fade_time > 0.0 else 0.3, 0.05, 3, 0.05, "s")
	fade.name = "FadeDuration"
	fade.allow_greater = false
	fade.editable = use_fade.button_pressed
	use_fade.toggled.connect(func(value: bool) -> void: fade.editable = value)
	mark.pressed.connect(func() -> void:
		var destination := preload("res://addons/kitchen_events/editor/ke_destination_dialog.gd").new()
		_form.add_child(destination)
		destination.destination_chosen.connect(func(point: Vector2) -> void:
			draft.point = point
			draft.configured = true
			update.call())
		destination.open_map(scene.text.strip_edges(), draft.point, draft.configured, facing.selected))
	scene.text_changed.connect(func(_text: String) -> void:
		draft.configured = false
		update.call())
	_hint(Text.t("A transferência encerra o evento."))
	_collect = func() -> Variant:
		if visual.button_pressed and not draft.configured:
			return Text.t("Marque a chegada no mapa antes de concluir o comando.")
		if not visual.button_pressed and scene.text.strip_edges().is_empty() and spawn.text.strip_edges().is_empty():
			return Text.t("Escolha a cena ou o ponto de chegada.")
		_resource.scene = scene.text.strip_edges()
		_resource.spawn_point = spawn.text.strip_edges()
		_resource.use_position = visual.button_pressed
		_resource.arrival_position = draft.point
		_resource.facing = facing.selected
		_resource.fade_time = fade.value if use_fade.button_pressed else 0.0
		return {"command": _resource}


func _build_call() -> void:
	var path := _line(Text.t("Nó (caminho a partir do evento, ou absoluto)"), str(_resource.node_path), "/root/Inventario")
	var method := _line(Text.t("Método"), _resource.method, "dar_item")
	var arguments := _line(Text.t("Argumentos, separados por vírgula"), _format_arguments(_resource.arguments), "\"pocao\", 2, true")
	var wait := _check(Text.t("Esperar o método terminar (quando ele usa await)"), _resource.wait)
	_collect = func() -> Variant:
		if path.text.strip_edges().is_empty() or method.text.strip_edges().is_empty():
			return Text.t("Escreva o nó e o método.")
		var parsed: Variant = _parse_arguments(arguments.text)
		if parsed == null:
			return Text.t("Argumentos inválidos. Use textos entre aspas, números, true ou false.")
		_resource.node_path = NodePath(path.text.strip_edges())
		_resource.method = method.text.strip_edges()
		_resource.arguments = parsed
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_signal() -> void:
	var signal_name := _line(Text.t("Nome do sinal"), _resource.signal_name, "porta_aberta")
	var arguments := _line(Text.t("Argumentos, separados por vírgula"), _format_arguments(_resource.arguments), "")
	_hint(Text.t("Conecte o sinal command_signal do evento na sua cena para reagir pelo código."))
	_collect = func() -> Variant:
		if signal_name.text.strip_edges().is_empty():
			return Text.t("Escreva o nome do sinal.")
		var parsed: Variant = _parse_arguments(arguments.text)
		if parsed == null:
			return Text.t("Argumentos inválidos. Use textos entre aspas, números, true ou false.")
		_resource.signal_name = signal_name.text.strip_edges()
		_resource.arguments = parsed
		return {"command": _resource}


func _build_balloon() -> void:
	var who := _target_picker(Text.t("Acima de quem?"), _resource.target, _resource.node_path)
	_label(Text.t("Balão"))
	var grid := GridContainer.new()
	grid.columns = 3
	_form.add_child(grid)
	var group := ButtonGroup.new()
	var buttons: Array[Button] = []
	for i in BalloonCommand.KIND_NAMES.size():
		var button := Button.new()
		button.text = Text.t(BalloonCommand.KIND_NAMES[i])
		button.toggle_mode = true
		button.button_group = group
		button.button_pressed = i == _resource.balloon
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(button)
		buttons.append(button)
	var duration := _number(Text.t("Tempo na tela"), _resource.duration, 0.2, 10, 0.1, "s")
	var wait := _check(Text.t("Esperar o balão sumir"), _resource.wait)
	_collect = func() -> Variant:
		if who[0].selected == Context.Target.NODE and who[1].text.strip_edges().is_empty():
			return Text.t("Escreva o caminho do nó.")
		_resource.target = who[0].selected
		_resource.node_path = NodePath(who[1].text.strip_edges())
		for i in buttons.size():
			if buttons[i].button_pressed:
				_resource.balloon = i
		_resource.duration = duration.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_screen() -> void:
	var effect := _option(Text.t("Efeito"), ScreenCommand.EFFECT_NAMES, _resource.effect)
	var color_label := _label(Text.t("Cor"))
	var color := ColorPickerButton.new()
	color.color = _resource.color
	color.custom_minimum_size.y = 28
	_form.add_child(color)
	var strength_box := VBoxContainer.new()
	_form.add_child(strength_box)
	var form_backup := _form
	_form = strength_box
	var strength := _number(Text.t("Força do tremor"), _resource.strength, 1, 64, 1, "px")
	_form = form_backup
	var duration := _number(Text.t("Duração"), _resource.duration, 0, 10, 0.05, "s")
	var wait := _check(Text.t("Esperar o efeito terminar"), _resource.wait)
	var hint := _hint("")
	var hints := [
		Text.t("A tela fica coberta até um Clarear. Falas continuam aparecendo por cima."),
		Text.t("Tira o escurecimento."),
		Text.t("Um clarão rápido da cor escolhida (branco para impacto, vermelho para dano)."),
		Text.t("Treme a câmera."),
		Text.t("Pinta o mundo com a cor (azul-escuro para noite, laranja para entardecer). Continua até Remover tinta."),
		Text.t("Volta às cores normais."),
	]
	var refresh := func(index: int) -> void:
		var uses_color: bool = index in [ScreenCommand.Effect.FADE_OUT, ScreenCommand.Effect.FLASH, ScreenCommand.Effect.TINT]
		color_label.visible = uses_color
		color.visible = uses_color
		strength_box.visible = index == ScreenCommand.Effect.SHAKE
		hint.text = hints[index]
		if index == ScreenCommand.Effect.TINT and color.color == Color.BLACK:
			color.color = Color("7a86c8")
		elif index == ScreenCommand.Effect.FLASH and color.color == Color.BLACK:
			color.color = Color.WHITE
	effect.item_selected.connect(refresh)
	refresh.call(effect.selected)
	_collect = func() -> Variant:
		_resource.effect = effect.selected
		_resource.color = color.color
		_resource.strength = strength.value
		_resource.duration = duration.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_image() -> void:
	var action := _option(Text.t("Ação"), ["Mostrar imagem", "Apagar imagem"], _resource.action)
	var slot := _number(Text.t("Número da imagem (1 a 10; o mesmo número troca a imagem)"), _resource.slot, 1, 10, 1)
	var show_box := VBoxContainer.new()
	_form.add_child(show_box)
	var form_backup := _form
	_form = show_box
	_label(Text.t("Imagem"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	_form.add_child(row)
	var preview := TextureRect.new()
	preview.custom_minimum_size = Vector2(72, 72)
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	preview.texture = _resource.image
	row.add_child(preview)
	var picked: Array = [_resource.image]
	var browse := Button.new()
	browse.text = Text.t("Escolher imagem…")
	browse.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	browse.pressed.connect(func() -> void: _browse(["*.png,*.webp,*.jpg,*.jpeg,*.svg,*.tres;Imagens"], func(path: String) -> void:
		var texture := load(path) as Texture2D
		if texture != null:
			picked[0] = texture
			preview.texture = texture))
	row.add_child(browse)
	var centered := _check(Text.t("No centro da tela"), _resource.centered)
	var position_row := HBoxContainer.new()
	_form.add_child(position_row)
	var pos_x := SpinBox.new()
	var pos_y := SpinBox.new()
	for spin in [pos_x, pos_y]:
		spin.min_value = -10000
		spin.max_value = 10000
		spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		position_row.add_child(spin)
	pos_x.prefix = "x"
	pos_y.prefix = "y"
	pos_x.value = _resource.position.x
	pos_y.value = _resource.position.y
	position_row.visible = not centered.button_pressed
	centered.toggled.connect(func(value: bool) -> void: position_row.visible = not value)
	var scale := _number(Text.t("Escala"), _resource.scale, 0.1, 10, 0.05, "×")
	_form = form_backup
	var fade := _number(Text.t("Aparecer / sumir em"), _resource.fade_time, 0, 5, 0.05, "s")
	var wait := _check(Text.t("Esperar terminar"), _resource.wait)
	_hint(Text.t("A imagem continua na tela depois do evento, até um Apagar imagem com o mesmo número."))
	action.item_selected.connect(func(index: int) -> void: show_box.visible = index == 0)
	show_box.visible = action.selected == 0
	_collect = func() -> Variant:
		if action.selected == 0 and picked[0] == null:
			return Text.t("Escolha a imagem.")
		_resource.action = action.selected
		_resource.slot = int(slot.value)
		_resource.image = picked[0]
		_resource.centered = centered.button_pressed
		_resource.position = Vector2(pos_x.value, pos_y.value)
		_resource.scale = scale.value
		_resource.fade_time = fade.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_music() -> void:
	var action := _option(Text.t("Ação"), MusicCommand.ACTION_NAMES, _resource.action)
	var play_box := VBoxContainer.new()
	_form.add_child(play_box)
	var form_backup := _form
	_form = play_box
	_label(Text.t("Música"))
	var picker := EditorResourcePicker.new()
	picker.base_type = "AudioStream"
	picker.edited_resource = _resource.music
	picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_form.add_child(picker)
	var volume := _number(Text.t("Volume"), _resource.volume_db, -40, 12, 0.5, "dB")
	var pause_game := _check(Text.t("Pausar a música do jogo enquanto esta toca"), _resource.pause_game_music)
	_form = form_backup
	var fade := _number(Text.t("Fade"), _resource.fade_time, 0, 10, 0.1, "s")
	var wait := _check(Text.t("Esperar o fade terminar"), _resource.wait)
	_hint(Text.t("A música toca em loop e continua depois do evento. \"Voltar à anterior\" retoma a música de antes (do evento ou do jogo)."))
	action.item_selected.connect(func(index: int) -> void: play_box.visible = index == 0)
	play_box.visible = action.selected == 0
	_collect = func() -> Variant:
		if action.selected == 0 and picker.edited_resource == null:
			return Text.t("Escolha a música.")
		_resource.action = action.selected
		_resource.music = picker.edited_resource
		_resource.volume_db = volume.value
		_resource.pause_game_music = pause_game.button_pressed
		_resource.fade_time = fade.value
		_resource.wait = wait.button_pressed
		return {"command": _resource}


func _build_common() -> void:
	var library := Settings.common_events()
	var events: Array = library.events if library != null else []
	_label(Text.t("Qual evento comum?"))
	var option := OptionButton.new()
	var selected := -1
	for i in events.size():
		var name: String = events[i].page_name if not events[i].page_name.is_empty() else Text.t("(sem nome)")
		option.add_item(name)
		if events[i].page_id == _resource.common_id:
			selected = i
	if events.is_empty():
		option.add_item(Text.t("Nenhum evento comum ainda"))
		option.disabled = true
	option.select(maxi(selected, 0))
	_form.add_child(option)
	_hint(Text.t("Crie e edite os eventos comuns em Projeto > Ferramentas > Kitchen Events: eventos comuns…, ou pelo botão Eventos comuns… no Inspector de um evento. Switches locais dentro do evento comum valem para o evento que chamou."))
	_collect = func() -> Variant:
		if events.is_empty():
			return Text.t("Crie um evento comum primeiro.")
		var chosen: Resource = events[option.selected]
		_resource.common_id = chosen.page_id
		_resource.common_name = chosen.page_name
		return {"command": _resource}


func _build_inspector() -> void:
	_hint(Text.t("Comando personalizado: edite os campos abaixo."))
	_inspector = EditorInspector.new()
	_inspector.custom_minimum_size.y = 320
	_inspector.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_form.add_child(_inspector)
	_inspector.edit(_resource)
	_collect = func() -> Variant:
		if not _resource.is_valid():
			return Text.t("Preencha os campos deste comando ou use Descartar edição.")
		return {"command": _resource}


static func _format_arguments(values: Array) -> String:
	var parts: Array[String] = []
	for value in values:
		parts.append(var_to_str(value))
	return ", ".join(parts)


static func _parse_arguments(text: String) -> Variant:
	var result: Array = []
	if text.strip_edges().is_empty():
		return result
	var expression := Expression.new()
	if expression.parse("[" + text + "]") != OK:
		return null
	var value: Variant = expression.execute([], null, false, true)
	return value if not expression.has_execute_failed() and value is Array else null


func _browse(filters: Array, on_selected: Callable) -> void:
	if not is_instance_valid(_file_dialog):
		_file_dialog = EditorFileDialog.new()
		_file_dialog.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_ALWAYS
		_file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_FILE
		_file_dialog.access = EditorFileDialog.ACCESS_RESOURCES
		_file_dialog.file_selected.connect(func(path: String) -> void:
			if _file_target.is_valid():
				_file_target.call(path))
		add_child(_file_dialog)
	_file_dialog.filters = PackedStringArray(filters)
	_file_target = on_selected
	_file_dialog.popup_file_dialog()


# --- Concluir -------------------------------------------------------------------

func _accept() -> bool:
	if not active:
		return true
	if is_instance_valid(_inspector):
		_inspector.edit(null)
	var result: Variant = _collect.call()
	if result is String:
		_error.text = result
		if kind == "custom":
			_inspector.edit(_resource)
		return false
	var changed: bool = _is_new or _finish_mode != result.has("finish") or _signature(_resource) != _signature(_initial)
	clear_editor()
	if changed:
		accepted.emit(result)
	return true


## Compares values, not instances: just browsing does not mark the event as changed.
static func _signature(value: Variant) -> Variant:
	if value is Resource:
		if not value.resource_path.is_empty() and not "::" in value.resource_path:
			return value.resource_path
		var fields := {"script": value.get_script().resource_path if value.get_script() != null else ""}
		for property in value.get_property_list():
			if property.usage & PROPERTY_USAGE_STORAGE and property.name != "script":
				fields[property.name] = _signature(value.get(property.name))
		return fields
	if value is Array:
		var values: Array = []
		for item in value:
			values.append(_signature(item))
		return values
	return value


func _build_item() -> void:
	var id := _line(Text.t("ID do item"), _resource.item_id, "chave_do_poco")
	var amount := _number(Text.t("Quantidade"), _resource.quantity, 1, 1000000, 1)
	amount.allow_greater = false
	_hint(Text.t("Usa o inventário configurado em Kitchen Events > Inventory > Provider Path."))
	_collect = func() -> Variant:
		_resource.item_id = id.text.strip_edges()
		_resource.quantity = int(amount.value)
		if not _resource.is_valid():
			return Text.t("Preencha o ID do item e uma quantidade positiva.")
		return {"command": _resource}
