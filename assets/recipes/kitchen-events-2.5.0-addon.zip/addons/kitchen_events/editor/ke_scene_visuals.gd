@tool
extends RefCounted
## Rebuild native scene nodes from serialized SceneState; never attach scripts,
## instantiate gameplay scenes, or call their constructors/ready methods.

static func read_scene(scene: PackedScene, depth: int = 0) -> Node:
	return _read_state(scene.get_state(), depth) if scene != null else null

static func _read_state(state: SceneState, depth: int) -> Node:
	if state == null or depth > 32:
		return null
	var base := state.get_base_scene_state()
	var root: Node = _read_state(base, depth + 1) if base != null else null
	for i in state.get_node_count():
		var path := state.get_node_path(i)
		var node: Node = root if i == 0 else (root.get_node_or_null(path) if root != null else null)
		if node == null:
			var instance := state.get_node_instance(i)
			if instance != null:
				node = read_scene(instance, depth + 1)
			else:
				var type := state.get_node_type(i)
				# No custom classes, scripts, signals or autoload references.
				if type != &"" and ClassDB.class_exists(type) and ClassDB.is_parent_class(type, &"Node") and ClassDB.can_instantiate(type):
					node = ClassDB.instantiate(type) as Node
				else:
					node = Node2D.new()
			if node == null:
				continue
			node.name = state.get_node_name(i)
			if i == 0:
				root = node
			else:
				var parent := root.get_node_or_null(state.get_node_path(i, true))
				if parent == null:
					node.free()
					continue
				parent.add_child(node)
		var properties := {}
		for property in node.get_property_list():
			properties[property.name] = property
		for j in state.get_node_property_count(i):
			var key := state.get_node_property_name(i, j)
			if key in [&"script", &"owner", &"process_mode"] or not properties.has(key):
				continue
			var value: Variant = state.get_node_property_value(i, j)
			if value is Script or value is Node or value is Callable or value is Signal:
				continue
			node.set(key, value)
		for group in state.get_node_groups(i):
			node.add_to_group(group)
	return root
