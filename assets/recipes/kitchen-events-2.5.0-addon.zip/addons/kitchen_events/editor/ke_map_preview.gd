@tool
extends Control
## Renderiza cópias de elementos visuais: não executa gameplay ou scripts do mapa.

signal point_selected(position: Vector2)

var viewport: SubViewport
var world: Node2D
var bounds := Rect2(-64, -64, 512, 320)
var zoom: float = 1.0
var camera_center := Vector2.ZERO
var selected_position := Vector2.ZERO
var has_point: bool = false
var facing: int = 0
var ghost: Sprite2D
var player_origin := Vector2.ZERO
var player_feet_offset := Vector2(0,15)
var player_visual_offset := Vector2.ZERO
var dragging: bool = false


func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_CROSS
	custom_minimum_size = Vector2(480, 320)
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	viewport = SubViewport.new()
	viewport.disable_3d = true
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	viewport.gui_disable_input = true
	add_child(viewport)
	resized.connect(_update_view)
	_update_view()


func show_map(source: Node2D) -> bool:
	if world != null:
		world.free()
	ghost = null
	has_point = false
	world = Node2D.new()
	world.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	viewport.add_child(world)
	var content_bounds: Array[Rect2] = []
	for child in source.get_children():
		_clone_visuals(child, world, content_bounds)
	if not content_bounds.is_empty():
		bounds = content_bounds[0]
		for rect in content_bounds:
			bounds = bounds.merge(rect)
	else:
		bounds = Rect2(-64, -64, 512, 320)
	bounds = bounds.grow(48)
	var player := _find_player(source)
	if player == null:
		player = source
	player_origin = source.global_transform.affine_inverse() * player.global_position
	var collider: CollisionShape2D
	for child in player.get_children():
		if child is CollisionShape2D and child.shape != null and not child.disabled:
			collider = child
			break
	player_feet_offset = Vector2.ZERO
	if collider!=null and collider.shape!=null:
		var collider_to_map := source.global_transform.affine_inverse()*collider.global_transform
		var body_bounds: Rect2 = collider_to_map*collider.shape.get_rect()
		player_feet_offset = Vector2(body_bounds.get_center().x, body_bounds.end.y) - player_origin
	var original: AnimatedSprite2D
	for child in player.get_children():
		if child is AnimatedSprite2D:
			original = child
			break
	player_visual_offset = Vector2.ZERO
	ghost = Sprite2D.new()
	ghost.z_index = 4095
	ghost.modulate = Color(1.1, 1.1, 1.1, 0.85)
	if original != null and original.sprite_frames != null:
		var animation := original.animation
		if original.sprite_frames.has_animation(&"idle"):
			animation = &"idle"
		if original.sprite_frames.has_animation(animation) and original.sprite_frames.get_frame_count(animation) > 0:
			ghost.texture = original.sprite_frames.get_frame_texture(animation, 0)
		ghost.offset = original.offset
		ghost.centered = original.centered
		var visual_to_map: Transform2D = source.global_transform.affine_inverse() * original.global_transform
		player_visual_offset = visual_to_map.origin - player_origin
		ghost.scale = visual_to_map.get_scale()
		ghost.rotation = visual_to_map.get_rotation()
	else:
		for child in player.get_children():
			if child is Sprite2D:
				ghost.texture = child.texture
				ghost.hframes = child.hframes
				ghost.vframes = child.vframes
				ghost.frame = child.frame
				ghost.offset = child.offset
				ghost.centered = child.centered
				var visual_to_map: Transform2D = source.global_transform.affine_inverse() * child.global_transform
				player_visual_offset = visual_to_map.origin - player_origin
				ghost.scale = visual_to_map.get_scale()
				ghost.rotation = visual_to_map.get_rotation()
				break
	world.add_child(ghost)
	fit_map()
	set_point(player_origin, false)
	return true


func _find_player(node: Node) -> Node2D:
	if node is CharacterBody2D and (node.is_in_group("player") or String(node.name).to_lower() in ["player", "tommy", "jogador", "hero"]):
		return node as Node2D
	for child in node.get_children():
		var found := _find_player(child)
		if found != null:
			return found
	return null


func _clone_visuals(source: Node, parent: Node2D, rectangles: Array[Rect2]) -> void:
	# UI, parallax e câmeras não fazem parte da geometria usada para escolher o chão.
	if source is CanvasLayer or source is Camera2D or source is Parallax2D or source is Control or source is CollisionShape2D:
		return
	var copy: Node2D
	if source is TileMapLayer:
		var tiles := TileMapLayer.new()
		tiles.tile_set = source.tile_set
		tiles.collision_enabled = false
		tiles.navigation_enabled = false
		tiles.occlusion_enabled = false
		for cell in source.get_used_cells():
			tiles.set_cell(cell, source.get_cell_source_id(cell), source.get_cell_atlas_coords(cell), source.get_cell_alternative_tile(cell))
		copy = tiles
	elif source is Sprite2D:
		var sprite := Sprite2D.new()
		for property in ["texture", "centered", "offset", "hframes", "vframes", "frame", "flip_h", "flip_v", "region_enabled", "region_rect"]:
			sprite.set(property, source.get(property))
		copy = sprite
	elif source is AnimatedSprite2D:
		var sprite := Sprite2D.new()
		if source.sprite_frames != null and source.sprite_frames.has_animation(source.animation) and source.sprite_frames.get_frame_count(source.animation) > 0:
			sprite.texture = source.sprite_frames.get_frame_texture(source.animation, source.frame)
			sprite.centered = source.centered
			sprite.offset = source.offset
			sprite.flip_h = source.flip_h
		copy = sprite
	else:
		copy = Node2D.new()
	parent.add_child(copy)
	if source is Node2D:
		copy.transform = source.transform
		copy.visible = source.visible
		copy.z_index = source.z_index
		copy.z_as_relative = source.z_as_relative
		copy.modulate = source.modulate
		copy.self_modulate = source.self_modulate
	if copy is TileMapLayer and copy.tile_set != null and not copy.get_used_cells().is_empty():
		var cells: Rect2i = copy.get_used_rect()
		var tile_size: Vector2 = Vector2(copy.tile_set.tile_size)
		rectangles.append(copy.global_transform * Rect2(Vector2(cells.position) * tile_size, Vector2(cells.size) * tile_size))
	elif copy is Sprite2D and copy.texture != null and copy.is_visible_in_tree():
		rectangles.append(copy.global_transform * copy.get_rect())
	for child in source.get_children():
		_clone_visuals(child, copy, rectangles)


func set_point(at: Vector2, configured: bool = true) -> void:
	selected_position = at
	has_point = configured
	if is_instance_valid(ghost):
		ghost.position = at+player_visual_offset
		ghost.flip_h = facing == 1
		ghost.visible = configured
	queue_redraw()


func fit_map() -> void:
	camera_center = bounds.get_center()
	zoom = clampf(minf(size.x / maxf(bounds.size.x, 1), size.y / maxf(bounds.size.y, 1)) * 0.92, 0.05, 12)
	_update_view()


func screen_to_map(at: Vector2) -> Vector2:
	return (at - size / 2) / zoom + camera_center


func map_to_screen(at: Vector2) -> Vector2:
	return (at - camera_center) * zoom + size / 2


func zoom_at(factor: float, at: Vector2) -> void:
	var anchor := screen_to_map(at)
	zoom = clampf(zoom * factor, 0.05, 12)
	camera_center = anchor - (at - size / 2) / zoom
	_update_view()


func _update_view() -> void:
	if viewport == null:
		return
	viewport.size = Vector2i(maxi(roundi(size.x), 1), maxi(roundi(size.y), 1))
	viewport.canvas_transform = Transform2D(Vector2(zoom, 0), Vector2(0, zoom), size / 2 - camera_center * zoom)
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_MIDDLE:
			dragging = event.pressed
		elif event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
			zoom_at(1.2 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 1.0 / 1.2, event.position)
		elif event.pressed and event.button_index == MOUSE_BUTTON_LEFT and world != null and ghost != null:
			# O clique marca os pés; a posição gravada é a origem do corpo do Tommy.
			var feet := screen_to_map(event.position).round()
			set_point(feet - player_feet_offset)
			point_selected.emit(selected_position)
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		camera_center -= event.relative / zoom
		_update_view()
		accept_event()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("202d35"))
	if viewport == null:
		return
	var grid: float = maxf(16.0, pow(2.0, ceil(log(24.0 / zoom) / log(2.0))))
	var top_left := screen_to_map(Vector2.ZERO)
	var bottom_right := screen_to_map(size)
	for x in range(floori(top_left.x / grid), ceili(bottom_right.x / grid) + 1):
		var screen_x := map_to_screen(Vector2(x * grid, 0)).x
		draw_line(Vector2(screen_x, 0), Vector2(screen_x, size.y), Color(1, 1, 1, 0.035))
	for y in range(floori(top_left.y / grid), ceili(bottom_right.y / grid) + 1):
		var screen_y := map_to_screen(Vector2(0, y * grid)).y
		draw_line(Vector2(0, screen_y), Vector2(size.x, screen_y), Color(1, 1, 1, 0.035))
	draw_texture_rect(viewport.get_texture(), Rect2(Vector2.ZERO, size), false)
	if has_point:
		var feet := map_to_screen(selected_position + player_feet_offset)
		var gold := Color("ffd77a")
		draw_arc(feet, 10, 0, TAU, 32, gold, 2, true)
		draw_line(feet - Vector2(17, 0), feet + Vector2(17, 0), gold, 2, true)
		draw_line(feet - Vector2(0, 7), feet + Vector2(0, 7), gold, 2, true)
		draw_rect(Rect2(map_to_screen(selected_position + Vector2(-5, -3)), Vector2(12, 18) * zoom), Color(1, 0.85, 0.48, 0.9), false, 1)
