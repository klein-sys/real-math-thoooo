@tool
extends ConfirmationDialog
signal destination_chosen(point: Vector2)
const Preview = preload("res://addons/kitchen_events/editor/ke_map_preview.gd")
const Visuals = preload("res://addons/kitchen_events/editor/ke_scene_visuals.gd")
const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Theme_ = preload("res://addons/kitchen_events/editor/ke_panel_theme.gd")
var preview: Control
var status: Label

func _ready() -> void:
	title = Text.t("Marcar chegada no mapa")
	Theme_.apply(self)
	dialog_hide_on_ok = false
	get_ok_button().text = Text.t("Usar este ponto")
	get_cancel_button().text = Text.t("Cancelar")
	var column := VBoxContainer.new()
	add_child(column)
	var hint := Label.new()
	hint.text = Text.t("Clique no chão para marcar os pés. Roda: zoom. Botão do meio: mover a prévia.")
	hint.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	hint.custom_minimum_size.x = 400
	hint.tooltip_text = hint.text
	column.add_child(hint)
	preview = Preview.new()
	column.add_child(preview)
	var fit := Button.new()
	fit.text = Text.t("Ver mapa inteiro")
	fit.pressed.connect(preview.fit_map)
	column.add_child(fit)
	status = Label.new()
	status.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	status.custom_minimum_size.x = 400
	column.add_child(status)
	preview.point_selected.connect(func(point: Vector2) -> void:
		status.text = "X: %.0f   Y: %.0f" % [point.x, point.y]
		get_ok_button().disabled = false)
	confirmed.connect(func() -> void:
		if preview.has_point:
			destination_chosen.emit(preview.selected_position)
			hide())
	visibility_changed.connect(func() -> void:
		if is_instance_valid(preview):
			preview.viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS if visible else SubViewport.UPDATE_DISABLED)

func open_map(path: String, point: Vector2, configured: bool, facing: int) -> void:
	var source: Node2D
	var own := false
	var edited := EditorInterface.get_edited_scene_root()
	if path.is_empty() or (edited != null and edited.scene_file_path == path):
		source = edited as Node2D
	elif ResourceLoader.exists(path, "PackedScene"):
		var native := Visuals.read_scene(load(path) as PackedScene)
		source = native as Node2D
		own = source != null
		if native != null and source == null:
			native.free()
	Theme_.popup(self, Vector2i(1000, 720), Vector2i(640, 480))
	get_ok_button().disabled = true
	if source == null:
		preview.hide()
		status.text = Text.t("Escolha uma cena 2D válida. Salve o mapa de destino antes de abrir a prévia.")
		return
	preview.show()
	preview.show_map(source)
	preview.facing = 1 if facing == 2 else 0
	if own:
		source.free()
	preview.fit_map.call_deferred()
	if configured:
		preview.set_point(point)
		get_ok_button().disabled = false
	status.text = Text.t("Marque a chegada em espaço livre. A prévia não testa colisões.")
