@tool
extends EditorInspectorPlugin
## Puts "Edit event…" at the top of the Inspector of every KEEvent.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Event = preload("res://addons/kitchen_events/runtime/ke_event.gd")
const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")

var plugin: EditorPlugin


func _can_handle(object: Object) -> bool:
	return object is Event


func _parse_begin(object: Object) -> void:
	var event: Node = object
	var column := VBoxContainer.new()
	column.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_DISABLED
	column.add_theme_constant_override("separation", 4)

	var heading := Label.new()
	heading.text = Text.t("Evento interativo")
	heading.add_theme_font_size_override("font_size", 16)
	column.add_child(heading)

	var summary := Label.new()
	summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	summary.custom_minimum_size.x = 120
	summary.text = _summary(event)
	column.add_child(summary)

	var open := Button.new()
	open.text = Text.t("Editar evento…")
	open.icon = EditorInterface.get_editor_theme().get_icon(&"Edit", &"EditorIcons")
	open.pressed.connect(plugin.open_event.bind(weakref(event)))
	column.add_child(open)
	var common := Button.new()
	common.text = Text.t("Eventos comuns…")
	common.tooltip_text = Text.t("Sequências que qualquer evento pode chamar com \"Chamar evento comum\".")
	common.pressed.connect(plugin.open_common_events)
	column.add_child(common)

	var row := HBoxContainer.new()
	column.add_child(row)
	var raw := CheckBox.new()
	raw.text = Text.t("Mostrar propriedades avançadas")
	raw.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	raw.button_pressed = plugin.show_raw_data
	raw.toggled.connect(func(value: bool) -> void: plugin.set_show_raw_data.call_deferred(weakref(event), value))
	row.add_child(raw)
	var new_id := Button.new()
	new_id.text = Text.t("Novo id")
	new_id.tooltip_text = Text.t("Dá um novo id ao evento. Switches locais e contadores já salvos deixam de valer para ele.")
	new_id.pressed.connect(plugin.regenerate_id.bind(weakref(event)))
	row.add_child(new_id)
	add_custom_control(column)


func _summary(event: Node) -> String:
	if event.pages.is_empty():
		return Text.t("Ainda sem páginas. Clique em Editar evento… para começar.")
	var lines: Array[String] = []
	for i in event.pages.size():
		var page: Resource = event.pages[i]
		if page == null:
			continue
		var trigger: String = [Text.t("botão"), Text.t("ao tocar"), Text.t("automático"), Text.t("paralelo")][page.trigger]
		var name: String = page.page_name if not page.page_name.is_empty() else Text.t("Página %d") % (i + 1)
		lines.append("%d. %s · %s · %d %s" % [i + 1, name, trigger, page.commands.size(), Text.t("comando(s)")])
	return "\n".join(lines)


func _parse_property(_object: Object, _type: Variant.Type, name: String, _hint: PropertyHint, _hint_text: String, _usage: int, _wide: bool) -> bool:
	return name == "pages" and not plugin.show_raw_data
