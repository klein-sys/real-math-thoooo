@tool
extends ConfirmationDialog
## "Characters" window: name, portrait and name color of each character.
## Lines with an automatic portrait use this list. Saved to the file set in
## Project Settings > Kitchen Events > Editor > Cast.

signal saved

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const Cast = preload("res://addons/kitchen_events/core/ke_cast.gd")
const Member = preload("res://addons/kitchen_events/core/ke_cast_member.gd")

var _list: VBoxContainer
var _members: Array = []
var _file_dialog: EditorFileDialog
var _picking: Resource


func _init() -> void:
	# The texts are already in the chosen language; the editor must not translate them again.
	auto_translate_mode = AUTO_TRANSLATE_MODE_DISABLED
	title = Text.t("Personagens")
	min_size = Vector2i(560, 420)
	get_ok_button().text = Text.t("Salvar")
	get_cancel_button().text = Text.t("Cancelar")
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	add_child(column)
	var hint := Label.new()
	hint.text = Text.t("Falas com retrato \"Automático pelo personagem\" usam o retrato e a cor cadastrados aqui.")
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.custom_minimum_size.x = 400
	column.add_child(hint)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size.y = 240
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 6)
	scroll.add_child(_list)
	var add := Button.new()
	add.text = Text.t("+ Personagem")
	add.pressed.connect(func() -> void:
		_members.append(Member.new())
		_rebuild())
	column.add_child(add)
	confirmed.connect(_save)


func open() -> void:
	_members.clear()
	var cast := Settings.cast()
	if cast != null:
		for member in cast.members:
			if member != null:
				_members.append(member.duplicate())
	if _members.is_empty():
		_members.append(Member.new())
	_rebuild()
	popup_centered(Vector2i(Vector2(620, 460) * EditorInterface.get_editor_scale()))


func _rebuild() -> void:
	for child in _list.get_children():
		_list.remove_child(child)
		child.queue_free()
	for i in _members.size():
		var member: Resource = _members[i]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		_list.add_child(row)
		var preview := TextureRect.new()
		preview.custom_minimum_size = Vector2(48, 48)
		preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		preview.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		preview.texture = member.portrait
		row.add_child(preview)
		var name_edit := LineEdit.new()
		name_edit.text = member.name
		name_edit.placeholder_text = Text.t("Nome")
		name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_edit.text_changed.connect(func(text: String) -> void: member.name = text.strip_edges())
		row.add_child(name_edit)
		var color := ColorPickerButton.new()
		color.color = member.name_color
		color.custom_minimum_size = Vector2(40, 0)
		color.tooltip_text = Text.t("Cor do nome")
		color.color_changed.connect(func(value: Color) -> void: member.name_color = value)
		row.add_child(color)
		var pick := Button.new()
		pick.text = Text.t("Retrato…")
		pick.pressed.connect(func() -> void: _pick_portrait(member))
		row.add_child(pick)
		var remove := Button.new()
		remove.text = "×"
		remove.pressed.connect(func() -> void:
			_members.remove_at(i)
			_rebuild())
		row.add_child(remove)


func _pick_portrait(member: Resource) -> void:
	_picking = member
	if not is_instance_valid(_file_dialog):
		_file_dialog = EditorFileDialog.new()
		_file_dialog.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_ALWAYS
		_file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_FILE
		_file_dialog.access = EditorFileDialog.ACCESS_RESOURCES
		_file_dialog.filters = PackedStringArray(["*.png,*.webp,*.jpg,*.jpeg,*.svg,*.tres;Imagens"])
		_file_dialog.file_selected.connect(func(path: String) -> void:
			var texture := load(path) as Texture2D
			if texture != null and _picking != null:
				_picking.portrait = texture
				_rebuild())
		add_child(_file_dialog)
	_file_dialog.popup_file_dialog()


func _save() -> void:
	var cast := Cast.new()
	for member in _members:
		if not member.name.is_empty():
			cast.members.append(member)
	var path := String(Settings.get_value("editor/cast"))
	if ResourceSaver.save(cast, path) != OK:
		push_error(Text.t("Kitchen Events: não foi possível salvar ") + path)
		return
	cast.take_over_path(path)
	EditorInterface.get_resource_filesystem().update_file(path)
	saved.emit()
