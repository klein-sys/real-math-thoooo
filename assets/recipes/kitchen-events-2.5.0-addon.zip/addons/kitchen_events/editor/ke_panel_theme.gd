@tool
extends RefCounted
## Blue-grey theme of the event editor. Only the event window uses this
## theme; the rest of the Godot editor does not change.

const BACKGROUND := Color("1b2838")
const PANEL := Color("2b3d52")
const FIELD := Color("203044")
const BORDER := Color("7692b0")
const SELECTION := Color("376da7")
const TEXT := Color("e5edf6")
const MUTED := Color("b0c1d4")
const FOCUS := Color("9acbff")
const HEADING := Color("c2d8ec")
const ERROR := Color("ffb3a4")

## Command list colors, by category.
const ROW_COLORS := {
	"Message": Color("9cddd6"),
	"State": Color("efd59b"),
	"Flow": Color("f0b4d4"),
	"Character": Color("e5edf6"),
	"Camera": Color("a9c8ff"),
	"Screen": Color("c7b3ff"),
	"Audio": Color("ffc09a"),
	"Scene": Color("8fe3c4"),
	"Advanced": Color("c9d3df"),
	"wait": Color("c8b8e9"),
	"finish": Color("efd59b"),
	"header": Color("8ea4bc"),
}


static func box(fill: Color, border: Color, width: int = 1, reference: StyleBox = null) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(4)
	for side in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]:
		style.set_content_margin(side, reference.get_content_margin(side) if reference != null else 4.0)
	return style


static func build(base: Theme) -> Theme:
	var result := Theme.new()
	result.merge_with(base)
	var panel := box(BACKGROUND, BORDER, 1, base.get_stylebox("panel", "AcceptDialog"))
	result.set_stylebox("panel", "AcceptDialog", panel)
	result.set_stylebox("panel", "ConfirmationDialog", panel)
	result.set_stylebox("panel", "PanelContainer", box(PANEL, BORDER, 1, base.get_stylebox("panel", "PanelContainer")))
	result.set_stylebox("panel", "PopupMenu", box(FIELD, BORDER, 1, base.get_stylebox("panel", "PopupMenu")))
	result.set_stylebox("hover", "PopupMenu", box(SELECTION, FOCUS, 1, base.get_stylebox("hover", "PopupMenu")))
	for type in ["Label", "Button", "OptionButton", "MenuButton", "CheckBox", "LineEdit", "TextEdit", "ItemList", "PopupMenu", "SpinBox"]:
		result.set_color("font_color", type, TEXT)
		result.set_color("font_hover_color", type, Color.WHITE)
		result.set_color("font_focus_color", type, Color.WHITE)
		result.set_color("font_pressed_color", type, Color.WHITE)
		result.set_color("font_disabled_color", type, Color("8094aa"))
		result.set_color("font_placeholder_color", type, MUTED)
	for type in ["Button", "OptionButton", "MenuButton"]:
		for state in ["normal", "hover", "pressed", "hover_pressed", "disabled"]:
			var fill := Color("344c66")
			var edge := BORDER
			if state == "hover":
				fill = Color("415f7f")
				edge = FOCUS
			elif state in ["pressed", "hover_pressed"]:
				fill = SELECTION
				edge = FOCUS
			elif state == "disabled":
				fill = Color("28384a")
				edge = Color("465e77")
			result.set_stylebox(state, type, box(fill, edge, 1, base.get_stylebox(state, type)))
		var focus := box(Color.TRANSPARENT, FOCUS, 2, base.get_stylebox("focus", type))
		focus.draw_center = false
		result.set_stylebox("focus", type, focus)
	for type in ["LineEdit", "TextEdit"]:
		for state in ["normal", "read_only"]:
			result.set_stylebox(state, type, box(FIELD, BORDER, 1, base.get_stylebox(state, type)))
		var field_focus := box(Color.TRANSPARENT, FOCUS, 2, base.get_stylebox("focus", type))
		field_focus.draw_center = false
		result.set_stylebox("focus", type, field_focus)
		result.set_color("selection_color", type, SELECTION)
		result.set_color("font_selected_color", type, Color.WHITE)
		result.set_color("caret_color", type, FOCUS)
	result.set_stylebox("panel", "ItemList", box(FIELD, BORDER, 1, base.get_stylebox("panel", "ItemList")))
	for state in ["selected", "selected_focus", "hovered", "hovered_focus", "hovered_selected", "hovered_selected_focus"]:
		var fill := SELECTION if "selected" in state else Color("2d4b6b")
		result.set_stylebox(state, "ItemList", box(fill, FOCUS, 1, base.get_stylebox(state, "ItemList")))
	result.set_color("font_selected_color", "ItemList", Color.WHITE)
	result.set_color("font_hovered_color", "ItemList", TEXT)
	for type in ["VScrollBar", "HScrollBar"]:
		for state in ["grabber", "grabber_highlight", "grabber_pressed"]:
			result.set_stylebox(state, type, box(BORDER if state == "grabber" else FOCUS, BORDER, 0, base.get_stylebox(state, type)))
	return result


static func apply(window: Window) -> void:
	if window.has_meta(&"ke_blue_theme") and window.theme != null:
		return
	window.theme = build(EditorInterface.get_editor_theme())
	window.set_meta(&"ke_blue_theme", true)


## Draws a column frame behind the controls, without changing the layout.
static func column(control: Control) -> void:
	if control.has_meta(&"ke_column_border"):
		return
	var style := box(PANEL, BORDER)
	control.draw.connect(func() -> void: control.draw_style_box(style, Rect2(Vector2(-3, -3), control.size + Vector2(6, 6))))
	control.resized.connect(control.queue_redraw)
	control.set_meta(&"ke_column_border", true)
	control.queue_redraw()


## Opens the window inside the available area of the editor/monitor.
static func popup(window: Window, preferred: Vector2i, minimum: Vector2i) -> void:
	var scale := EditorInterface.get_editor_scale()
	preferred = Vector2i(Vector2(preferred) * scale)
	minimum = Vector2i(Vector2(minimum) * scale)
	var available := window.get_tree().root.size
	if DisplayServer.get_name() != "headless":
		var usable := DisplayServer.screen_get_usable_rect(maxi(window.get_tree().root.current_screen, 0))
		available = Vector2i(mini(available.x, usable.size.x), mini(available.y, usable.size.y))
	available = Vector2i(maxi(available.x - 40, 320), maxi(available.y - 80, 240))
	window.max_size = Vector2i.ZERO
	window.min_size = Vector2i(mini(minimum.x, available.x), mini(minimum.y, available.y))
	window.max_size = available
	var target := Vector2i(clampi(preferred.x, window.min_size.x, available.x), clampi(preferred.y, window.min_size.y, available.y))
	window.size = target
	window.popup_centered_clamped(target, 0.95)
