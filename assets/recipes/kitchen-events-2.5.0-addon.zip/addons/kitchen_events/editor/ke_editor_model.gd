@tool
extends RefCounted
## Isolated draft of the event. Only the plugin applies the pages to the node, with Undo/Redo.

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Names = preload("res://addons/kitchen_events/core/ke_names.gd")
const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")
const Command = preload("res://addons/kitchen_events/core/ke_command.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")
const ShowText = preload("res://addons/kitchen_events/commands/ke_show_text_command.gd")
const ChangeState = preload("res://addons/kitchen_events/commands/ke_change_state_command.gd")
const Wait = preload("res://addons/kitchen_events/commands/ke_wait_command.gd")

var pages: Array = []
var selected := 0
var dirty := false


func load_pages(source: Array) -> void:
	pages = []
	for page in source:
		pages.append(copy_value(page))
	if pages.is_empty():
		pages.append(new_page())
	for page in pages:
		if page.page_id.is_empty():
			page.page_id = Names.new_id("pg")
	selected = 0
	dirty = false


func page() -> Resource:
	return pages[selected] if selected >= 0 and selected < pages.size() else null


## Copies the event data (pages, commands, conditions); images, sounds and
## scenes keep pointing to their files.
static func copy_value(value: Variant) -> Variant:
	if value is Resource:
		var resource: Resource = value
		var path := resource.resource_path
		if not path.is_empty() and not "::" in path:
			return resource
		var copy: Resource = resource.duplicate(false)
		for property in resource.get_property_list():
			if not property.usage & PROPERTY_USAGE_STORAGE or property.name == "script":
				continue
			var field: Variant = resource.get(property.name)
			if field is Resource or field is Array or field is Dictionary:
				copy.set(property.name, copy_value(field))
		return copy
	if value is Array:
		var array: Array = value.duplicate(false)
		for i in array.size():
			array[i] = copy_value(array[i])
		return array
	if value is Dictionary:
		var dictionary: Dictionary = value.duplicate(false)
		for key in dictionary:
			dictionary[key] = copy_value(dictionary[key])
		return dictionary
	return value


static func new_page() -> Resource:
	var resource: Resource = Page.new()
	resource.page_id = Names.new_id("pg")
	return resource


func add_page() -> void:
	pages.append(new_page())
	selected = pages.size() - 1
	dirty = true


func duplicate_page() -> void:
	var resource: Resource = copy_value(page())
	resource.page_id = Names.new_id("pg")
	resource.page_name = (resource.page_name + " " + Text.t("(cópia)")) if not resource.page_name.is_empty() else Text.t("Cópia")
	pages.insert(selected + 1, resource)
	selected += 1
	dirty = true


func delete_page() -> void:
	pages.remove_at(selected)
	if pages.is_empty():
		pages.append(new_page())
	selected = clampi(selected, 0, pages.size() - 1)
	dirty = true


func move_page(direction: int) -> void:
	var destination := selected + direction
	if destination < 0 or destination >= pages.size():
		return
	var resource: Resource = pages[selected]
	pages.remove_at(selected)
	pages.insert(destination, resource)
	selected = destination
	dirty = true


func edit_property(property: String, value: Variant) -> void:
	if page() == null or page().get(property) == value:
		return
	page().set(property, value)
	dirty = true


## Rows of the command list. Each row:
## {"kind": "command"|"header"|"finish", "list": Array, "index": int, "depth": int, "data": Resource, "number": int}
func rows() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var resource := page()
	if resource == null:
		return result
	var counter := [0]
	_append_list(result, resource.commands, 0, counter)
	for i in resource.finish_changes.size():
		counter[0] += 1
		result.append({"kind": "finish", "list": resource.finish_changes, "index": i, "depth": 0, "data": resource.finish_changes[i], "number": counter[0]})
	return result


func _append_list(result: Array[Dictionary], list: Array, depth: int, counter: Array) -> void:
	for i in list.size():
		var command: Resource = list[i]
		counter[0] += 1
		result.append({"kind": "command", "list": list, "index": i, "depth": depth, "data": command, "number": counter[0]})
		if command == null:
			continue
		for branch in command.get_branches():
			result.append({"kind": "header", "list": branch["commands"], "index": 0, "depth": depth + 1, "data": command, "label": branch["label"], "number": 0})
			_append_list(result, branch["commands"], depth + 2, counter)


## Text of a row, such as "Text  ·  Orb: Now try not to fall."
static func row_title(row: Dictionary) -> String:
	var resource: Resource = row["data"]
	match row["kind"]:
		"header":
			return ": " + String(row["label"])
		"finish":
			return Text.t("Ao terminar") + "  ·  " + (resource.get_summary() if resource != null else "?")
	if resource == null:
		return Text.t("Comando vazio")
	var summary: String = resource.get_summary()
	return resource.get_command_name() + ("  ·  " + summary if not summary.is_empty() else "")


static func row_category(row: Dictionary) -> String:
	match row["kind"]:
		"header":
			return "header"
		"finish":
			return "finish"
	var resource: Resource = row["data"]
	if resource is Wait:
		return "wait"
	return resource.get_category() if resource != null else "Advanced"


## Where a new command goes: after the selected row, at the start of a
## branch, or at the end of the main list (before the "On finish" rows).
func insertion_point(selection: Dictionary) -> Dictionary:
	var resource := page()
	if selection.is_empty() or selection["kind"] == "finish":
		return {"list": resource.commands, "index": resource.commands.size()}
	if selection["kind"] == "header":
		return {"list": selection["list"], "index": 0}
	return {"list": selection["list"], "index": selection["index"] + 1}


## Puts the result of a form into the draft and returns the position of the new row.
## [param result]: {"command": Resource} or {"finish": Array[KEStateChange]}.
## [param replacing]: the row being edited, or {} for a new command.
func put(result: Dictionary, replacing: Dictionary, selection: Dictionary) -> Dictionary:
	var resource := page()
	dirty = true
	if not replacing.is_empty():
		if replacing["kind"] == "finish":
			resource.finish_changes.remove_at(replacing["index"])
			if result.has("finish"):
				for i in result["finish"].size():
					resource.finish_changes.insert(replacing["index"] + i, result["finish"][i])
				return {"kind": "finish", "data": result["finish"][0]}
			resource.commands.append(result["command"])
			return {"kind": "command", "data": result["command"]}
		var list: Array = replacing["list"]
		if result.has("finish"):
			list.remove_at(replacing["index"])
			resource.finish_changes.append_array(result["finish"])
			return {"kind": "finish", "data": result["finish"][0]}
		list[replacing["index"]] = result["command"]
		return {"kind": "command", "data": result["command"]}
	if result.has("finish"):
		resource.finish_changes.append_array(result["finish"])
		return {"kind": "finish", "data": result["finish"][0]}
	var point := insertion_point(selection)
	point["list"].insert(point["index"], result["command"])
	return {"kind": "command", "data": result["command"]}


func remove_row(row: Dictionary) -> void:
	if row["kind"] == "header":
		return
	row["list"].remove_at(row["index"])
	dirty = true


func duplicate_row(row: Dictionary) -> Resource:
	if row["kind"] == "header":
		return null
	var copy: Resource = copy_value(row["data"])
	row["list"].insert(row["index"] + 1, copy)
	dirty = true
	return copy


## Moves inside the same list. Returns false when there is nowhere to go.
func move_row(row: Dictionary, direction: int) -> bool:
	if row["kind"] == "header":
		return false
	var list: Array = row["list"]
	var destination: int = row["index"] + direction
	if destination < 0 or destination >= list.size():
		return false
	var item: Variant = list[row["index"]]
	list[row["index"]] = list[destination]
	list[destination] = item
	dirty = true
	return true


## Names of global switches and variables used in the draft pages.
func used_names() -> Dictionary:
	var switches: Array[String] = []
	var variables: Array[String] = []
	var speakers: Array[String] = []
	var stack: Array = pages.duplicate()
	var seen := {}
	while not stack.is_empty():
		var item: Variant = stack.pop_back()
		if item is Array:
			stack.append_array(item)
			continue
		if not item is Resource or seen.has(item.get_instance_id()):
			continue
		seen[item.get_instance_id()] = true
		var script: Script = item.get_script()
		var global_name := script.get_global_name() if script != null else &""
		match global_name:
			&"KESwitchCondition":
				if item.scope == 1:
					_add_name(switches, item.global_switch)
			&"KEStateChange":
				if item.target == StateChange.Target.SWITCH:
					_add_name(switches, item.name)
				elif item.target == StateChange.Target.VARIABLE:
					_add_name(variables, item.name)
			&"KEVariableCondition":
				_add_name(variables, item.variable_name)
			&"KEShowTextCommand":
				_add_name(speakers, item.speaker)
		for property in item.get_property_list():
			if property.usage & PROPERTY_USAGE_STORAGE and property.name != "script":
				var field: Variant = item.get(property.name)
				if field is Array or (field is Resource and field.resource_path.is_empty()):
					stack.append(field)
	switches.sort()
	variables.sort()
	speakers.sort()
	return {"switches": switches, "variables": variables, "speakers": speakers}


static func _add_name(target: Array[String], name: String) -> void:
	if not name.strip_edges().is_empty() and not name in target:
		target.append(name)


## Error message that blocks Apply, or "".
func validation_error() -> String:
	var ids: Array[String] = []
	for index in pages.size():
		var resource: Resource = pages[index]
		if resource == null:
			continue
		if resource.page_id in ids:
			return Text.t("Duas páginas têm o mesmo identificador. Use Duplicar para copiar páginas.")
		ids.append(resource.page_id)
		for condition in resource.conditions:
			if condition == null or not condition.is_valid():
				return Text.t("Página %d: complete as condições (nome do switch global ou da variável).") % (index + 1)
		for change in resource.finish_changes:
			if change == null or not change.is_valid():
				return Text.t("Página %d: complete os switches \"Ao terminar\".") % (index + 1)
		var stack: Array = resource.commands.duplicate()
		while not stack.is_empty():
			var command: Resource = stack.pop_back()
			if command == null:
				continue
			if not command.is_valid():
				return Text.t("Página %d: há um comando incompleto (%s).") % [index + 1, command.get_command_name()]
			for branch in command.get_branches():
				stack.append_array(branch["commands"])
	return ""


## Clean copies to store in the node.
func pages_to_apply() -> Array:
	var result: Array = []
	for resource in pages:
		result.append(copy_value(resource))
	return result
