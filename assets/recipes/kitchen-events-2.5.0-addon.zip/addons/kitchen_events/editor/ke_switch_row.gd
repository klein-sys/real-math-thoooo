@tool
extends HBoxContainer
## A "Local · A · On" or "Global · name ▾ · Off" row.
## Edits a KESwitchCondition (condition) or a KEStateChange (change).

signal edited
signal removed

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const SwitchCondition = preload("res://addons/kitchen_events/conditions/ke_switch_condition.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")

var resource: Resource
var scope := OptionButton.new()
var local_id := OptionButton.new()
var global_id := LineEdit.new()
var known := MenuButton.new()
var value := OptionButton.new()
var remove_button := Button.new()
var _loading := true


func _init() -> void:
	add_theme_constant_override("separation", 5)
	for text in [Text.t("Local"), Text.t("Global")]:
		scope.add_item(text)
	for text in ["A", "B", "C", "D"]:
		local_id.add_item(text)
	global_id.placeholder_text = "nome_do_switch"
	global_id.tooltip_text = Text.t("O mesmo nome compartilha o switch entre eventos e mapas.")
	global_id.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	global_id.custom_minimum_size.x = 90
	known.text = "▾"
	known.tooltip_text = Text.t("Switches já usados nesta cena e neste evento")
	remove_button.text = "×"
	remove_button.tooltip_text = Text.t("Remover")
	scope.tooltip_text = Text.t("Local: só deste evento. Global: compartilhado por eventos e mapas.")
	local_id.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for control in [scope, local_id, global_id, known, value, remove_button]:
		add_child(control)
	scope.item_selected.connect(func(index: int) -> void:
		if _loading:
			return
		_write_scope(index)
		_refresh()
		edited.emit())
	local_id.item_selected.connect(func(index: int) -> void:
		if _loading:
			return
		resource.set("local_switch" if resource is SwitchCondition else "self_switch", index)
		edited.emit())
	global_id.text_changed.connect(func(text: String) -> void:
		if _loading:
			return
		resource.set("global_switch" if resource is SwitchCondition else "name", text)
		edited.emit())
	value.item_selected.connect(func(index: int) -> void:
		if _loading:
			return
		if resource is SwitchCondition:
			resource.value = index == 0
		else:
			resource.switch_value = index
		edited.emit())
	known.get_popup().index_pressed.connect(func(index: int) -> void:
		global_id.text = known.get_popup().get_item_text(index)
		resource.set("global_switch" if resource is SwitchCondition else "name", global_id.text)
		edited.emit())
	remove_button.pressed.connect(func() -> void: removed.emit())


## [param switch]: KESwitchCondition or switch KEStateChange.
func configure(switch: Resource, names: Array[String] = [], removable: bool = true) -> void:
	_loading = true
	resource = switch
	value.clear()
	value.add_item(Text.t("Ligado"))
	value.add_item(Text.t("Desligado"))
	if resource is SwitchCondition:
		scope.select(resource.scope)
		local_id.select(clampi(resource.local_switch, 0, 3))
		global_id.text = resource.global_switch
		value.select(0 if resource.value else 1)
	else:
		value.add_item(Text.t("Inverter"))
		scope.select(0 if resource.target == StateChange.Target.SELF_SWITCH else 1)
		local_id.select(clampi(resource.self_switch, 0, 3))
		global_id.text = resource.name
		value.select(resource.switch_value)
	remove_button.visible = removable
	known.get_popup().clear()
	for text in names:
		known.get_popup().add_item(text)
	known.disabled = names.is_empty()
	_refresh()
	_loading = false


func _write_scope(index: int) -> void:
	if resource is SwitchCondition:
		resource.scope = index
	else:
		resource.target = StateChange.Target.SELF_SWITCH if index == 0 else StateChange.Target.SWITCH


func _refresh() -> void:
	var local := scope.selected == 0
	local_id.visible = local
	global_id.visible = not local
	known.visible = not local
