@tool
extends ConfirmationDialog
## "Event" window: pages and conditions on the left, command sequence in the
## middle and the command form on the right. Everything is edited in a draft;
## "Apply and close" stores it in the node with Undo/Redo; "Cancel" changes nothing.

signal apply_requested(pages: Array)

const Text = preload("res://addons/kitchen_events/ke_text.gd")
const Data = preload("res://addons/kitchen_events/core/ke_data.gd")
const Model = preload("res://addons/kitchen_events/editor/ke_editor_model.gd")
const Theme_ = preload("res://addons/kitchen_events/editor/ke_panel_theme.gd")
const CommandPanel = preload("res://addons/kitchen_events/editor/ke_command_panel.gd")
const CastDialog = preload("res://addons/kitchen_events/editor/ke_cast_dialog.gd")
const Registry = preload("res://addons/kitchen_events/editor/ke_class_registry.gd")
const Page = preload("res://addons/kitchen_events/core/ke_event_page.gd")
const SwitchCondition = preload("res://addons/kitchen_events/conditions/ke_switch_condition.gd")
const VariableCondition = preload("res://addons/kitchen_events/conditions/ke_variable_condition.gd")
const ItemCondition = preload("res://addons/kitchen_events/conditions/ke_item_condition.gd")
const MethodCondition = preload("res://addons/kitchen_events/conditions/ke_method_condition.gd")
const ShowText = preload("res://addons/kitchen_events/commands/ke_show_text_command.gd")
const Move = preload("res://addons/kitchen_events/commands/ke_move_command.gd")
const Wait = preload("res://addons/kitchen_events/commands/ke_wait_command.gd")
const ChangeState = preload("res://addons/kitchen_events/commands/ke_change_state_command.gd")
const StateChange = preload("res://addons/kitchen_events/core/ke_state_change.gd")
const Settings = preload("res://addons/kitchen_events/runtime/ke_settings.gd")
const CommonEvents = preload("res://addons/kitchen_events/core/ke_common_events.gd")

## Items of "More commands" (the first four have their own buttons).
## ["-", "Section"] creates a separator with a title.
const MORE_COMMANDS := [
	["-", "Conversa"],
	["Escolhas", "res://addons/kitchen_events/commands/ke_show_choices_command.gd"],
	["Balão de emoção", "res://addons/kitchen_events/commands/ke_balloon_command.gd"],
	["-", "Cinema"],
	["Tela (escurecer, piscar, tremer, tingir)", "res://addons/kitchen_events/commands/ke_screen_command.gd"],
	["Câmera", "res://addons/kitchen_events/commands/ke_camera_command.gd"],
	["Mostrar / apagar imagem", "res://addons/kitchen_events/commands/ke_show_image_command.gd"],
	["Música", "res://addons/kitchen_events/commands/ke_music_command.gd"],
	["Som", "res://addons/kitchen_events/commands/ke_play_sound_command.gd"],
	["-", "Personagens"],
	["Virar", "res://addons/kitchen_events/commands/ke_face_command.gd"],
	["Animação", "res://addons/kitchen_events/commands/ke_play_animation_command.gd"],
	["-", "Lógica"],
	["Condição (se / senão)", "res://addons/kitchen_events/commands/ke_conditional_command.gd"],
	["Variável", "variable"],
	["Dar item", "res://addons/kitchen_events/commands/ke_give_item_command.gd"],
	["Remover item", "res://addons/kitchen_events/commands/ke_remove_item_command.gd"],
	["Chamar evento comum", "res://addons/kitchen_events/commands/ke_call_common_event_command.gd"],
	["Encerrar evento", "res://addons/kitchen_events/commands/ke_end_event_command.gd"],
	["-", "Cena e código"],
	["Transferir jogador", "res://addons/kitchen_events/commands/ke_transfer_command.gd"],
	["Chamar método do código", "res://addons/kitchen_events/commands/ke_call_method_command.gd"],
	["Emitir sinal", "res://addons/kitchen_events/commands/ke_emit_signal_command.gd"],
]

var model = Model.new()
var known_from_scene: Dictionary = {}

var _event_title: Label
var _pages_list: ItemList
var _page_settings: ScrollContainer
var _page_column: VBoxContainer
var _command_column: VBoxContainer
var _command_panel: VBoxContainer
var _commands: ItemList
var _rows: Array[Dictionary] = []
var _selected := -1
var _editing: Dictionary = {}
var _loading := false
var _status: Label
var _delete_bar: HBoxContainer
var _delete_message: Label
var _delete_kind := ""
var _name_edit: LineEdit
var _enabled: CheckBox
var _trigger: OptionButton
var _verb: LineEdit
var _limit: OptionButton
var _custom_limit: SpinBox
var _image_mode: OptionButton
var _image_picker: EditorResourcePicker
var _conditions: VBoxContainer
var _skip_finish: CheckBox
var _id_edit: LineEdit
var _action_edit: LineEdit
var _page_up: Button
var _page_down: Button
var _row_buttons: Dictionary = {}
var _more_menu: MenuButton
var _custom_commands: Array = []
var _cast_dialog: ConfirmationDialog
var _common_mode := false
var _settings_heading: Label
var _event_only: Array = []
var _pages_heading: Label
var _add_page_button: Button
var _auto_move: OptionButton
var _auto_box: VBoxContainer
var _auto_distance: SpinBox
var _auto_speed: SpinBox
var _auto_pause: SpinBox
var _auto_vertical: CheckBox


func _init() -> void:
	# The texts are already in the chosen language; the editor must not translate them again.
	auto_translate_mode = AUTO_TRANSLATE_MODE_DISABLED
	title = Text.t("Editor de eventos")
	exclusive = true
	unresizable = false
	dialog_hide_on_ok = false
	get_ok_button().text = Text.t("Aplicar e fechar")
	get_cancel_button().text = Text.t("Cancelar")
	confirmed.connect(_apply)
	visibility_changed.connect(func() -> void:
		Data.editor_draft_mode = visible
		if not visible:
			_command_panel.clear_editor())
	_build()


# --- Window layout ------------------------------------------------------------

func _button(parent: Control, text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.pressed.connect(callback)
	parent.add_child(button)
	return button


func _label(parent: Control, text: String, heading: bool = false) -> Label:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size.x = 160
	if heading:
		label.add_theme_font_size_override("font_size", 17)
		label.add_theme_color_override("font_color", Theme_.HEADING)
	parent.add_child(label)
	return label


func _card(parent: Control, heading: String) -> VBoxContainer:
	var frame := PanelContainer.new()
	parent.add_child(frame)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 10)
	frame.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)
	_label(column, heading, true)
	return column


func _spin(parent: Control, text: String, minimum: float, maximum: float, step: float, suffix: String, property: String) -> SpinBox:
	var spin := SpinBox.new()
	spin.min_value = minimum
	spin.max_value = maximum
	spin.step = step
	spin.suffix = suffix
	spin.allow_greater = true
	_field(parent, text, spin)
	spin.value_changed.connect(func(value: float) -> void: _set_page_property(property, value))
	return spin


func _field(parent: Control, text: String, control: Control) -> void:
	var row := VBoxContainer.new()
	parent.add_child(row)
	_label(row, text)
	control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(control)


func _build() -> void:
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	add_child(content)
	_event_title = _label(content, Text.t("Evento"), true)
	_label(content, Text.t("Escolha uma página, organize a sequência e edite o comando ao lado. As divisórias podem ser arrastadas."))
	var split := HSplitContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.split_offset = 0
	content.add_child(split)

	# Column 1: pages
	_page_column = VBoxContainer.new()
	_page_column.custom_minimum_size.x = 320
	_page_column.add_theme_constant_override("separation", 8)
	split.add_child(_page_column)
	_pages_heading = _label(_page_column, Text.t("Páginas"), true)
	_pages_list = ItemList.new()
	_pages_list.custom_minimum_size.y = 96
	_pages_list.max_text_lines = 1
	_pages_list.allow_reselect = true
	_pages_list.item_selected.connect(_select_page)
	_page_column.add_child(_pages_list)
	var page_actions := GridContainer.new()
	page_actions.columns = 3
	_page_column.add_child(page_actions)
	_add_page_button = _button(page_actions, Text.t("+ Página"), _add_page)
	_button(page_actions, Text.t("Duplicar"), _duplicate_page)
	_button(page_actions, Text.t("Excluir"), func() -> void: _request_delete("page"))
	_page_up = _button(page_actions, Text.t("↑ Página"), _move_page.bind(-1))
	_page_down = _button(page_actions, Text.t("↓ Página"), _move_page.bind(1))
	_page_up.tooltip_text = Text.t("Mover para cima")
	_page_down.tooltip_text = Text.t("Mover para baixo: a última página disponível tem prioridade")
	_page_settings = ScrollContainer.new()
	_page_settings.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_page_settings.custom_minimum_size.y = 100
	_page_settings.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_page_settings.follow_focus = true
	_page_column.add_child(_page_settings)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 10)
	_page_settings.add_child(left)

	var settings := _card(left, Text.t("Página"))
	_settings_heading = settings.get_child(0)
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = Text.t("Ex.: Primeira conversa")
	_field(settings, Text.t("Nome"), _name_edit)
	_name_edit.text_changed.connect(func(value: String) -> void:
		_set_page_property("page_name", value)
		_refresh_page_titles())
	_enabled = CheckBox.new()
	_enabled.text = Text.t("Página habilitada")
	settings.add_child(_enabled)
	_enabled.toggled.connect(func(value: bool) -> void: _set_page_property("enabled", value))
	_trigger = OptionButton.new()
	for text in ["Apertar botão", "Ao tocar", "Automático", "Processo paralelo"]:
		_trigger.add_item(Text.t(text))
	_trigger.set_item_tooltip(0, Text.t("O jogador chega perto e aperta o botão de interagir."))
	_trigger.set_item_tooltip(1, Text.t("Começa quando o jogador entra na área do evento."))
	_trigger.set_item_tooltip(2, Text.t("Começa sozinho quando a página fica ativa. Desligue a página no fim (ex.: switch local A)."))
	_trigger.set_item_tooltip(3, Text.t("Roda em loop, ao fundo, sem travar o jogador (sons de ambiente, cronômetros, NPCs). Sem falas."))
	_field(settings, Text.t("Ativação"), _trigger)
	_trigger.item_selected.connect(func(index: int) -> void: _set_page_property("trigger", index))
	_verb = LineEdit.new()
	_verb.placeholder_text = Text.t("Ler, Conversar, Abrir…")
	_field(settings, Text.t("Verbo"), _verb)
	_verb.text_changed.connect(func(value: String) -> void: _set_page_property("interaction_label", value))
	_limit = OptionButton.new()
	for text in ["Sempre", "Uma vez", "Limite personalizado"]:
		_limit.add_item(Text.t(text))
	_field(settings, Text.t("Repetição"), _limit)
	_custom_limit = SpinBox.new()
	_custom_limit.min_value = 2
	_custom_limit.max_value = 100000
	_custom_limit.suffix = Text.t("vezes")
	settings.add_child(_custom_limit)
	_limit.item_selected.connect(func(index: int) -> void:
		if _loading:
			return
		_custom_limit.visible = index == 2
		_set_page_property("max_executions", 0 if index == 0 else (1 if index == 1 else int(_custom_limit.value))))
	_custom_limit.value_changed.connect(func(value: float) -> void:
		if not _loading and _limit.selected == 2:
			_set_page_property("max_executions", int(value)))

	var image_card := _card(left, Text.t("Imagem nesta página"))
	_image_mode = OptionButton.new()
	for text in ["Manter a imagem do evento", "Trocar por outra imagem", "Esconder a imagem"]:
		_image_mode.add_item(Text.t(text))
	image_card.add_child(_image_mode)
	_image_picker = EditorResourcePicker.new()
	_image_picker.base_type = "Texture2D"
	_image_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	image_card.add_child(_image_picker)
	_label(image_card, Text.t("A imagem do evento é o primeiro Sprite2D ou AnimatedSprite2D filho dele. Ex.: baú fechado na página 1, aberto na página 2."))
	_image_mode.item_selected.connect(func(index: int) -> void:
		_image_picker.visible = index == 1
		_set_page_property("image_mode", index))
	_image_picker.resource_changed.connect(func(resource: Resource) -> void: _set_page_property("image", resource))

	var move_card := _card(left, Text.t("Movimento próprio"))
	_auto_move = OptionButton.new()
	for text in ["Parado", "Ida e volta", "Ao acaso"]:
		_auto_move.add_item(Text.t(text))
	move_card.add_child(_auto_move)
	_auto_box = VBoxContainer.new()
	move_card.add_child(_auto_box)
	_auto_distance = _spin(_auto_box, Text.t("Distância de cada caminhada"), 1, 4096, 1, "px", "auto_move_distance")
	_auto_speed = _spin(_auto_box, Text.t("Velocidade"), 1, 1000, 1, "px/s", "auto_move_speed")
	_auto_pause = _spin(_auto_box, Text.t("Pausa entre caminhadas"), 0, 30, 0.1, "s", "auto_move_pause")
	_auto_vertical = CheckBox.new()
	_auto_vertical.text = Text.t("Ao acaso: também para cima e para baixo")
	_auto_box.add_child(_auto_vertical)
	_auto_vertical.toggled.connect(func(value: bool) -> void: _set_page_property("auto_move_vertical", value))
	_label(move_card, Text.t("O evento anda sozinho enquanto ninguém fala com ele, e para durante a conversa."))
	_auto_move.item_selected.connect(func(index: int) -> void:
		_auto_box.visible = index != 0
		_set_page_property("auto_move", index))

	var condition_card := _card(left, Text.t("Condições para esta página"))
	_label(condition_card, Text.t("Todas devem ser atendidas. Sem condições, a página está sempre disponível."))
	_conditions = VBoxContainer.new()
	_conditions.add_theme_constant_override("separation", 6)
	condition_card.add_child(_conditions)
	_button(condition_card, Text.t("+ Condição de switch"), func() -> void: _add_condition(SwitchCondition.new()))
	var other_conditions := MenuButton.new()
	other_conditions.text = Text.t("Outras condições") + " ▾"
	other_conditions.flat = false
	other_conditions.get_popup().add_item(Text.t("Variável"))
	other_conditions.get_popup().add_item(Text.t("Método do código"))
	other_conditions.get_popup().add_item(Text.t("Item"))
	other_conditions.get_popup().index_pressed.connect(func(index: int) -> void:
		_add_condition([VariableCondition, MethodCondition, ItemCondition][index].new()))
	condition_card.add_child(other_conditions)
	_label(condition_card, Text.t("A última página disponível é escolhida. Use Ligado e Desligado para separar os comportamentos."))

	var finish_card := _card(left, Text.t("Ao concluir"))
	_skip_finish = CheckBox.new()
	_skip_finish.text = Text.t("Concluir ao pular as falas")
	_skip_finish.tooltip_text = Text.t("Esc / B também aplica os switches \"Ao terminar\". Interromper o evento nunca aplica.")
	finish_card.add_child(_skip_finish)
	_skip_finish.toggled.connect(func(value: bool) -> void: _set_page_property("finish_on_skip", value))

	var more := Button.new()
	more.text = Text.t("Outras opções") + " ▸"
	more.toggle_mode = true
	left.add_child(more)
	var advanced := VBoxContainer.new()
	advanced.visible = false
	left.add_child(advanced)
	more.toggled.connect(func(value: bool) -> void:
		advanced.visible = value
		more.text = Text.t("Outras opções") + (" ▾" if value else " ▸"))
	_id_edit = LineEdit.new()
	_id_edit.editable = false
	_id_edit.tooltip_text = Text.t("Identifica a página nos saves (contagem de execuções).")
	_field(advanced, Text.t("ID da página"), _id_edit)
	_action_edit = LineEdit.new()
	_action_edit.placeholder_text = Text.t("Vazio = interact (Configurações do Projeto)")
	_field(advanced, Text.t("Ação de botão"), _action_edit)
	_action_edit.text_changed.connect(func(value: String) -> void: _set_page_property("interaction_action", value.strip_edges()))
	# For common events, the left column shows only the name.
	_event_only = [_enabled, _trigger.get_parent(), _verb.get_parent(), _limit.get_parent(), _custom_limit,
		image_card.get_parent().get_parent(), move_card.get_parent().get_parent(), condition_card.get_parent().get_parent(),
		finish_card.get_parent().get_parent(), more, advanced]

	# Columns 2 and 3: sequence and editing
	var editor_split := HSplitContainer.new()
	editor_split.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_child(editor_split)
	_command_column = VBoxContainer.new()
	_command_column.custom_minimum_size.x = 340
	_command_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_command_column.add_theme_constant_override("separation", 8)
	editor_split.add_child(_command_column)
	_label(_command_column, Text.t("Sequência de comandos"), true)
	_label(_command_column, Text.t("De cima para baixo. Clique para editar."))
	var additions := GridContainer.new()
	additions.columns = 2
	_command_column.add_child(additions)
	for pair in [["+ Fala", "text"], ["+ Movimento", "move"], ["+ Espera", "wait"], ["+ Switch", "switch"]]:
		var button := _button(additions, Text.t(pair[0]), _new_command.bind(pair[1]))
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_more_menu = MenuButton.new()
	_more_menu.text = Text.t("Mais comandos") + " ▾"
	_more_menu.get_popup().id_pressed.connect(_on_more_command)
	_command_column.add_child(_more_menu)
	_commands = ItemList.new()
	_commands.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_commands.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_commands.custom_minimum_size = Vector2(300, 140)
	_commands.max_text_lines = 1
	_commands.allow_reselect = true
	_commands.item_selected.connect(_select_row)
	_commands.gui_input.connect(_on_commands_input)
	_command_column.add_child(_commands)
	var actions := GridContainer.new()
	actions.columns = 3
	_command_column.add_child(actions)
	_row_buttons["edit"] = _button(actions, Text.t("Editar"), _edit_selected)
	_row_buttons["duplicate"] = _button(actions, Text.t("Duplicar"), _duplicate_row)
	_row_buttons["delete"] = _button(actions, Text.t("Excluir"), func() -> void: _request_delete("command"))
	_row_buttons["up"] = _button(actions, Text.t("↑ Subir"), _move_row.bind(-1))
	_row_buttons["down"] = _button(actions, Text.t("↓ Descer"), _move_row.bind(1))
	_label(_command_column, Text.t("Switches \"Ao terminar\" aguardam a página inteira."))
	var edit_margin := MarginContainer.new()
	edit_margin.custom_minimum_size.x = 380
	edit_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	edit_margin.add_theme_constant_override("margin_left", 10)
	editor_split.add_child(edit_margin)
	_command_panel = CommandPanel.new()
	_command_panel.accepted.connect(_accept_command)
	_command_panel.discarded.connect(func() -> void:
		_editing = {}
		_validate())
	_command_panel.cast_requested.connect(_open_cast)
	edit_margin.add_child(_command_panel)

	_delete_bar = HBoxContainer.new()
	_delete_bar.add_theme_constant_override("separation", 10)
	content.add_child(_delete_bar)
	_delete_message = _label(_delete_bar, "")
	_delete_message.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_button(_delete_bar, Text.t("Excluir do rascunho"), _confirm_delete)
	var keep := _button(_delete_bar, Text.t("Manter"), func() -> void: _delete_bar.hide())
	_delete_bar.set_meta(&"keep", keep)
	_delete_bar.hide()
	_status = _label(content, "")

	_cast_dialog = CastDialog.new()
	_cast_dialog.saved.connect(func() -> void:
		if _command_panel.active and _command_panel.kind == "text":
			_command_panel._refresh_portrait())
	add_child(_cast_dialog)


# --- Abrir --------------------------------------------------------------------

func open_for(event: Node, scene_names: Dictionary = {}) -> void:
	Theme_.apply(self)
	for column in [_page_column, _command_column, _command_panel]:
		Theme_.column(column)
	_command_panel.clear_editor()
	_delete_bar.hide()
	model.load_pages(event.pages)
	known_from_scene = scene_names
	_set_common_mode(false)
	_event_title.text = Text.t("Evento: ") + str(event.name)
	_selected = -1
	_editing = {}
	_fill_more_menu()
	_refresh()
	Theme_.popup(self, Vector2i(1440, 820), Vector2i(900, 560))


## Opens the project's common event list, in the same editor.
func open_common(scene_names: Dictionary = {}) -> void:
	Theme_.apply(self)
	for column in [_page_column, _command_column, _command_panel]:
		Theme_.column(column)
	_command_panel.clear_editor()
	_delete_bar.hide()
	var library := Settings.common_events()
	model.load_pages(library.events if library != null else [])
	if library == null or library.events.is_empty():
		model.pages[0].page_name = Text.t("Novo evento comum")
	known_from_scene = scene_names
	_set_common_mode(true)
	_event_title.text = Text.t("Eventos comuns — sequências que qualquer evento pode chamar")
	_selected = -1
	_editing = {}
	_fill_more_menu()
	_refresh()
	Theme_.popup(self, Vector2i(1440, 820), Vector2i(900, 560))


func is_common_mode() -> bool:
	return _common_mode


func _set_common_mode(value: bool) -> void:
	_common_mode = value
	for control in _event_only:
		control.visible = not value
	_pages_heading.text = Text.t("Eventos comuns") if value else Text.t("Páginas")
	_add_page_button.text = Text.t("+ Evento comum") if value else Text.t("+ Página")
	_page_up.text = Text.t("↑ Subir") if value else Text.t("↑ Página")
	_page_down.text = Text.t("↓ Descer") if value else Text.t("↓ Página")
	_settings_heading.text = Text.t("Evento comum") if value else Text.t("Página")


func _fill_more_menu() -> void:
	var popup := _more_menu.get_popup()
	popup.clear()
	for i in MORE_COMMANDS.size():
		if MORE_COMMANDS[i][0] == "-":
			popup.add_separator(Text.t(MORE_COMMANDS[i][1]))
		else:
			popup.add_item(Text.t(MORE_COMMANDS[i][0]), i)
	_custom_commands = []
	for info in Registry.list_commands():
		if not String(info["script"].resource_path).begins_with("res://addons/kitchen_events/"):
			_custom_commands.append(info)
	if not _custom_commands.is_empty():
		popup.add_separator(Text.t("Seus comandos"))
		for i in _custom_commands.size():
			popup.add_item(_custom_commands[i]["name"], 1000 + i)


func _known_names() -> Dictionary:
	var result := model.used_names()
	for key in known_from_scene:
		for name in known_from_scene[key]:
			if not name in result[key]:
				result[key].append(name)
		result[key].sort()
	return result


# --- Pages --------------------------------------------------------------------

func _refresh() -> void:
	_loading = true
	_pages_list.clear()
	for i in model.pages.size():
		_pages_list.add_item("")
	_refresh_page_titles()
	_pages_list.select(model.selected)
	_loading = false
	_refresh_page()


func _refresh_page_titles() -> void:
	for i in model.pages.size():
		var page: Resource = model.pages[i]
		var text := Text.t("Página %d") % (i + 1)
		if _common_mode:
			text = "%02d · " % (i + 1) + (page.page_name if not page.page_name.is_empty() else Text.t("(sem nome)"))
		elif page != null and not page.page_name.is_empty():
			text += " · " + page.page_name
		if page != null and not page.enabled:
			text += " " + Text.t("(desabilitada)")
		_pages_list.set_item_text(i, text)
		_pages_list.set_item_tooltip(i, text)


func _refresh_page() -> void:
	_loading = true
	var page: Resource = model.page()
	_command_panel.clear_editor()
	_editing = {}
	_selected = -1
	_delete_bar.hide()
	_page_up.disabled = model.selected == 0
	_page_down.disabled = model.selected == model.pages.size() - 1
	_name_edit.text = page.page_name
	_enabled.button_pressed = page.enabled
	_trigger.select(page.trigger)
	_verb.text = page.interaction_label
	_limit.select(0 if page.max_executions == 0 else (1 if page.max_executions == 1 else 2))
	_custom_limit.value = maxi(page.max_executions, 2)
	_custom_limit.visible = _limit.selected == 2
	_image_mode.select(page.image_mode)
	_image_picker.edited_resource = page.image
	_image_picker.visible = page.image_mode == Page.ImageMode.REPLACE
	_skip_finish.button_pressed = page.finish_on_skip
	_id_edit.text = page.page_id
	_action_edit.text = page.interaction_action
	_auto_move.select(page.auto_move)
	_auto_box.visible = page.auto_move != Page.AutoMove.NONE
	_auto_distance.value = page.auto_move_distance
	_auto_speed.value = page.auto_move_speed
	_auto_pause.value = page.auto_move_pause
	_auto_vertical.button_pressed = page.auto_move_vertical
	if _common_mode:
		_custom_limit.visible = false
	_refresh_conditions()
	_refresh_rows()
	_loading = false
	_validate()


func _refresh_conditions() -> void:
	for child in _conditions.get_children():
		_conditions.remove_child(child)
		child.queue_free()
	var page: Resource = model.page()
	var names := _known_names()
	for i in page.conditions.size():
		var condition: Resource = page.conditions[i]
		if condition == null:
			continue
		var row: Control = CommandPanel.condition_row(condition, names, true)
		_conditions.add_child(row)
		row.edited.connect(func() -> void:
			model.dirty = true
			_validate())
		row.removed.connect(func() -> void:
			page.conditions.remove_at(i)
			model.dirty = true
			_refresh_conditions()
			_validate())


func _add_condition(condition: Resource) -> void:
	model.page().conditions.append(condition)
	model.dirty = true
	_refresh_conditions()
	_validate()


func _set_page_property(property: String, value: Variant) -> void:
	if _loading:
		return
	model.edit_property(property, value)
	_validate()


func _select_page(index: int) -> void:
	if _loading:
		return
	if not _command_panel.flush():
		_pages_list.select(model.selected)
		return
	model.selected = index
	_refresh_page()


func _add_page() -> void:
	if not _command_panel.flush():
		return
	model.add_page()
	_refresh()


func _duplicate_page() -> void:
	if not _command_panel.flush():
		return
	model.duplicate_page()
	_refresh()


func _move_page(direction: int) -> void:
	if not _command_panel.flush():
		return
	model.move_page(direction)
	_refresh()


# --- Comandos -------------------------------------------------------------------

func _refresh_rows(select_data: Variant = null, select_kind: String = "") -> void:
	_commands.clear()
	_rows = model.rows()
	var theme := EditorInterface.get_editor_theme()
	for i in _rows.size():
		var row: Dictionary = _rows[i]
		var indent := "      ".repeat(row["depth"])
		var number := "%02d   " % row["number"] if row["number"] > 0 else "       "
		var text := Model.row_title(row)
		_commands.add_item(number + indent + text, _row_icon(row, theme))
		_commands.set_item_tooltip(i, text)
		var category := Model.row_category(row)
		var resource: Resource = row["data"]
		if row["kind"] == "command" and resource != null and not resource.is_valid():
			_commands.set_item_custom_fg_color(i, Theme_.ERROR)
			_commands.set_item_tooltip(i, text + "\n" + Text.t("Comando incompleto: clique para completar."))
		else:
			_commands.set_item_custom_fg_color(i, Theme_.ROW_COLORS.get(category, Theme_.TEXT))
		if select_data != null and row["data"] == select_data and (select_kind.is_empty() or row["kind"] == select_kind):
			_selected = i
	if _selected >= 0 and _selected < _rows.size():
		_commands.select(_selected)
		_commands.ensure_current_is_visible()
	else:
		_selected = -1
	_update_row_buttons()


func _row_icon(row: Dictionary, theme: Theme) -> Texture2D:
	var name := "Animation"
	match Model.row_category(row):
		"Message":
			name = "Annotation"
		"State", "finish":
			name = "Key"
		"wait":
			name = "Timer"
		"Character":
			name = "Node2D"
		"Camera":
			name = "Camera2D"
		"Screen":
			name = "CanvasLayer"
		"Audio":
			name = "AudioStreamPlayer"
		"Scene":
			name = "PackedScene"
		"Flow":
			name = "Range"
		"header":
			name = "ArrowRight"
		"Advanced":
			name = "Script"
	return theme.get_icon(name, &"EditorIcons") if theme.has_icon(name, &"EditorIcons") else null


func _selection() -> Dictionary:
	return _rows[_selected] if _selected >= 0 and _selected < _rows.size() else {}


func _update_row_buttons() -> void:
	var row := _selection()
	var editable: bool = not row.is_empty() and row["kind"] != "header"
	_row_buttons["edit"].disabled = not editable
	_row_buttons["duplicate"].disabled = not editable
	_row_buttons["delete"].disabled = not editable
	_row_buttons["up"].disabled = not editable or row["index"] <= 0
	_row_buttons["down"].disabled = not editable or row["index"] >= row["list"].size() - 1


func _new_command(kind: String) -> void:
	if not _command_panel.flush():
		return
	_delete_bar.hide()
	_editing = {}
	var command: Resource
	match kind:
		"text":
			command = ShowText.new()
		"move":
			command = Move.new()
		"wait":
			command = Wait.new()
		"switch":
			command = ChangeState.create([StateChange.make_self_switch("A")])
		"variable":
			command = ChangeState.create([StateChange.make_variable("", StateChange.Operation.ADD, 1)])
	_command_panel.open_new(command, _known_names())


func _on_more_command(id: int) -> void:
	if id >= 1000:
		var info: Dictionary = _custom_commands[id - 1000]
		_open_new_script(info["script"])
		return
	var target: String = MORE_COMMANDS[id][1]
	if target == "variable":
		_new_command("variable")
	else:
		_open_new_script(load(target))


func _open_new_script(script: Script) -> void:
	if not _command_panel.flush():
		return
	_delete_bar.hide()
	_editing = {}
	var command: Resource = script.new()
	if CommandPanel.kind_of(command) == "end":
		_insert_result({"command": command})
		return
	_command_panel.open_new(command, _known_names())


func _select_row(index: int) -> void:
	if _loading:
		return
	var target: Dictionary = _rows[index]
	if _command_panel.active and not _editing.is_empty() and _editing["data"] == target["data"] and _editing["kind"] == target["kind"]:
		return
	if not _command_panel.flush():
		if _selected >= 0:
			_commands.select(_selected)
		else:
			_commands.deselect_all()
		return
	# Finishing may have changed the list; look for the same row again.
	_selected = -1
	for i in _rows.size():
		if _rows[i]["data"] == target["data"] and _rows[i]["kind"] == target["kind"] and _rows[i].get("label", "") == target.get("label", ""):
			_selected = i
	if _selected >= 0:
		_commands.select(_selected)
	_update_row_buttons()
	_delete_bar.hide()
	_edit_selected()


func _edit_selected() -> void:
	var row := _selection()
	if row.is_empty() or row["kind"] == "header":
		_command_panel.clear_editor()
		_editing = {}
		return
	if row["data"] == null or CommandPanel.kind_of(row["data"]) == "end":
		_command_panel.clear_editor()
		_editing = {}
		return
	_editing = row
	_command_panel.open_row(row, _known_names())


func _accept_command(result: Dictionary) -> void:
	if _editing.is_empty():
		_insert_result(result)
		return
	var placed: Dictionary = model.put(result, _editing, {})
	_editing = {}
	_refresh_rows(placed["data"], placed["kind"])
	_validate()


func _insert_result(result: Dictionary) -> void:
	var placed: Dictionary = model.put(result, {}, _selection())
	_refresh_rows(placed["data"], placed["kind"])
	_validate()


func _duplicate_row() -> void:
	if not _command_panel.flush():
		return
	var row := _selection()
	if row.is_empty():
		return
	var copy: Resource = model.duplicate_row(row)
	_refresh_rows(copy, row["kind"])
	_validate()


func _move_row(direction: int) -> void:
	if not _command_panel.flush():
		return
	var row := _selection()
	if row.is_empty() or not model.move_row(row, direction):
		return
	_refresh_rows(row["data"], row["kind"])
	_validate()


func _on_commands_input(input: InputEvent) -> void:
	if not input is InputEventKey or not input.pressed or input.echo:
		return
	if input.keycode == KEY_DELETE and _selected >= 0:
		_commands.accept_event()
		_request_delete("command")
	elif input.is_command_or_control_pressed() and input.keycode == KEY_D:
		_commands.accept_event()
		_duplicate_row()


func _request_delete(kind: String) -> void:
	if not _command_panel.flush():
		return
	if kind == "command" and (_selection().is_empty() or _selection()["kind"] == "header"):
		return
	_delete_kind = kind
	_delete_message.text = Text.t("Excluir esta página e seus comandos?") if kind == "page" else Text.t("Excluir o comando selecionado?")
	_delete_bar.show()
	_delete_bar.get_meta(&"keep").grab_focus()


func _confirm_delete() -> void:
	_delete_bar.hide()
	_command_panel.clear_editor()
	_editing = {}
	if _delete_kind == "page":
		model.delete_page()
		_refresh()
		return
	model.remove_row(_selection())
	_selected = -1
	_refresh_rows()
	_validate()


func _open_cast() -> void:
	_cast_dialog.open()


# --- Aplicar -------------------------------------------------------------------

func _validate() -> void:
	var error: String = model.validation_error()
	get_ok_button().disabled = not error.is_empty()
	if not error.is_empty():
		_status.text = error
	elif model.dirty:
		_status.text = Text.t("Rascunho alterado. Aplicar envia as mudanças à cena; Ctrl+S salva o arquivo.")
	else:
		_status.text = Text.t("Nenhuma alteração. Você pode cancelar sem mudar o evento.")
	_status.add_theme_color_override("font_color", Theme_.ERROR if not error.is_empty() else Theme_.MUTED)


func _apply() -> void:
	if not _command_panel.flush():
		return
	if not model.validation_error().is_empty():
		_validate()
		return
	if not model.dirty:
		hide()
		return
	if _common_mode:
		_save_common_events()
		return
	apply_requested.emit(model.pages_to_apply())


## Saves the common event library to the project file.
func _save_common_events() -> void:
	var path := String(Settings.get_value("editor/common_events"))
	var library: Resource = Settings.common_events()
	if library == null:
		library = CommonEvents.new()
	var events: Array[Resource] = []
	events.assign(model.pages_to_apply())
	library.events.assign(events)
	if ResourceSaver.save(library, path) != OK:
		_status.text = Text.t("Não foi possível salvar %s.") % path
		return
	library.take_over_path(path)
	EditorInterface.get_resource_filesystem().update_file(path)
	hide()
