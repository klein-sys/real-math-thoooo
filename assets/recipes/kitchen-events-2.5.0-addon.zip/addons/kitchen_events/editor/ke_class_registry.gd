@tool
extends RefCounted
## Finds the commands shown in the "Add command" menu: the built-in ones, in a
## fixed order, plus every script class of the project that extends KECommand.

const Text = preload("res://addons/kitchen_events/ke_text.gd")

const COMMAND_BASE := "res://addons/kitchen_events/core/ke_command.gd"
const BUILT_IN := [
	"res://addons/kitchen_events/commands/ke_give_item_command.gd",
	"res://addons/kitchen_events/commands/ke_remove_item_command.gd",
	"res://addons/kitchen_events/commands/ke_show_text_command.gd",
	"res://addons/kitchen_events/commands/ke_show_choices_command.gd",
	"res://addons/kitchen_events/commands/ke_conditional_command.gd",
	"res://addons/kitchen_events/commands/ke_wait_command.gd",
	"res://addons/kitchen_events/commands/ke_end_event_command.gd",
	"res://addons/kitchen_events/commands/ke_change_state_command.gd",
	"res://addons/kitchen_events/commands/ke_face_command.gd",
	"res://addons/kitchen_events/commands/ke_move_command.gd",
	"res://addons/kitchen_events/commands/ke_play_animation_command.gd",
	"res://addons/kitchen_events/commands/ke_camera_command.gd",
	"res://addons/kitchen_events/commands/ke_play_sound_command.gd",
	"res://addons/kitchen_events/commands/ke_transfer_command.gd",
	"res://addons/kitchen_events/commands/ke_call_method_command.gd",
	"res://addons/kitchen_events/commands/ke_emit_signal_command.gd",
	"res://addons/kitchen_events/commands/ke_balloon_command.gd",
	"res://addons/kitchen_events/commands/ke_screen_command.gd",
	"res://addons/kitchen_events/commands/ke_show_image_command.gd",
	"res://addons/kitchen_events/commands/ke_music_command.gd",
	"res://addons/kitchen_events/commands/ke_call_common_event_command.gd",
]
const CATEGORY_ORDER := ["Message", "Flow", "State", "Character", "Camera", "Screen", "Audio", "Scene", "Advanced"]


## [{"script": Script, "name": String, "category": String}], grouped by category.
static func list_commands() -> Array:
	var paths: Array = BUILT_IN.duplicate()
	for path in _custom_command_paths():
		if not path in paths:
			paths.append(path)
	var result: Array = []
	for path in paths:
		var script := load(path) as Script
		if script == null or not script.can_instantiate():
			continue
		var sample: Resource = script.new()
		result.append({"script": script, "name": sample.get_command_name(), "category": sample.get_category()})
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var order_a := _category_rank(a["category"])
		var order_b := _category_rank(b["category"])
		if order_a != order_b:
			return order_a < order_b
		return paths.find(a["script"].resource_path) < paths.find(b["script"].resource_path))
	return result


static func _category_rank(category: String) -> int:
	var index := CATEGORY_ORDER.find(category)
	return index if index >= 0 else CATEGORY_ORDER.size()


static func _custom_command_paths() -> Array:
	var classes := ProjectSettings.get_global_class_list()
	var by_name := {}
	for info in classes:
		by_name[info["class"]] = info
	var result: Array = []
	for info in classes:
		var path: String = info["path"]
		if path.begins_with("res://addons/kitchen_events/"):
			continue
		var base: StringName = info["base"]
		var guard := 0
		while guard < 32:
			guard += 1
			if base == &"KECommand":
				result.append(path)
				break
			if not by_name.has(base):
				break
			base = by_name[base]["base"]
	return result
