#!/usr/bin/env python3
"""Pixel dungeon pack v7 - 96x96, lit/ramped shading, selective outlines.
Run: python make_birds_v4.py  ->  builds ./pixel_birds_v4/ and pixel_birds_v4.zip
"""
import json, math, os, shutil, sys, zipfile
from PIL import Image

S = 96
GROUND = 91  # last pixel row feet may occupy
LX, LY, LZ = -0.45, -0.65, 0.62
BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]
BLK = (24, 18, 30)
WHT = (255, 255, 255)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def c8(c):
    return tuple(max(0, min(255, int(round(v)))) for v in c)


def ramp(base):
    """4-step hue-shifted ramp: deep, shade, base, light."""
    b = tuple(base)
    deep = lerp(tuple(v * 0.42 for v in b), (34, 22, 70), 0.35)
    shade = lerp(tuple(v * 0.72 for v in b), (70, 50, 120), 0.16)
    light = lerp(tuple(min(255, v * 1.1) for v in b), (255, 238, 175), 0.30)
    return [c8(deep), c8(shade), c8(b), c8(light)]


class Cv:
    def __init__(self):
        self.cell = [[None] * S for _ in range(S)]
        self.pid = 0
        self.dets = []

    # -- shading
    def _idx(self, x, y, nx, ny, nz, dither):
        lum = (nx * LX + ny * LY + nz * LZ) * 0.9 + 0.1
        lum += (BAYER[y % 4][x % 4] / 16.0 - 0.5) * dither
        return 3 if lum > 0.68 else 2 if lum > 0.28 else 1 if lum > -0.22 else 0

    def _put(self, x, y, rp, idx, sep):
        if 0 <= x < S and 0 <= y < S:
            self.cell[y][x] = [rp, idx, self.pid, sep]

    def blob(self, cx, cy, rx, ry, rp, dither=0.07, sep=False, new=True, ymax=None, ymin=None):
        if new:
            self.pid += 1
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            if ymax is not None and y > ymax:
                continue
            if ymin is not None and y < ymin:
                continue
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx, ny = (x - cx) / rx, (y - cy) / ry
                d = nx * nx + ny * ny
                if d > 1.0:
                    continue
                self._put(x, y, rp, self._idx(x, y, nx, ny, math.sqrt(1 - d), dither), sep)

    def capsule(self, ax, ay, bx, by, r0, r1, rp, dither=0.07, sep=False, new=True):
        if new:
            self.pid += 1
        rm = max(r0, r1)
        x0, x1 = int(min(ax, bx) - rm) - 1, int(max(ax, bx) + rm) + 2
        y0, y1 = int(min(ay, by) - rm) - 1, int(max(ay, by) + rm) + 2
        vx, vy = bx - ax, by - ay
        L2 = vx * vx + vy * vy or 1e-9
        for y in range(y0, y1):
            for x in range(x0, x1):
                t = max(0.0, min(1.0, ((x - ax) * vx + (y - ay) * vy) / L2))
                px, py = ax + vx * t, ay + vy * t
                r = r0 + (r1 - r0) * t
                dx, dy = x - px, y - py
                d = (dx * dx + dy * dy) / (r * r)
                if d > 1.0:
                    continue
                self._put(x, y, rp, self._idx(x, y, dx / r, dy / r, math.sqrt(1 - d), dither), sep)

    def chain(self, pts, rs, rp, dither=0.07, sep=False):
        self.pid += 1
        for i in range(len(pts) - 1):
            rpi = rp[i] if isinstance(rp[0], list) else rp
            self.capsule(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], rs[i], rs[i + 1], rpi,
                         dither, sep, new=False)

    def tri(self, a, b, d, rp, idx=2, sep=False):
        self.pid += 1

        def s(p1, p2, p3):
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])
        xs = [a[0], b[0], d[0]]; ys = [a[1], b[1], d[1]]
        for y in range(int(min(ys)) - 1, int(max(ys)) + 2):
            for x in range(int(min(xs)) - 1, int(max(xs)) + 2):
                p = (x, y)
                d1, d2, d3 = s(p, a, b), s(p, b, d), s(p, d, a)
                if not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0)):
                    self._put(x, y, rp, idx, sep)

    def det(self, x, y, c):
        self.dets.append((int(round(x)), int(round(y)), c))

    def eye(self, x, y, iris=None):
        """2x2 eye with a highlight."""
        base = iris or BLK
        self.det(x, y, WHT if iris is None else base)
        self.det(x + 1, y, BLK if iris is None else base)
        self.det(x, y + 1, BLK)
        self.det(x + 1, y + 1, BLK)

    # -- final render
    def render(self):
        g = self.cell

        def at(x, y):
            return g[y][x] if 0 <= x < S and 0 <= y < S else None
        # inner separation lines for flagged parts
        for y in range(S):
            for x in range(S):
                c = g[y][x]
                if c and c[3]:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        n = at(x + dx, y + dy)
                        if n and n[2] < c[2]:
                            c.append("edge")
                            break
        out = [[None] * S for _ in range(S)]
        for y in range(S):
            for x in range(S):
                c = g[y][x]
                if c:
                    idx = 0 if (len(c) > 4) else c[1]
                    out[y][x] = c[0][idx]
        for y in range(S):
            for x in range(S):
                if g[y][x] is None:
                    for dx, dy in ((0, 1), (-1, 0), (1, 0), (0, -1)):
                        n = at(x + dx, y + dy)
                        if n:
                            col = lerp(tuple(v * 0.5 for v in n[0][0]), (18, 10, 28), 0.45)
                            out[y][x] = c8(col)
                            break
        for x, y, col in self.dets:
            if 0 <= x < S and 0 <= y < S and out[y][x] is not None:
                out[y][x] = col
        img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        for y in range(S):
            for x in range(S):
                if out[y][x] is not None:
                    img.putpixel((x, y), out[y][x] + (255,))
        return img


class Pose:
    def __init__(self, kind, i):
        if kind == "idle":
            self.ph = None
            self.dy = [0, 0, 1, 1][i]
            self.hd = [0, 1, 1, 0][i]
            self.tail = [0, 1, 0, -1][i]
            self.hop = [0, 0, 1, 1][i]
            self.blink = (i == 2)
            self.hx = [0, 0, 1, 1][i]
            self.fl = i / 4.0
        else:
            self.ph = i / 6.0
            s = abs(math.sin(2 * math.pi * self.ph))
            self.dy = -int(round(s))
            self.hd = 0
            self.tail = math.sin(2 * math.pi * self.ph)
            self.hop = -int(round(4 * s))
            self.blink = False
            self.hx = int(round(math.sin(2 * math.pi * self.ph)))
            self.fl = i / 6.0


def leg(c, p, x0, top, r, rp, phase, stride=5, lift=5, knee=0.0, pawrp=None, sep=False):
    if p.ph is None:
        fx, l = x0, 0.0
    else:
        f = (p.ph + phase) % 1.0
        if f < 0.5:
            fx, l = x0 + stride * (1 - 4 * f), 0.0
        else:
            u = (f - 0.5) / 0.5
            fx, l = x0 + stride * (-1 + 2 * u), lift * math.sin(math.pi * u)
    fy = GROUND - l - r
    if knee:
        mx, my = (x0 + fx) / 2 + knee, (top + fy) / 2
        c.chain([(x0, top), (mx, my), (fx, fy)], [r * 1.1, r, r * 0.88], rp, sep=sep)
    else:
        c.capsule(x0, top, fx, fy, r * 1.1, r * 0.9, rp, sep=sep)
    c.blob(fx + 1, GROUND - l - 1.2, r * 1.15, 2.2, pawrp or rp, dither=0.0)


def spikes(c, cx, cy, rx, ry, a0, a1, n, length, base, rps):
    for i in range(n):
        th = math.radians(a0 + (a1 - a0) * i / (n - 1))
        bx, by = cx + rx * math.cos(th), cy - ry * math.sin(th)
        nx, ny = math.cos(th) / rx, -math.sin(th) / ry
        nn = math.hypot(nx, ny); nx, ny = nx / nn, ny / nn
        tx, ty = bx + nx * length, by + ny * length
        qx, qy = -ny, nx
        a = (bx - qx * base / 2 - nx * 2, by - qy * base / 2 - ny * 2)
        b = (bx + qx * base / 2 - nx * 2, by + qy * base / 2 - ny * 2)
        lit = nx * LX + ny * LY
        c.tri(a, b, (tx, ty), rps[i % len(rps)], idx=3 if lit > 0.55 else 2 if lit > -0.2 else 1)


# ====================================================================== medieval props (96px)
import random


def flat(col):
    col = c8(col)
    return [col] * 4


class Cv2(Cv):
    """Cv + 'free' pixels drawn after outlining (sparks, sparkles)."""
    def __init__(self):
        super().__init__()
        self.free = []

    def fx(self, x, y, col):
        self.free.append((int(round(x)), int(round(y)), c8(col)))

    def render(self):
        img = super().render()
        for x, y, col in self.free:
            if 0 <= x < S and 0 <= y < S:
                img.putpixel((x, y), tuple(col) + (255,))
        return img


# ---- palettes
STN = [ramp((152, 150, 166)), ramp((140, 140, 158)), ramp((160, 154, 164)), ramp((130, 132, 152))]
STL = [ramp((186, 182, 194)), ramp((172, 170, 186)), ramp((192, 186, 192))]
STW = [ramp((126, 108, 100)), ramp((114, 100, 96)), ramp((136, 116, 106)), ramp((106, 94, 94))]
STF = [ramp((124, 130, 150)), ramp((112, 118, 140)), ramp((132, 134, 154)), ramp((106, 114, 136))]
W1, W2, WD, WL = ramp((152, 100, 58)), ramp((130, 84, 48)), ramp((92, 58, 36)), ramp((186, 132, 78))
IR, IRD = ramp((106, 112, 132)), ramp((64, 68, 86))
GD, RD = ramp((248, 206, 66)), ramp((184, 36, 50))
VOID = flat((16, 12, 22))
WOODS = [W1, W2, WL, ramp((142, 92, 52))]


# ---- primitives
def fillm(c, x0, y0, x1, y1, fn, mask=None, sep=True):
    c.pid += 1
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if mask is not None and not mask(x, y):
                continue
            r = fn(x, y)
            if r is None:
                continue
            c._put(x, y, r[0], r[1], sep)


def box(c, x0, y0, x1, y1, rp, bevel=1, sep=True, mask=None):
    def fn(x, y):
        if bevel and (y < y0 + bevel or x < x0 + bevel):
            return rp, 3
        if bevel and (y > y1 - bevel or x > x1 - bevel):
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def stones(c, x0, y0, x1, y1, rps, bw=12, bh=8, mask=None, sep=True, seed=0, tile=None):
    def fn(x, y):
        ry = (y - y0) // bh
        off = (bw // 2) if ry % 2 else 0
        xx = x - x0 + off
        cx = xx // bw
        lx, ly = xx % bw, (y - y0) % bh
        kx, ky = (cx % tile[0], ry % tile[1]) if tile else (cx, ry)
        h = (kx * 73856093) ^ (ky * 19349663) ^ (seed * 83492791)
        rp = rps[(h >> 3) % len(rps)]
        if lx == 0 or ly == bh - 1:
            return rp, 0
        if ly == 0 or lx == 1:
            return rp, 3
        if ly == bh - 2:
            return rp, 1
        sp = (x * 7349 + y * 9157 + seed * 31) % 19
        if sp == 0:
            return rp, 3
        if sp == 1:
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def planks(c, x0, y0, x1, y1, rps, pw=8, vertical=True, mask=None, sep=True, seed=0):
    def fn(x, y):
        a = (x - x0) if vertical else (y - y0)
        b = (y - y0) if vertical else (x - x0)
        k, l = a // pw, a % pw
        rp = rps[(k * 31 + seed) % len(rps)]
        if l == 0:
            return rp, 0
        if l == 1:
            return rp, 3
        if l == pw - 1:
            return rp, 1
        if (b * 5 + k * 13) % 23 == 0 and l > 2:
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def poly(c, pts, rp, idx=2, fn=None, sep=True):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]

    def inside(x, y):
        px, py = x + 0.5, y + 0.5
        ins = False
        j = len(pts) - 1
        for i in range(len(pts)):
            xi, yi = pts[i]; xj, yj = pts[j]
            if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi:
                ins = not ins
            j = i
        return ins
    f = fn if fn else (lambda x, y: (rp, idx))
    fillm(c, int(min(xs)), int(min(ys)), int(max(xs)) + 1, int(max(ys)) + 1, f, inside, sep)


def arch_mask(cx, top, half, bottom):
    def m(x, y):
        if y < top or y > bottom:
            return False
        dx = x - cx
        if y >= top + half:
            return abs(dx) <= half
        return dx * dx + (y - (top + half)) ** 2 <= half * half
    return m


def ell_mask(cx, cy, rx, ry):
    return lambda x, y: ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0


def tone(c, x0, y0, x1, y1, d, mask=None):
    for y in range(max(0, y0), min(S, y1 + 1)):
        for x in range(max(0, x0), min(S, x1 + 1)):
            cell = c.cell[y][x]
            if cell and cell[1] > 0 and (mask is None or mask(x, y)):
                cell[1] = max(0, min(3, cell[1] + d))


def flame(c, cx, base_y, h, w, t, seed=0.0, sway=2.0):
    sw = sway * math.sin(2 * math.pi * t + seed)
    flick = 1 + 0.12 * math.sin(4 * math.pi * t + seed * 1.7)
    for col, k in (((214, 48, 34), 1.0), ((250, 124, 32), 0.8), ((255, 196, 64), 0.58), ((255, 240, 176), 0.34)):
        hh, ww = h * k * flick, w * k
        pts = [(cx, base_y - ww * 0.4), (cx + sw * 0.35 * k, base_y - hh * 0.45), (cx + sw * k, base_y - hh)]
        c.chain(pts, [ww, ww * 0.68, 0.7], flat(col), dither=0.0)



def hh(x, y, s=0):
    return ((x % 96) * 374761393 + (y % 96) * 668265263 + s * 1442695041) & 0xffffffff


# ====================================================================== dungeon set (96px)
DST = [ramp((100, 102, 122)), ramp((90, 94, 114)), ramp((108, 106, 120)), ramp((82, 88, 108))]
DSL = [ramp((126, 128, 148)), ramp((116, 120, 140))]
DW = [ramp((100, 68, 46)), ramp((86, 58, 40)), ramp((112, 76, 50))]
MOSS = ramp((84, 132, 82))
MOSSD = ramp((58, 98, 66))
BONE, BONED = ramp((234, 228, 208)), ramp((198, 190, 168))
RUST = ramp((146, 82, 54))
GS = ramp((112, 114, 134))
DARK = flat((16, 12, 22))


def flame2(c, cx, base_y, h, w, t, cols, seed=0.0, sway=2.0):
    sw = sway * math.sin(2 * math.pi * t + seed)
    flick = 1 + 0.12 * math.sin(4 * math.pi * t + seed * 1.7)
    for col, k in zip(cols, (1.0, 0.8, 0.58, 0.34)):
        hh_, ww = h * k * flick, w * k
        pts = [(cx, base_y - ww * 0.4), (cx + sw * 0.35 * k, base_y - hh_ * 0.45), (cx + sw * k, base_y - hh_)]
        c.chain(pts, [ww, ww * 0.68, 0.7], flat(col), dither=0.0)


SOUL = [(20, 110, 96), (40, 190, 150), (120, 240, 200), (232, 255, 242)]
WARM = [(214, 48, 34), (250, 124, 32), (255, 196, 64), (255, 240, 176)]


def skull(c, x, y, r=8.0):
    c.blob(x, y, r, r * 0.92, BONE, dither=0.04, sep=True)
    c.blob(x, y + r * 0.78, r * 0.62, r * 0.4, BONED, dither=0.04)
    for sx in (-1, 1):
        c.blob(x + sx * r * 0.4, y - r * 0.02, r * 0.28, r * 0.32, DARK, dither=0.0)
    c.blob(x, y + r * 0.34, r * 0.1, r * 0.16, DARK, dither=0.0)
    for k in (-2, -1, 0, 1, 2):
        c.fx(x + k * max(1, r * 0.2), y + r * 0.92, (60, 50, 56))


# ---------------------------------------------------------------- objects
def dungeon_door(c):
    stones(c, 22, 8, 73, 91, DST, bw=9, bh=6, mask=arch_mask(47.5, 8, 26, 91), seed=3)
    dm = arch_mask(47.5, 16, 19, 91)
    planks(c, 28, 16, 67, 91, DW, pw=6, mask=dm, seed=5)
    for y in (46, 70):
        box(c, 28, y, 67, y + 4, IRD, mask=dm, sep=False)
        for x in range(32, 66, 8):
            c.fx(x, y + 2, (150, 156, 176))
    box(c, 40, 24, 55, 36, DARK, bevel=0)
    for x in (43, 47, 51):
        box(c, x, 24, x + 1, 36, IR, bevel=0, sep=False)
    box(c, 52, 54, 61, 64, IR)
    c.det(56, 58, (16, 12, 22)); c.det(56, 59, (16, 12, 22))
    box(c, 18, 88, 77, 91, DSL[0])


def cell_door(c):
    stones(c, 22, 8, 73, 91, DST, bw=9, bh=6, mask=arch_mask(47.5, 8, 26, 91), seed=4)
    dm = arch_mask(47.5, 16, 19, 91)
    fillm(c, 28, 16, 67, 91, lambda x, y: (DARK, 2), dm)
    for x in range(31, 66, 6):
        box(c, x, 16, x + 2, 91, IR, mask=dm, sep=False)
    for y in (34, 56, 78):
        box(c, 28, y, 67, y + 3, IR, mask=dm, sep=False)
    box(c, 54, 52, 63, 64, IRD)
    c.det(58, 56, (16, 12, 22)); c.det(58, 57, (16, 12, 22))
    for (x, y) in ((36, 40), (50, 70), (60, 30)):
        c.blob(x, y, 2.6, 2, RUST, dither=0.2)
    box(c, 18, 88, 77, 91, DSL[0])


def wall_shackles(c):
    stones(c, 6, 4, 89, 91, DST, bw=13, bh=8, seed=6, sep=False)
    tone(c, 6, 4, 89, 91, -1)
    for x in (28, 68):
        c.blob(x, 10, 4, 4, IR, dither=0.0)
        for k in range(6):
            y = 16 + k * 6
            c.blob(x, y, 1.6, 2.8, IRD, dither=0.0)
            c.blob(x, y + 3, 2.6, 1.5, IR, dither=0.0)
        c.blob(x, 54, 7, 6, IR, dither=0.04)
        c.blob(x, 54, 4.2, 3.6, DARK, dither=0.0)
        box(c, x - 2, 58, x + 2, 64, IRD)
    c.blob(48, 80, 12, 3, MOSS, dither=0.2)
    c.blob(14, 70, 5, 8, MOSS, dither=0.2)


def skeleton_sitting(c):
    c.chain([(44, 46), (45, 56), (48, 66)], [2.4, 2.2, 2.6], BONE, dither=0.03, sep=True)
    for k, y in enumerate((46, 51, 56)):
        w = 11 - k * 1.5
        c.capsule(45 - w, y, 45 + w, y, 1.4, 1.4, BONE, dither=0.0, sep=True)
    c.blob(48, 68, 8, 4.4, BONE, dither=0.03, sep=True)
    skull(c, 44, 32, 9)
    c.chain([(50, 70), (70, 82), (88, 88)], [3.0, 2.6, 2.0], BONE, sep=True)
    c.chain([(54, 72), (72, 84), (90, 90)], [2.8, 2.4, 1.8], BONED, sep=True)
    c.chain([(40, 48), (30, 58), (34, 74)], [2.4, 2.0, 1.7], BONE, sep=True)
    c.chain([(52, 48), (62, 60), (58, 76)], [2.4, 2.0, 1.7], BONED, sep=True)
    for (x, y) in ((34, 77), (58, 79), (91, 89)):
        c.blob(x, y, 3.2, 2.6, BONE, dither=0.0)
    c.blob(24, 88, 12, 3, DST[1], dither=0.12)
    c.blob(70, 90, 8, 2.6, DST[0], dither=0.12)


def skull_pile(c):
    for (x, y, r) in ((34, 62, 8), (48, 58, 8.5), (62, 62, 8), (26, 74, 8), (40, 72, 8.5), (56, 72, 8.5), (70, 74, 8),
                      (32, 85, 8), (48, 84, 8.5), (64, 85, 8)):
        skull(c, x, y, r)
    c.capsule(14, 90, 82, 82, 2.8, 2.8, BONED, dither=0.03, sep=True)
    c.blob(13, 90, 4, 3.2, BONED, dither=0.0); c.blob(83, 81, 4, 3.2, BONED, dither=0.0)


def bones(c):
    c.capsule(14, 84, 70, 66, 2.6, 2.6, BONE, dither=0.03, sep=True)
    c.capsule(14, 66, 70, 84, 2.6, 2.6, BONED, dither=0.03, sep=True)
    for (x, y) in ((14, 84), (70, 66), (14, 66), (70, 84)):
        c.blob(x - 1, y - 2, 3.6, 3, BONE, dither=0.0); c.blob(x - 1, y + 2, 3.6, 3, BONE, dither=0.0)
    skull(c, 74, 80, 8)
    for k in range(3):
        c.chain([(30 + k * 9, 52), (34 + k * 9, 58), (30 + k * 9, 64)], [1.6, 1.8, 1.6], BONED, dither=0.0, sep=True)
    c.capsule(8, 90, 30, 88, 1.8, 1.6, BONE, dither=0.0, sep=True)


def cobweb_corner(c):
    col = (222, 222, 236)
    for a in range(0, 91, 15):
        r = math.radians(a)
        for d in range(0, 86):
            c.fx(2 + d * math.cos(r), 2 + d * math.sin(r), col)
    for rad in (16, 30, 46, 62, 78):
        for a in range(0, 91, 1):
            sag = 1 - 0.14 * math.sin(math.pi * a / 90.0)
            r = math.radians(a)
            c.fx(2 + rad * sag * math.cos(r), 2 + rad * sag * math.sin(r), (200, 200, 218))
    c.capsule(30, 30, 30, 30, 2.6, 2.6, flat((22, 18, 28)), dither=0.0)
    for (dx, dy) in ((-5, -4), (-6, 0), (-5, 4), (-3, 6), (5, -4), (6, 0), (5, 4), (3, 6)):
        c.fx(30 + dx, 30 + dy, (22, 18, 28))
    for d in range(0, 14):
        c.fx(30 + 0.0, 16 + d, (214, 214, 230))


def sarcophagus(c):
    stones(c, 12, 60, 83, 91, DST, bw=12, bh=8, seed=5)
    poly(c, [(8, 60), (88, 60), (80, 32), (16, 32)], DSL[0], idx=2)
    tone(c, 8, 32, 30, 60, 1); tone(c, 70, 32, 88, 60, -1)
    box(c, 46, 38, 49, 56, DST[3][0:4] and DST[1], bevel=0)
    box(c, 40, 43, 55, 46, DST[1], bevel=0)
    box(c, 8, 58, 88, 63, DSL[1])
    for x in (20, 70):
        c.blob(x, 76, 5, 5, DST[3], dither=0.0)
    c.blob(48, 88, 20, 3, MOSS, dither=0.2)


def wooden_coffin(c):
    pts = [(36, 6), (60, 6), (72, 34), (62, 90), (34, 90), (24, 34)]
    poly(c, pts, DW[0], fn=lambda x, y: (DW[(x // 8) % 3], 0 if x % 8 == 0 else (3 if x % 8 == 1 else 2)))
    tone(c, 24, 6, 36, 90, 1); tone(c, 62, 6, 72, 90, -1)
    box(c, 46, 14, 49, 52, IR, bevel=1)
    box(c, 38, 24, 57, 28, IR, bevel=1)
    for (x, y) in ((34, 20), (60, 20), (30, 38), (66, 38), (36, 80), (58, 80)):
        c.fx(x, y, (170, 176, 196))
    c.blob(48, 70, 4, 5, IRD, dither=0.0)
    c.blob(48, 88, 18, 3, DST[1], dither=0.1)


def gravestone(c):
    c.blob(48, 88, 30, 6, ramp((92, 66, 48)), dither=0.2)
    stones(c, 28, 14, 67, 88, DSL, bw=14, bh=9, mask=arch_mask(47.5, 14, 20, 88), seed=7)
    tone(c, 28, 14, 38, 88, 1); tone(c, 58, 14, 67, 88, -1)
    box(c, 46, 30, 49, 56, DST[3], bevel=0, sep=False)
    box(c, 40, 36, 55, 39, DST[3], bevel=0, sep=False)
    for (x, y, dx) in ((34, 44, 3), (44, 64, 2), (54, 74, -3)):
        c.fx(x, y, (40, 40, 56)); c.fx(x + dx, y + 1, (40, 40, 56)); c.fx(x + dx * 2, y + 3, (40, 40, 56))
    c.blob(33, 82, 6, 4, MOSS, dither=0.2); c.blob(62, 80, 5, 5, MOSS, dither=0.2)


def altar(c):
    stones(c, 14, 52, 81, 91, DST, bw=12, bh=8, seed=8)
    box(c, 8, 44, 87, 53, DSL[0])
    box(c, 26, 44, 69, 53, ramp((150, 28, 44)))
    box(c, 26, 49, 69, 51, GD, bevel=0, sep=False)
    skull(c, 48, 36, 8)
    for x in (24, 72):
        c.capsule(x, 44, x, 26, 2.6, 2.6, ramp((226, 218, 196)), dither=0.04, sep=True)
        c.blob(x, 26, 2.6, 1.4, ramp((60, 52, 48)), dither=0.0)
    c.capsule(36, 44, 36, 36, 1.2, 1.2, GD, dither=0.0)
    c.blob(36, 34, 3.6, 3, GD, dither=0.0)
    box(c, 54, 38, 66, 44, ramp((190, 40, 56)), sep=True)
    for y in (70, 80):
        box(c, 22, y, 74, y + 2, DST[3], bevel=0, sep=False)


def spike_pit(c):
    box(c, 4, 78, 91, 91, DST[0])
    for x in range(8, 90, 9):
        c.tri((x - 3.5, 78), (x + 3.5, 78), (x, 44), ramp((156, 158, 172)), sep=True)
        c.blob(x, 76, 5, 2.6, RUST, dither=0.2)
    box(c, 4, 86, 91, 91, DST[3])


def treasure_pile(c):
    c.blob(48, 78, 38, 22, GD, dither=0.22, ymax=90)
    for k, (x, y) in enumerate(((20, 72), (34, 62), (50, 58), (64, 64), (74, 74), (28, 80), (58, 78), (44, 70))):
        c.blob(x, y, 4.2, 3.4, GD, dither=0.1)
        c.fx(x - 1, y - 1, (255, 248, 200))
    for (x, y, col) in ((38, 58, (210, 40, 60)), (62, 60, (60, 190, 120)), (50, 52, (220, 236, 252)), (26, 70, (80, 120, 230))):
        c.blob(x, y, 3.2, 3.2, flat(col), dither=0.0)
    c.blob(70, 58, 4, 4.4, GD, dither=0.04); c.capsule(70, 60, 70, 52, 1.2, 1.2, GD, dither=0.0)
    poly(c, [(24, 56), (46, 56), (44, 44), (40, 50), (35, 40), (30, 50), (26, 44)], GD, idx=2)
    for (x, y) in ((22, 50), (74, 48), (50, 44), (60, 56)):
        c.fx(x, y, WHT); c.fx(x - 1, y, (255, 240, 170)); c.fx(x + 1, y, (255, 240, 170)); c.fx(x, y - 1, (255, 240, 170)); c.fx(x, y + 1, (255, 240, 170))


def stocks(c):
    for x in (14, 70):
        box(c, x, 22, x + 11, 91, DW[0])
        c.blob(x + 5.5, 22, 6, 3, DW[1], dither=0.0)
    box(c, 8, 40, 87, 49, DW[2])
    box(c, 8, 49, 87, 58, DW[0])
    for (x, r) in ((32, 4.6), (48, 6.4), (64, 4.6)):
        c.blob(x, 49, r, r, DARK, dither=0.0)
    box(c, 78, 44, 84, 56, IR)
    c.blob(81, 60, 3.6, 4, IRD, dither=0.0)
    box(c, 6, 87, 89, 91, DW[1])


def broken_barrel(c):
    def w(y):
        return 20 + 5 * math.sin(math.pi * (y - 30) / 60.0)
    body = lambda x, y: 30 <= y <= 90 and abs(x - 47.5) <= w(y) and not (x >= 50 and y < 52 + ((x * 7) % 7))
    planks(c, 20, 30, 76, 90, [DW[0], DW[1], DW[2]], pw=6, mask=body, seed=2)
    tone(c, 20, 30, 34, 90, 1, body); tone(c, 62, 30, 76, 90, -1, body)
    for (y0, y1) in ((38, 42), (60, 64), (78, 82)):
        box(c, 20, y0, 76, y1, IRD, mask=body, sep=False)
    c.capsule(60, 88, 88, 84, 2.8, 2.8, DW[1], dither=0.05, sep=True)
    c.capsule(66, 78, 78, 90, 2.6, 2.6, DW[0], dither=0.05, sep=True)
    c.blob(24, 92 - 3, 6, 2, MOSS, dither=0.2)


def hanging_cage(c):
    for k in range(7):
        y = 0 + k * 3
        c.blob(48, y, 1.4, 2.0 if k % 2 else 1.4, IRD, dither=0.0)
    skull(c, 48, 52, 8)
    c.blob(48, 16, 19, 5, IR, dither=0.0, new=True)
    for x in range(30, 67, 6):
        mid = 48 + (x - 48) * 1.18
        c.chain([(x * 0.85 + 48 * 0.15, 16), (mid, 40), (x * 0.85 + 48 * 0.15, 66)], [1.3, 1.5, 1.3], IR, dither=0.0, sep=True)
    c.blob(48, 66, 19, 5, IR, dither=0.0, new=True)
    c.blob(48, 42, 21.5, 1.6, IRD, dither=0.0, new=True)
    c.blob(48, 12, 6, 4, IRD, dither=0.0, new=True)


def lever(c, on=False):
    stones(c, 16, 24, 79, 91, DST, bw=13, bh=8, seed=9, sep=False)
    tone(c, 16, 24, 24, 91, 1); tone(c, 72, 24, 79, 91, -1)
    box(c, 30, 36, 65, 80, IR)
    box(c, 44, 44, 52, 70, DARK, bevel=0)
    for (x, y) in ((33, 39), (62, 39), (33, 77), (62, 77)):
        c.fx(x, y, (190, 196, 214))
    tx = 61 if on else 35
    c.capsule(48, 72, tx, 42, 2.6, 2.4, IRD, dither=0.0, sep=True)
    c.blob(tx, 41, 4.4, 4.4, ramp((200, 40, 56)), dither=0.04)
    c.blob(48, 72, 5, 5, IR, dither=0.0)


def lever_off(c):
    lever(c, False)


def lever_on(c):
    lever(c, True)


def stairs_down(c):
    stones(c, 12, 6, 83, 91, DST, bw=12, bh=8, mask=arch_mask(47.5, 6, 36, 91), seed=3)
    fillm(c, 20, 14, 75, 91, lambda x, y: (DARK, 2), arch_mask(47.5, 14, 28, 91))
    for k in range(7):
        f = 0.82 ** k
        w = int(52 * (0.84 ** k))
        y1 = int(90 - k * 11.5 + k * k * 0.55)
        h = max(4, int(8 - k * 0.9))
        col = ramp((int(130 * f), int(130 * f), int(150 * f)))
        box(c, 48 - w // 2, y1 - h, 48 + w // 2, y1, col, sep=False)
    c.fx(48, 20, (60, 50, 90))


def broken_pillar(c):
    pts_top = [(36, 46), (40, 36), (46, 44), (52, 30), (58, 42), (60, 38), (60, 90), (36, 90)]
    planks(c, 36, 30, 59, 82, [DST[0], DST[1]], pw=6, mask=lambda x, y: y >= 34 + ((x * 5) % 11) - (4 if x > 50 else 0), seed=2, sep=False)
    tone(c, 36, 34, 43, 82, 1); tone(c, 52, 34, 59, 82, -1)
    box(c, 31, 82, 64, 87, DSL[0]); box(c, 27, 87, 68, 91, DSL[1])
    c.blob(76, 84, 9, 7, DST[0], dither=0.1)
    c.blob(80, 78, 5, 4, DST[2], dither=0.1)
    c.blob(16, 86, 6, 4, MOSS, dither=0.2)
    c.fx(46, 24, (160, 160, 176)); c.fx(52, 20, (140, 140, 160))


def rubble_pile(c):
    rng = random.Random(11)
    spots = [(48, 74, 16, 12), (28, 80, 12, 9), (68, 80, 13, 9), (40, 62, 10, 8), (58, 64, 10, 8), (80, 86, 8, 5), (16, 87, 8, 5), (48, 52, 7, 6)]
    for (x, y, rx, ry) in spots:
        c.blob(x, y, rx, ry, DST[rng.randint(0, 3)], dither=0.12, sep=True)
    for k in range(5):
        c.fx(30 + k * 8, 46 - k % 2 * 6, (150, 150, 168))


def wall_cracked(c):
    stones(c, 4, 4, 91, 91, DST, bw=14, bh=8, seed=12, sep=False)
    tone(c, 4, 4, 91, 91, -1)
    hole = [(40, 22), (56, 18), (64, 34), (58, 44), (66, 60), (52, 72), (42, 62), (34, 48), (44, 38)]
    poly(c, hole, DARK, idx=2)
    for (x0, y0, x1, y1) in ((20, 12, 38, 22), (62, 26, 78, 34)):
        pass
    for (x, y, w_) in ((20, 84, 12), (44, 86, 10), (62, 83, 14)):
        box(c, x, y, x + w_, y + 6, DST[2])
    c.chain([(34, 6), (38, 20), (34, 34)], [1.0, 1.0, 1.0], flat((20, 16, 26)), dither=0.0)
    c.blob(80, 70, 7, 9, MOSS, dither=0.2)


def chest_iron(c):
    box(c, 18, 56, 77, 90, DW[1])
    planks(c, 18, 56, 77, 90, DW, pw=8, sep=False)
    dome = lambda x, y: y <= 56 and ((x - 47.5) / 30) ** 2 + ((y - 56) / 18) ** 2 <= 1.0
    body = lambda x, y: 18 <= x <= 77 and 56 <= y <= 90
    planks(c, 18, 38, 77, 56, DW, pw=8, mask=dome, sep=True)
    allm = lambda x, y: dome(x, y) or body(x, y)
    for x in (24, 40, 55, 68):
        box(c, x, 38, x + 5, 90, IRD, mask=allm, sep=False)
    box(c, 18, 54, 77, 58, IRD, mask=allm, sep=False)
    box(c, 42, 58, 53, 72, IR)
    c.blob(47.5, 56, 5, 5, IR, dither=0.0); c.blob(47.5, 56, 2.6, 2.6, DARK, dither=0.0)
    for (x, y) in ((22, 62), (72, 62), (22, 84), (72, 84)):
        c.blob(x, y, 2, 2, RUST, dither=0.1)
    box(c, 16, 87, 79, 91, DW[1])


def gargoyle(c):
    wing = ramp((74, 78, 100))
    for mir in (False, True):
        m = (lambda p: (96 - p[0], p[1])) if mir else (lambda p: p)
        poly(c, [m(p) for p in [(38, 48), (6, 20), (10, 50), (20, 44), (22, 62), (34, 58)]], wing, idx=2)
    c.chain([(62, 72), (80, 68), (82, 54)], [2.6, 2.2, 1.4], GS, sep=True)
    stones(c, 20, 74, 75, 91, DST, bw=12, bh=6, seed=4)
    box(c, 16, 70, 79, 76, DST[2])
    c.blob(48, 56, 16, 18, GS, dither=0.06)
    c.blob(48, 62, 9, 10, DST[2], dither=0.08)
    c.capsule(36, 60, 32, 72, 4.4, 3.6, GS, dither=0.06, sep=True); c.capsule(60, 60, 64, 72, 4.4, 3.6, GS, dither=0.06, sep=True)
    for x in (30, 34, 62, 66):
        c.blob(x, 73, 2, 2, DST[3], dither=0.0)
    c.tri((36, 26), (30, 8), (43, 22), DST[3], sep=True); c.tri((60, 26), (66, 8), (53, 22), DST[3], sep=True)
    c.blob(48, 32, 12, 10.5, GS, dither=0.05, sep=True)
    c.blob(48, 39, 7, 4.5, DST[0], dither=0.05)
    c.det(41, 30, (240, 60, 50)); c.det(42, 30, (240, 60, 50)); c.det(54, 30, (240, 60, 50)); c.det(55, 30, (240, 60, 50))
    c.det(45, 42, WHT); c.det(51, 42, WHT)
    c.blob(30, 86, 7, 3, MOSS, dither=0.2)


def dungeon_object_list():
    return [("dungeon_door", dungeon_door), ("cell_door", cell_door), ("wall_shackles", wall_shackles),
            ("skeleton_sitting", skeleton_sitting), ("skull_pile", skull_pile), ("bones", bones),
            ("cobweb_corner", cobweb_corner), ("sarcophagus", sarcophagus), ("wooden_coffin", wooden_coffin),
            ("gravestone", gravestone), ("altar", altar), ("spike_pit", spike_pit), ("treasure_pile", treasure_pile),
            ("stocks", stocks), ("broken_barrel", broken_barrel), ("hanging_cage", hanging_cage),
            ("lever_off", lever_off), ("lever_on", lever_on), ("stairs_down", stairs_down),
            ("broken_pillar", broken_pillar), ("rubble_pile", rubble_pile), ("wall_cracked", wall_cracked),
            ("chest_iron", chest_iron), ("gargoyle", gargoyle)]


# ---------------------------------------------------------------- animated
def soul_torch(c, t, i):
    box(c, 34, 74, 62, 84, IRD)
    for x in (38, 58):
        c.fx(x, 79, (150, 156, 176))
    c.capsule(48, 88, 48, 50, 4.2, 3.2, DW[0], dither=0.05)
    box(c, 44, 66, 52, 69, IRD, sep=True)
    poly(c, [(40, 44), (56, 44), (53, 54), (43, 54)], IRD, idx=2)
    flame2(c, 48, 46, 32, 7.5, t, SOUL)
    for j in range(3):
        ph = (t + j / 3.0) % 1.0
        c.fx(48 + 6 * math.sin(6 * ph + j * 2), 40 - ph * 22, (140, 255, 220 - int(ph * 60)))


def skull_candles(c, t, i):
    wax = ramp((230, 222, 198))
    skull(c, 48, 70, 20)
    for (x, y0, h) in ((34, 56, 26), (48, 50, 34), (62, 56, 22)):
        c.blob(x, y0 + 2, 6, 3, wax, dither=0.0)
        c.capsule(x, y0, x, y0 - h + 10, 3.2, 3.0, wax, dither=0.04, sep=True)
        c.capsule(x + 2, y0 - 4, x + 2, y0 + 6, 1.0, 1.0, wax, dither=0.0)
        flame2(c, x, y0 - h + 10, 12, 3.6, t, WARM, seed=x * 0.1, sway=1.0)
    c.blob(26, 84, 6, 2.4, wax, dither=0.0); c.blob(70, 84, 6, 2.4, wax, dither=0.0)


def crystals(c, t, i):
    p = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    base = lerp((70, 150, 230), (150, 120, 250), p)
    c.blob(48, 86, 34, 8, DST[1], dither=0.1)
    for (x, hgt, wdt, k) in ((28, 44, 9, 0.85), (40, 62, 11, 1.0), (54, 72, 12, 1.1), (68, 48, 9, 0.9), (80, 30, 7, 0.8)):
        top = 88 - hgt
        L = lerp(base, (255, 255, 255), 0.30 * k)
        R = lerp(base, (20, 20, 80), 0.35)
        poly(c, [(x - wdt, 88), (x - wdt + 1, top + 8), (x, top - 4), (x, 88)], flat(L), idx=2)
        poly(c, [(x, 88), (x, top - 4), (x + wdt - 1, top + 8), (x + wdt, 88)], flat(R), idx=2)
        c.fx(x - 2, top + 6, (255, 255, 255))
    for j in range(5):
        ph = (t + j / 5.0) % 1.0
        c.fx(24 + j * 14, 54 - ph * 30, lerp(base, (255, 255, 255), 0.5))


def mushrooms(c, t, i):
    p = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    c.blob(48, 88, 36, 5, ramp((70, 66, 60)), dither=0.12)
    caps = [(26, 62, 14, 10, (60, 200, 190)), (50, 50, 20, 14, (150, 90, 230)), (72, 66, 12, 9, (60, 200, 190)), (38, 74, 9, 7, (240, 120, 200))]
    for (x, y, rx, ry, col) in caps:
        c.capsule(x, y, x, 88, 3.6, 4.4, ramp((226, 220, 200)), dither=0.06)
    for (x, y, rx, ry, col) in caps:
        cc = lerp(col, (255, 255, 255), 0.18 * p)
        c.blob(x, y, rx, ry, ramp(cc), dither=0.05, ymax=y + 2)
        for (dx, dy) in ((-rx * 0.4, -ry * 0.4), (rx * 0.3, -ry * 0.55), (rx * 0.1, -ry * 0.1)):
            c.fx(x + dx, y + dy, lerp(cc, (255, 255, 255), 0.6))
    for j in range(5):
        ph = (t + j / 5.0) % 1.0
        c.fx(22 + j * 12 + 3 * math.sin(6 * ph + j), 52 - ph * 36, (150, 255, 230))


def water_drip(c, t, i):
    poly(c, [(36, 0), (60, 0), (51, 26), (48, 34), (45, 26)], DST[1], idx=2)
    tone(c, 36, 0, 46, 30, 1)
    c.blob(48, 88, 24, 4, flat((50, 100, 170)), dither=0.0)
    c.blob(44, 87, 8, 1.4, flat((120, 170, 230)), dither=0.0)
    if i < 5:
        y = 36 + (i / 4.0) ** 2 * 48
        c.blob(48, y, 2.2, 3.2, flat((130, 190, 250)), dither=0.0)
    else:
        for r in (6, 11):
            for a in range(0, 360, 12):
                c.fx(48 + r * 1.9 * math.cos(math.radians(a)), 88 + r * 0.45 * math.sin(math.radians(a)), (150, 200, 250))
        for (dx, dy) in ((-6, -6), (6, -8), (0, -11)):
            c.fx(48 + dx, 84 + dy, (170, 215, 255))
    if i == 4:
        for (dx, dy) in ((-4, 2), (4, 2)):
            c.fx(48 + dx, 86 + dy, (170, 215, 255))


def spike_trap(c, t, i):
    box(c, 4, 78, 91, 91, DST[0])
    box(c, 4, 86, 91, 91, DST[3])
    h = (2, 10, 28, 38, 38, 18)[i]
    for k, x in enumerate(range(10, 90, 10)):
        c.blob(x, 80, 4.4, 2, DST[3], dither=0.0, new=True)
        if h > 2:
            c.tri((x - 3.5, 80), (x + 3.5, 80), (x, 80 - h), ramp((170, 172, 186)), sep=True)


def wisp(c, t, i):
    by = 44 + 4 * math.sin(2 * math.pi * t)
    sw = 5 * math.sin(2 * math.pi * t)
    c.chain([(48, by + 6), (46 - sw * .5, by + 20), (50 - sw, by + 34), (46 - sw * 1.2, by + 46)], [7, 5, 3.4, 1.2], flat((40, 150, 200)), dither=0.0)
    c.chain([(48, by + 6), (47 - sw * .4, by + 18), (49 - sw * .8, by + 28)], [4.6, 3.2, 1.4], flat((110, 220, 250)), dither=0.0)
    for col, r in (((40, 150, 210), 13), ((90, 210, 250), 10), ((190, 245, 255), 6.4), ((255, 255, 255), 3.2)):
        c.blob(48, by, r, r, flat(col), dither=0.0, new=True)
    c.blob(44, by - 2, 2.0, 3.0, flat((20, 40, 80)), dither=0.0); c.blob(53, by - 2, 2.0, 3.0, flat((20, 40, 80)), dither=0.0)
    for j in range(4):
        ph = (t + j / 4.0) % 1.0
        c.fx(36 + j * 8, by + 30 - ph * 26, (160, 240, 255))


def dungeon_anim_list():
    return [("soul_torch", soul_torch), ("skull_candles", skull_candles), ("crystals", crystals),
            ("mushrooms", mushrooms), ("water_drip", water_drip), ("spike_trap", spike_trap), ("wisp", wisp)]


# ---------------------------------------------------------------- tiles
def moss_patch(c, size, mod, seed, only_lower=False):
    for y in range(S):
        for x in range(S):
            cell = c.cell[y][x]
            if cell and cell[1] > 0 and hh(x // size, y // size, seed) % mod == 0:
                cell[0] = MOSSD


def tile_dungeon_wall(c):
    stones(c, 0, 0, 95, 95, DST, bw=24, bh=12, seed=21, sep=False, tile=(4, 8))
    moss_patch(c, 4, 22, 9)


def tile_dungeon_floor(c):
    stones(c, 0, 0, 95, 95, [DST[1], DST[3], DST[0]], bw=32, bh=24, seed=22, sep=False, tile=(3, 4))
    for y in range(S):
        for x in range(S):
            cell = c.cell[y][x]
            if cell and hh(x, y, 4) % 211 == 0:
                cell[1] = 0
                n = c.cell[(y + 1) % S][x]
                if n and n[1] > 0:
                    n[1] = 1


def tile_mossy_floor(c):
    stones(c, 0, 0, 95, 95, [DST[1], DST[3]], bw=32, bh=24, seed=23, sep=False, tile=(3, 4))
    moss_patch(c, 6, 3, 14)
    for y in range(S):
        for x in range(S):
            cell = c.cell[y][x]
            if cell and cell[0] is MOSSD and cell[1] > 0:
                cell[1] = 3 if hh(x, y, 2) % 7 == 0 else (1 if hh(x, y, 3) % 5 == 0 else 2)


EARTH = [ramp((112, 84, 62)), ramp((102, 76, 56)), ramp((122, 92, 68))]
PEB = ramp((138, 134, 144))


def tile_dirt(c):
    def fn(x, y):
        rp = EARTH[(hh(x // 3, y // 3, 6) >> 6) % 3]
        u, v = (x % 8) - 3.5, (y % 8) - 3.5
        if hh(x // 8, y // 8, 7) % 5 == 0 and (u / 2.8) ** 2 + (v / 2.2) ** 2 <= 1.0:
            lum = -(u * 0.5 + v * 0.7) / 3
            return PEB, (3 if lum > 0.3 else 1 if lum < -0.3 else 2)
        if hh(x, y, 8) % 37 == 0:
            return rp, 3
        if hh(x, y - 1, 8) % 37 == 0:
            return rp, 1
        return rp, 2
    fillm(c, 0, 0, 95, 95, fn, None, False)


def dungeon_tile_list():
    return [("tile_dungeon_wall", tile_dungeon_wall), ("tile_dungeon_floor", tile_dungeon_floor),
            ("tile_mossy_floor", tile_mossy_floor), ("tile_dirt", tile_dirt)]


# ---------------------------------------------------------------- build
N_ANIM = 6


def build():
    root = "pixel_dungeon_v7"
    shutil.rmtree(root, ignore_errors=True)
    os.makedirs(f"{root}/frames")
    statics = dungeon_object_list() + dungeon_tile_list()
    anims = dungeon_anim_list()
    cols = 5
    rows = (len(statics) + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * S, rows * S), (0, 0, 0, 0))
    atlas = {"frames": {}, "meta": {"app": "make_dungeon_v7.py", "image": "spritesheet_static.png", "format": "RGBA8888",
                                    "size": {"w": sheet.width, "h": sheet.height}, "frame_size": {"w": S, "h": S}, "scale": 1,
                                    "ground_y": GROUND, "note": "Objects: base on ground_y. tile_* are seamless 96x96. cobweb_corner attaches to a top-left corner (flip for other corners)."}}
    pal = set(); imgs = {}
    for k, (name, fn) in enumerate(statics):
        c = Cv2(); fn(c); im = c.render()
        imgs[name] = im
        im.save(f"{root}/frames/{name}.png")
        x, y = (k % cols) * S, (k // cols) * S
        sheet.paste(im, (x, y))
        atlas["frames"][name] = {"frame": {"x": x, "y": y, "w": S, "h": S}, "sourceSize": {"w": S, "h": S}, "rotated": False, "trimmed": False}
        pal.update(p[:3] for p in im.getdata() if p[3])
    sheet.save(f"{root}/spritesheet_static.png")
    json.dump(atlas, open(f"{root}/spritesheet_static.json", "w"), indent=2)

    asheet = Image.new("RGBA", (N_ANIM * S, len(anims) * S), (0, 0, 0, 0))
    aatlas = {"frames": {}, "animations": {}, "meta": {"app": "make_dungeon_v7.py", "image": "spritesheet_animated.png",
                                                      "format": "RGBA8888", "size": {"w": asheet.width, "h": asheet.height},
                                                      "frame_size": {"w": S, "h": S}, "scale": 1}}
    aframes = {}
    for r, (name, fn) in enumerate(anims):
        names = []; aframes[name] = []
        for i in range(N_ANIM):
            c = Cv2(); fn(c, i / N_ANIM, i); im = c.render()
            fname = f"{name}_{i}"
            im.save(f"{root}/frames/{fname}.png")
            asheet.paste(im, (i * S, r * S))
            aatlas["frames"][fname] = {"frame": {"x": i * S, "y": r * S, "w": S, "h": S}, "sourceSize": {"w": S, "h": S}, "rotated": False, "trimmed": False}
            names.append(fname); aframes[name].append(im)
            pal.update(p[:3] for p in im.getdata() if p[3])
        aatlas["animations"][name] = {"frames": names, "fps": 8, "loop": True}
    asheet.save(f"{root}/spritesheet_animated.png")
    json.dump(aatlas, open(f"{root}/spritesheet_animated.json", "w"), indent=2)

    bg = (40, 38, 54, 255)
    pv = Image.new("RGBA", (sheet.width * 2, sheet.height * 2), bg)
    pv.alpha_composite(sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)); pv.save(f"{root}/preview_static_2x.png")
    av = Image.new("RGBA", (asheet.width * 2, asheet.height * 2), bg)
    av.alpha_composite(asheet.resize((asheet.width * 2, asheet.height * 2), Image.NEAREST)); av.save(f"{root}/preview_animated_2x.png")
    gif = []
    for i in range(N_ANIM):
        g = Image.new("RGBA", (len(anims) * S * 2, S * 2), (24, 22, 34, 255))
        for k, (name, _) in enumerate(anims):
            g.alpha_composite(aframes[name][i].resize((S * 2, S * 2), Image.NEAREST), (k * S * 2, 0))
        gif.append(g.convert("P", palette=Image.ADAPTIVE))
    gif[0].save(f"{root}/preview_animated.gif", save_all=True, append_images=gif[1:], duration=120, loop=0, disposal=2)

    cv = Image.new("RGBA", (630, 500), (0, 0, 0, 255))
    wall, floor = imgs["tile_dungeon_wall"], imgs["tile_dungeon_floor"]
    for y in range(0, 380, 96):
        for x in range(0, 630, 96):
            cv.paste(wall, (x, y))
    for y in range(380, 500, 96):
        for x in range(0, 630, 96):
            cv.paste(floor, (x, y))
    cv.alpha_composite(Image.new("RGBA", (630, 500), (6, 4, 20, 110)))

    def put(im, cx, top):
        cv.alpha_composite(im.resize((S * 2, S * 2), Image.NEAREST), (cx - S, top))
    put(imgs["cobweb_corner"], 96, 0)
    put(imgs["hanging_cage"], 315, 0)
    put(aframes["soul_torch"][1], 205, 120); put(aframes["soul_torch"][4], 425, 120)
    for nm, cx in (("gargoyle", 95), ("dungeon_door", 315), ("skull_pile", 535)):
        put(imgs[nm], cx, 430 - 184)
    cv.convert("RGB").save(f"{root}/itch_cover_630x500.png")

    with open(f"{root}/palette.gpl", "w") as f:
        f.write("GIMP Palette\nName: Pixel Dungeon v7\nColumns: 8\n#\n")
        for i, (a, b, c_) in enumerate(sorted(pal)):
            f.write(f"{a:3d} {b:3d} {c_:3d}  c{i}\n")
    nt = len(dungeon_tile_list())
    open(f"{root}/README.txt", "w").write(f"""PIXEL DUNGEON PACK v7 - crypt, prison and dungeon props, tiles
{len(statics) - nt} static objects, {len(anims)} animated objects, {nt} seamless tiles. All {S}x{S} px, transparent PNG
(tiles are fully opaque and tile seamlessly). Same size and style as the medieval pack.

Static objects: {', '.join(n for n, _ in dungeon_object_list())}
Animated ({N_ANIM} frames @ 8 fps): {', '.join(n for n, _ in anims)}
Tiles: {', '.join(n for n, _ in dungeon_tile_list())}

spritesheet_static.png/.json     all static objects + tiles, 5 columns (TexturePacker-style atlas)
spritesheet_animated.png/.json   one row per animated object, {N_ANIM} columns; JSON has animations
frames/                          every sprite as its own PNG
palette.gpl                      {len(pal)} colors (GIMP / Aseprite / Krita)
preview_*                        nearest-neighbour previews, not for use in game
itch_cover_630x500.png           cover image for an itch.io page
make_dungeon_v7.py               generator source (Python + Pillow)

Objects sit on row {GROUND} of {S}: align the frame bottom to your ground line.
Hanging items (hanging_cage) and wall items (wall_shackles, cobweb_corner) attach to the top/wall instead.
Engine tips: Nearest/Point filtering, no mipmaps. Tiles: set wrap mode to Repeat.
Unity: Sprite Mode Multiple, Grid By Cell Size {S}x{S}, Pixels Per Unit 16.
Godot: AtlasTexture / TileSet with {S}x{S} cells, filter Nearest.

License: CC0 by default - change this line before publishing if you want other terms.
""")
    shutil.copy(__file__, f"{root}/make_dungeon_v7.py")
    with zipfile.ZipFile("pixel_dungeon_v7.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for dp, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(dp, f); z.write(p, p)
    print("done", len(pal), "colors", len(statics), "static", len(anims), "animated")


if __name__ == "__main__":
    build()
