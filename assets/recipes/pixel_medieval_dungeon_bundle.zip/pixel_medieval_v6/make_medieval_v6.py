#!/usr/bin/env python3
"""Pixel medieval pack v6 - 96x96, lit/ramped shading, selective outlines.
Run: python make_birds_v4.py  ->  builds ./pixel_birds_v4/ and pixel_birds_v4.zip
"""
import json, math, os, shutil, sys, zipfile
from PIL import Image

S = 96
GROUND = 91  # last pixel row feet may occupy
LX, LY, LZ = -0.45, -0.65, 0.62
BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]
BLK = (24, 18, 30)
WHT = (255, 255, 255)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def c8(c):
    return tuple(max(0, min(255, int(round(v)))) for v in c)


def ramp(base):
    """4-step hue-shifted ramp: deep, shade, base, light."""
    b = tuple(base)
    deep = lerp(tuple(v * 0.42 for v in b), (34, 22, 70), 0.35)
    shade = lerp(tuple(v * 0.72 for v in b), (70, 50, 120), 0.16)
    light = lerp(tuple(min(255, v * 1.1) for v in b), (255, 238, 175), 0.30)
    return [c8(deep), c8(shade), c8(b), c8(light)]


class Cv:
    def __init__(self):
        self.cell = [[None] * S for _ in range(S)]
        self.pid = 0
        self.dets = []

    # -- shading
    def _idx(self, x, y, nx, ny, nz, dither):
        lum = (nx * LX + ny * LY + nz * LZ) * 0.9 + 0.1
        lum += (BAYER[y % 4][x % 4] / 16.0 - 0.5) * dither
        return 3 if lum > 0.68 else 2 if lum > 0.28 else 1 if lum > -0.22 else 0

    def _put(self, x, y, rp, idx, sep):
        if 0 <= x < S and 0 <= y < S:
            self.cell[y][x] = [rp, idx, self.pid, sep]

    def blob(self, cx, cy, rx, ry, rp, dither=0.07, sep=False, new=True, ymax=None, ymin=None):
        if new:
            self.pid += 1
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            if ymax is not None and y > ymax:
                continue
            if ymin is not None and y < ymin:
                continue
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx, ny = (x - cx) / rx, (y - cy) / ry
                d = nx * nx + ny * ny
                if d > 1.0:
                    continue
                self._put(x, y, rp, self._idx(x, y, nx, ny, math.sqrt(1 - d), dither), sep)

    def capsule(self, ax, ay, bx, by, r0, r1, rp, dither=0.07, sep=False, new=True):
        if new:
            self.pid += 1
        rm = max(r0, r1)
        x0, x1 = int(min(ax, bx) - rm) - 1, int(max(ax, bx) + rm) + 2
        y0, y1 = int(min(ay, by) - rm) - 1, int(max(ay, by) + rm) + 2
        vx, vy = bx - ax, by - ay
        L2 = vx * vx + vy * vy or 1e-9
        for y in range(y0, y1):
            for x in range(x0, x1):
                t = max(0.0, min(1.0, ((x - ax) * vx + (y - ay) * vy) / L2))
                px, py = ax + vx * t, ay + vy * t
                r = r0 + (r1 - r0) * t
                dx, dy = x - px, y - py
                d = (dx * dx + dy * dy) / (r * r)
                if d > 1.0:
                    continue
                self._put(x, y, rp, self._idx(x, y, dx / r, dy / r, math.sqrt(1 - d), dither), sep)

    def chain(self, pts, rs, rp, dither=0.07, sep=False):
        self.pid += 1
        for i in range(len(pts) - 1):
            rpi = rp[i] if isinstance(rp[0], list) else rp
            self.capsule(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], rs[i], rs[i + 1], rpi,
                         dither, sep, new=False)

    def tri(self, a, b, d, rp, idx=2, sep=False):
        self.pid += 1

        def s(p1, p2, p3):
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])
        xs = [a[0], b[0], d[0]]; ys = [a[1], b[1], d[1]]
        for y in range(int(min(ys)) - 1, int(max(ys)) + 2):
            for x in range(int(min(xs)) - 1, int(max(xs)) + 2):
                p = (x, y)
                d1, d2, d3 = s(p, a, b), s(p, b, d), s(p, d, a)
                if not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0)):
                    self._put(x, y, rp, idx, sep)

    def det(self, x, y, c):
        self.dets.append((int(round(x)), int(round(y)), c))

    def eye(self, x, y, iris=None):
        """2x2 eye with a highlight."""
        base = iris or BLK
        self.det(x, y, WHT if iris is None else base)
        self.det(x + 1, y, BLK if iris is None else base)
        self.det(x, y + 1, BLK)
        self.det(x + 1, y + 1, BLK)

    # -- final render
    def render(self):
        g = self.cell

        def at(x, y):
            return g[y][x] if 0 <= x < S and 0 <= y < S else None
        # inner separation lines for flagged parts
        for y in range(S):
            for x in range(S):
                c = g[y][x]
                if c and c[3]:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        n = at(x + dx, y + dy)
                        if n and n[2] < c[2]:
                            c.append("edge")
                            break
        out = [[None] * S for _ in range(S)]
        for y in range(S):
            for x in range(S):
                c = g[y][x]
                if c:
                    idx = 0 if (len(c) > 4) else c[1]
                    out[y][x] = c[0][idx]
        for y in range(S):
            for x in range(S):
                if g[y][x] is None:
                    for dx, dy in ((0, 1), (-1, 0), (1, 0), (0, -1)):
                        n = at(x + dx, y + dy)
                        if n:
                            col = lerp(tuple(v * 0.5 for v in n[0][0]), (18, 10, 28), 0.45)
                            out[y][x] = c8(col)
                            break
        for x, y, col in self.dets:
            if 0 <= x < S and 0 <= y < S and out[y][x] is not None:
                out[y][x] = col
        img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        for y in range(S):
            for x in range(S):
                if out[y][x] is not None:
                    img.putpixel((x, y), out[y][x] + (255,))
        return img


class Pose:
    def __init__(self, kind, i):
        if kind == "idle":
            self.ph = None
            self.dy = [0, 0, 1, 1][i]
            self.hd = [0, 1, 1, 0][i]
            self.tail = [0, 1, 0, -1][i]
            self.hop = [0, 0, 1, 1][i]
            self.blink = (i == 2)
            self.hx = [0, 0, 1, 1][i]
            self.fl = i / 4.0
        else:
            self.ph = i / 6.0
            s = abs(math.sin(2 * math.pi * self.ph))
            self.dy = -int(round(s))
            self.hd = 0
            self.tail = math.sin(2 * math.pi * self.ph)
            self.hop = -int(round(4 * s))
            self.blink = False
            self.hx = int(round(math.sin(2 * math.pi * self.ph)))
            self.fl = i / 6.0


def leg(c, p, x0, top, r, rp, phase, stride=5, lift=5, knee=0.0, pawrp=None, sep=False):
    if p.ph is None:
        fx, l = x0, 0.0
    else:
        f = (p.ph + phase) % 1.0
        if f < 0.5:
            fx, l = x0 + stride * (1 - 4 * f), 0.0
        else:
            u = (f - 0.5) / 0.5
            fx, l = x0 + stride * (-1 + 2 * u), lift * math.sin(math.pi * u)
    fy = GROUND - l - r
    if knee:
        mx, my = (x0 + fx) / 2 + knee, (top + fy) / 2
        c.chain([(x0, top), (mx, my), (fx, fy)], [r * 1.1, r, r * 0.88], rp, sep=sep)
    else:
        c.capsule(x0, top, fx, fy, r * 1.1, r * 0.9, rp, sep=sep)
    c.blob(fx + 1, GROUND - l - 1.2, r * 1.15, 2.2, pawrp or rp, dither=0.0)


def spikes(c, cx, cy, rx, ry, a0, a1, n, length, base, rps):
    for i in range(n):
        th = math.radians(a0 + (a1 - a0) * i / (n - 1))
        bx, by = cx + rx * math.cos(th), cy - ry * math.sin(th)
        nx, ny = math.cos(th) / rx, -math.sin(th) / ry
        nn = math.hypot(nx, ny); nx, ny = nx / nn, ny / nn
        tx, ty = bx + nx * length, by + ny * length
        qx, qy = -ny, nx
        a = (bx - qx * base / 2 - nx * 2, by - qy * base / 2 - ny * 2)
        b = (bx + qx * base / 2 - nx * 2, by + qy * base / 2 - ny * 2)
        lit = nx * LX + ny * LY
        c.tri(a, b, (tx, ty), rps[i % len(rps)], idx=3 if lit > 0.55 else 2 if lit > -0.2 else 1)


# ====================================================================== medieval props (96px)
import random


def flat(col):
    col = c8(col)
    return [col] * 4


class Cv2(Cv):
    """Cv + 'free' pixels drawn after outlining (sparks, sparkles)."""
    def __init__(self):
        super().__init__()
        self.free = []

    def fx(self, x, y, col):
        self.free.append((int(round(x)), int(round(y)), col))

    def render(self):
        img = super().render()
        for x, y, col in self.free:
            if 0 <= x < S and 0 <= y < S:
                img.putpixel((x, y), tuple(col) + (255,))
        return img


# ---- palettes
STN = [ramp((152, 150, 166)), ramp((140, 140, 158)), ramp((160, 154, 164)), ramp((130, 132, 152))]
STL = [ramp((186, 182, 194)), ramp((172, 170, 186)), ramp((192, 186, 192))]
STW = [ramp((126, 108, 100)), ramp((114, 100, 96)), ramp((136, 116, 106)), ramp((106, 94, 94))]
STF = [ramp((124, 130, 150)), ramp((112, 118, 140)), ramp((132, 134, 154)), ramp((106, 114, 136))]
W1, W2, WD, WL = ramp((152, 100, 58)), ramp((130, 84, 48)), ramp((92, 58, 36)), ramp((186, 132, 78))
IR, IRD = ramp((106, 112, 132)), ramp((64, 68, 86))
GD, RD = ramp((248, 206, 66)), ramp((184, 36, 50))
VOID = flat((16, 12, 22))
WOODS = [W1, W2, WL, ramp((142, 92, 52))]


# ---- primitives
def fillm(c, x0, y0, x1, y1, fn, mask=None, sep=True):
    c.pid += 1
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if mask is not None and not mask(x, y):
                continue
            r = fn(x, y)
            if r is None:
                continue
            c._put(x, y, r[0], r[1], sep)


def box(c, x0, y0, x1, y1, rp, bevel=1, sep=True, mask=None):
    def fn(x, y):
        if bevel and (y < y0 + bevel or x < x0 + bevel):
            return rp, 3
        if bevel and (y > y1 - bevel or x > x1 - bevel):
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def stones(c, x0, y0, x1, y1, rps, bw=12, bh=8, mask=None, sep=True, seed=0, tile=None):
    def fn(x, y):
        ry = (y - y0) // bh
        off = (bw // 2) if ry % 2 else 0
        xx = x - x0 + off
        cx = xx // bw
        lx, ly = xx % bw, (y - y0) % bh
        kx, ky = (cx % tile[0], ry % tile[1]) if tile else (cx, ry)
        h = (kx * 73856093) ^ (ky * 19349663) ^ (seed * 83492791)
        rp = rps[(h >> 3) % len(rps)]
        if lx == 0 or ly == bh - 1:
            return rp, 0
        if ly == 0 or lx == 1:
            return rp, 3
        if ly == bh - 2:
            return rp, 1
        sp = (x * 7349 + y * 9157 + seed * 31) % 19
        if sp == 0:
            return rp, 3
        if sp == 1:
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def planks(c, x0, y0, x1, y1, rps, pw=8, vertical=True, mask=None, sep=True, seed=0):
    def fn(x, y):
        a = (x - x0) if vertical else (y - y0)
        b = (y - y0) if vertical else (x - x0)
        k, l = a // pw, a % pw
        rp = rps[(k * 31 + seed) % len(rps)]
        if l == 0:
            return rp, 0
        if l == 1:
            return rp, 3
        if l == pw - 1:
            return rp, 1
        if (b * 5 + k * 13) % 23 == 0 and l > 2:
            return rp, 1
        return rp, 2
    fillm(c, x0, y0, x1, y1, fn, mask, sep)


def poly(c, pts, rp, idx=2, fn=None, sep=True):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]

    def inside(x, y):
        px, py = x + 0.5, y + 0.5
        ins = False
        j = len(pts) - 1
        for i in range(len(pts)):
            xi, yi = pts[i]; xj, yj = pts[j]
            if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi:
                ins = not ins
            j = i
        return ins
    f = fn if fn else (lambda x, y: (rp, idx))
    fillm(c, int(min(xs)), int(min(ys)), int(max(xs)) + 1, int(max(ys)) + 1, f, inside, sep)


def arch_mask(cx, top, half, bottom):
    def m(x, y):
        if y < top or y > bottom:
            return False
        dx = x - cx
        if y >= top + half:
            return abs(dx) <= half
        return dx * dx + (y - (top + half)) ** 2 <= half * half
    return m


def ell_mask(cx, cy, rx, ry):
    return lambda x, y: ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0


def tone(c, x0, y0, x1, y1, d, mask=None):
    for y in range(max(0, y0), min(S, y1 + 1)):
        for x in range(max(0, x0), min(S, x1 + 1)):
            cell = c.cell[y][x]
            if cell and cell[1] > 0 and (mask is None or mask(x, y)):
                cell[1] = max(0, min(3, cell[1] + d))


def flame(c, cx, base_y, h, w, t, seed=0.0, sway=2.0):
    sw = sway * math.sin(2 * math.pi * t + seed)
    flick = 1 + 0.12 * math.sin(4 * math.pi * t + seed * 1.7)
    for col, k in (((214, 48, 34), 1.0), ((250, 124, 32), 0.8), ((255, 196, 64), 0.58), ((255, 240, 176), 0.34)):
        hh, ww = h * k * flick, w * k
        pts = [(cx, base_y - ww * 0.4), (cx + sw * 0.35 * k, base_y - hh * 0.45), (cx + sw * k, base_y - hh)]
        c.chain(pts, [ww, ww * 0.68, 0.7], flat(col), dither=0.0)


# ---------------------------------------------------------------- castle pieces
def castle_tower(c):
    for x in (24, 37, 50, 63):
        stones(c, x, 14, x + 8, 27, STN, bw=9, bh=7, seed=x)
    stones(c, 28, 34, 67, 91, STN, bw=10, bh=7, seed=2, sep=False)
    tone(c, 28, 34, 36, 91, 1); tone(c, 58, 34, 67, 91, -1); tone(c, 28, 34, 67, 38, -1)
    stones(c, 24, 26, 71, 33, STL, bw=12, bh=8, seed=3)
    for x in (35, 58):
        box(c, x, 50, x + 3, 62, VOID, bevel=0)
    box(c, 46, 42, 49, 58, VOID, bevel=0)
    stones(c, 35, 64, 60, 91, STL, bw=8, bh=6, mask=arch_mask(47.5, 64, 12.5, 91), seed=5)
    planks(c, 38, 68, 57, 91, [WD, W2], pw=5, mask=arch_mask(47.5, 68, 10, 91), seed=1)
    box(c, 38, 80, 57, 82, IRD, bevel=0, mask=arch_mask(47.5, 68, 10, 91))
    c.capsule(47.5, 26, 47.5, 3, 1.0, 1.0, WD, dither=0.0)
    c.tri((48, 3), (48, 14), (65, 8.5), RD, sep=True)


def castle_wall(c):
    for k in range(6):
        x = 8 + 14 * k
        stones(c, x, 14, x + 9, 27, STN, bw=10, bh=7, seed=k)
    stones(c, 4, 40, 91, 91, STN, bw=12, bh=8, seed=7, sep=False)
    tone(c, 4, 40, 12, 91, 1); tone(c, 84, 40, 91, 91, -1); tone(c, 4, 40, 91, 44, -1); tone(c, 4, 84, 91, 91, -1)
    stones(c, 2, 26, 93, 39, STL, bw=14, bh=7, seed=9)
    for x in (26, 69):
        box(c, x, 54, x + 3, 68, VOID, bevel=0)
    for (x, y) in ((18, 70), (50, 74), (78, 62)):
        c.blob(x, y, 4, 2.4, ramp((92, 124, 82)), dither=0.2, new=True)


def castle_gate(c):
    for k in range(6):
        x = 8 + 14 * k
        stones(c, x, 10, x + 9, 25, STN, bw=10, bh=7, seed=k)
    stones(c, 4, 32, 91, 91, STN, bw=12, bh=8, seed=4, sep=False)
    tone(c, 4, 32, 12, 91, 1); tone(c, 84, 32, 91, 91, -1)
    stones(c, 2, 24, 93, 31, STL, bw=14, bh=7, seed=8)
    stones(c, 22, 38, 73, 91, STL, bw=9, bh=6, mask=arch_mask(47.5, 38, 26, 91), seed=6)
    inner = arch_mask(47.5, 44, 21, 91)
    fillm(c, 26, 44, 69, 91, lambda x, y: (VOID, 2), inner)
    for x in range(30, 66, 6):
        box(c, x, 44, x + 2, 91, IR, mask=inner, sep=False)
    for y in (53, 64, 75, 86):
        box(c, 26, y, 69, y + 2, IR, mask=inner, sep=False)
    for x in range(30, 66, 6):
        c.tri((x - 0.5, 91), (x + 2.5, 91), (x + 1, 86), IR, sep=False)


def door(c):
    stones(c, 22, 8, 73, 91, STL, bw=9, bh=6, mask=arch_mask(47.5, 8, 26, 91), seed=3)
    dm = arch_mask(47.5, 16, 19, 91)
    planks(c, 28, 16, 67, 91, [WD, W2, W1], pw=6, mask=dm, seed=2)
    for y in (38, 64):
        box(c, 28, y, 67, y + 4, IR, mask=dm, sep=False)
        for x in range(32, 66, 8):
            c.fx(x, y + 2, (196, 202, 220))
    box(c, 28, 86, 67, 91, STN[0], mask=dm, sep=False)
    c.blob(57, 56, 3.2, 3.2, GD, dither=0.0)
    c.det(57, 56, (60, 40, 20)); c.det(57, 57, (60, 40, 20))
    box(c, 18, 88, 77, 91, STN[0], sep=True)


def window(c):
    stones(c, 20, 12, 75, 84, STL, bw=10, bh=7, mask=arch_mask(47.5, 12, 28, 84), seed=4)
    GL = [ramp((50, 96, 210)), ramp((210, 52, 56)), ramp((244, 204, 72)), ramp((60, 170, 110))]

    def fn(x, y):
        u, v = (x - 28) // 8, (y - 20) // 8
        lx, ly = (x - 28) % 8, (y - 20) % 8
        if lx == 0 or ly == 0:
            return IRD, 2
        rp = GL[(u * 2 + v * 3) % 4]
        if lx <= 2 and ly <= 2:
            return rp, 3
        return rp, 2
    fillm(c, 28, 20, 67, 76, fn, arch_mask(47.5, 20, 20, 76))
    box(c, 44, 20, 51, 76, IRD, bevel=0, mask=arch_mask(47.5, 20, 20, 76), sep=False)
    box(c, 14, 80, 81, 88, STL[0], sep=True)


# ---------------------------------------------------------------- furniture
def throne(c):
    poly(c, [(28, 30), (48, 4), (68, 30)], RD, idx=2)
    box(c, 28, 28, 67, 70, ramp((150, 96, 46)))
    box(c, 34, 26, 61, 62, RD)
    for (x, y) in ((38, 34), (47, 30), (56, 34), (42, 46), (52, 46)):
        c.fx(x, y, (250, 214, 90))
    c.blob(48, 12, 4, 4, GD, dither=0.0)
    for x in (28, 66):
        c.blob(x + 1, 28, 3, 3, GD, dither=0.0)
    box(c, 20, 52, 28, 66, ramp((150, 96, 46)))
    box(c, 67, 52, 75, 66, ramp((150, 96, 46)))
    c.blob(24, 50, 4, 3, GD, dither=0.0); c.blob(71, 50, 4, 3, GD, dither=0.0)
    box(c, 22, 62, 73, 72, RD)
    box(c, 20, 70, 75, 76, ramp((150, 96, 46)))
    box(c, 24, 76, 33, 91, ramp((150, 96, 46))); box(c, 62, 76, 71, 91, ramp((150, 96, 46)))
    box(c, 34, 84, 61, 91, ramp((120, 76, 40)))
    box(c, 30, 88, 66, 91, GD)


def table(c):
    box(c, 12, 46, 83, 54, W1)
    box(c, 14, 54, 81, 59, W2)
    box(c, 16, 59, 24, 91, WD); box(c, 71, 59, 79, 91, WD)
    box(c, 24, 76, 71, 80, W2)
    c.capsule(26, 38, 26, 44, 1.2, 1.2, GD, dither=0.0)
    c.blob(26, 36, 4.2, 3.6, GD, dither=0.05)
    c.blob(26, 45, 4.2, 1.4, GD, dither=0.0)
    c.blob(47, 41, 9, 5, ramp((200, 146, 72)), dither=0.12)
    for x in (43, 47, 51):
        c.det(x, 39, (140, 90, 40)); c.det(x + 1, 40, (140, 90, 40))
    c.blob(67, 39, 6, 8, ramp((176, 112, 72)), dither=0.08)
    c.capsule(67, 31, 67, 28, 2.6, 2.2, ramp((176, 112, 72)), dither=0.0)
    c.chain([(72, 36), (77, 39), (72, 44)], [1.2, 1.4, 1.2], ramp((150, 92, 56)), dither=0.0)


def chair(c):
    box(c, 30, 18, 37, 70, W1); box(c, 59, 18, 66, 70, W1)
    c.blob(33.5, 18, 3.4, 3, GD, dither=0.0); c.blob(62.5, 18, 3.4, 3, GD, dither=0.0)
    for y in (26, 40):
        box(c, 37, y, 58, y + 4, W2)
    for x in (42, 49, 56):
        pass
    box(c, 28, 56, 68, 62, RD)
    box(c, 28, 62, 68, 68, W2)
    box(c, 30, 68, 37, 91, WD); box(c, 59, 68, 66, 91, WD)
    box(c, 37, 80, 58, 83, W2)


def bed(c):
    box(c, 6, 36, 16, 91, W1)
    c.blob(11, 35, 6, 3, GD, dither=0.0)
    box(c, 80, 56, 89, 91, W1)
    c.blob(84.5, 55, 5, 2.4, GD, dither=0.0)
    box(c, 8, 74, 87, 82, W2)
    box(c, 16, 62, 80, 76, ramp((246, 240, 228)))
    box(c, 34, 56, 80, 76, RD)
    box(c, 34, 62, 80, 65, GD)
    c.blob(25, 58, 10, 5, ramp((252, 250, 244)), dither=0.04)
    box(c, 10, 82, 16, 91, WD); box(c, 80, 82, 86, 91, WD)


def bookshelf(c):
    box(c, 20, 4, 75, 91, W2)
    box(c, 26, 10, 69, 86, flat((40, 26, 24)), bevel=0)
    rng = random.Random(7)
    cols = [ramp(x) for x in ((176, 40, 44), (40, 96, 176), (60, 140, 80), (200, 150, 50), (120, 60, 130), (180, 100, 60), (50, 60, 90))]
    boards = [36, 60, 84]
    tops = [10, 40, 64]
    for r, (by, ty) in enumerate(zip(boards, tops)):
        x = 27
        while x < 66:
            w = rng.choice((4, 5, 6, 7))
            if x + w > 68:
                break
            hmax = by - ty - 2
            h = rng.randint(max(10, hmax - 8), hmax)
            col = rng.choice(cols)
            box(c, x, by - h, x + w - 1, by - 1, col)
            c.det(x + 1, by - h + 3, (250, 214, 90)) if w >= 5 else None
            x += w
        box(c, 24, by, 71, by + 3, W1)
    c.blob(60, 22, 3, 3, ramp((236, 230, 210)), dither=0.0)


def chest_closed(c):
    box(c, 18, 56, 77, 90, W1)
    planks(c, 18, 56, 77, 90, [W1, W2], pw=8, sep=False)
    dome = lambda x, y: y <= 56 and ((x - 47.5) / 30) ** 2 + ((y - 56) / 18) ** 2 <= 1.0
    body = lambda x, y: 18 <= x <= 77 and 56 <= y <= 90
    planks(c, 18, 38, 77, 56, [W2, W1], pw=8, mask=dome, sep=True)
    allm = lambda x, y: dome(x, y) or body(x, y)
    for x in (28, 61):
        box(c, x, 38, x + 6, 90, IR, mask=allm, sep=False)
    box(c, 18, 54, 77, 58, IR, mask=allm, sep=False)
    box(c, 42, 52, 53, 66, GD)
    c.det(47, 57, (60, 40, 20)); c.det(47, 58, (60, 40, 20)); c.det(47, 59, (60, 40, 20))
    box(c, 16, 87, 79, 91, WD)


def chest_open(c):
    poly(c, [(24, 58), (72, 58), (66, 18), (30, 18)], ramp((92, 40, 44)), idx=2)
    box(c, 30, 14, 66, 21, W2)
    box(c, 36, 14, 41, 58, IR, sep=False); box(c, 55, 14, 60, 58, IR, sep=False)
    box(c, 22, 54, 73, 62, flat((60, 20, 28)), bevel=0)
    c.blob(48, 54, 24, 10, GD, dither=0.2, ymax=60)
    for (x, y, r) in ((30, 50, 3), (62, 49, 3), (40, 44, 3), (54, 43, 3)):
        c.blob(x, y, r, r * 0.8, GD, dither=0.1)
    c.blob(36, 49, 2.6, 2.6, RD, dither=0.0); c.blob(56, 48, 2.6, 2.6, ramp((60, 190, 120)), dither=0.0)
    c.blob(47, 45, 2.6, 2.6, ramp((226, 240, 252)), dither=0.0)
    box(c, 18, 60, 77, 90, W1)
    planks(c, 18, 60, 77, 90, [W1, W2], pw=8, sep=False)
    for x in (28, 61):
        box(c, x, 60, x + 6, 90, IR, sep=False)
    box(c, 42, 60, 53, 72, GD)
    box(c, 16, 87, 79, 91, WD)
    for (x, y) in ((24, 36), (70, 40), (48, 38)):
        c.fx(x, y, WHT); c.fx(x - 1, y, (255, 240, 170)); c.fx(x + 1, y, (255, 240, 170)); c.fx(x, y - 1, (255, 240, 170)); c.fx(x, y + 1, (255, 240, 170))


def barrel(c):
    def w(y):
        return 20 + 5 * math.sin(math.pi * (y - 30) / 60.0)
    body = lambda x, y: 30 <= y <= 90 and abs(x - 47.5) <= w(y)
    planks(c, 20, 30, 76, 90, [W1, W2, WL], pw=6, mask=body, seed=1)
    tone(c, 20, 30, 34, 90, 1, body); tone(c, 62, 30, 76, 90, -1, body)
    for (y0, y1) in ((38, 42), (56, 60), (76, 80)):
        box(c, 20, y0, 76, y1, IR, mask=body, sep=False)
    lid = ell_mask(47.5, 30, 20, 5.5)
    planks(c, 26, 24, 70, 36, [WL, W1], pw=7, vertical=False, mask=lid, seed=2)
    box(c, 28, 86, 68, 91, WD, mask=body)


def anvil(c):
    planks(c, 26, 70, 69, 91, [W2, W1, WD], pw=6, seed=3)
    box(c, 32, 62, 63, 72, IR)
    poly(c, [(40, 48), (56, 48), (62, 62), (34, 62)], IR, idx=2)
    box(c, 20, 34, 77, 49, IR)
    poly(c, [(21, 34), (4, 40), (6, 44), (21, 49)], IR, idx=2)
    tone(c, 20, 34, 77, 36, 1)
    c.fx(30, 30, (255, 220, 120)); c.fx(52, 28, (255, 190, 90)); c.fx(60, 31, (255, 230, 150))


def shield_swords(c):
    box(c, 14, 6, 81, 88, W2)
    planks(c, 14, 6, 81, 88, [W2, W1], pw=9, sep=False)
    steel = ramp((206, 212, 226))
    for mirror in (False, True):
        sx = (lambda x: 96 - x) if mirror else (lambda x: x)
        tip, hilt = (24, 12), (66, 64)
        c.capsule(sx(tip[0]), tip[1], sx(hilt[0]), hilt[1], 1.2, 2.4, steel, dither=0.0, sep=True)
        dx, dy = hilt[0] - tip[0], hilt[1] - tip[1]
        L = math.hypot(dx, dy); px, py = dy / L, -dx / L
        ax, ay = sx(hilt[0] - px * 9), hilt[1] - py * 9
        bx, by = sx(hilt[0] + px * 9), hilt[1] + py * 9
        c.capsule(ax, ay, bx, by, 1.9, 1.9, GD, dither=0.0, sep=True)
        gx, gy = sx(hilt[0] + dx / L * 12), hilt[1] + dy / L * 12
        c.capsule(sx(hilt[0]), hilt[1], gx, gy, 2.2, 2.2, ramp((90, 58, 40)), dither=0.0, sep=True)
        c.blob(gx, gy, 3, 3, GD, dither=0.0)

    def shield_pts(s):
        pts = [(48 + 19 * s, 30), (48 + 19 * s, 54)]
        for a in range(0, 91, 10):
            r = math.radians(a)
            pts.append((48 + 19 * s * math.cos(r), 54 + 32 * s * math.sin(r)))
        pts.append((48, 54 + 32 * s))
        for a in range(90, -1, -10):
            r = math.radians(a)
            pts.append((48 - 19 * s * math.cos(r), 54 + 32 * s * math.sin(r)))
        pts.append((48 - 19 * s, 30))
        return pts
    poly(c, shield_pts(1.0), IR, idx=2)
    poly(c, shield_pts(0.86), RD, fn=lambda x, y: ((GD, 2) if (abs(x - 48) <= 3 or abs(y - 52) <= 3) else (RD, 3 if (x < 48 and y < 52) else 2)))


def well(c):
    stones(c, 20, 62, 76, 91, STN, bw=10, bh=8, mask=lambda x, y: y <= 84 or ((x - 47.5) / 28) ** 2 + ((y - 84) / 7) ** 2 <= 1.0, seed=2)
    tone(c, 20, 62, 32, 91, 1); tone(c, 64, 62, 76, 91, -1)
    rim = ell_mask(47.5, 62, 29, 9)
    stones(c, 18, 52, 77, 72, STL, bw=10, bh=6, mask=rim, seed=3)
    water = ell_mask(47.5, 63, 23, 6)
    fillm(c, 24, 56, 71, 70, lambda x, y: (ramp((60, 112, 196)), 3 if (x + y) % 11 == 0 else (1 if y < 61 else 2)), water)
    box(c, 22, 18, 29, 64, W1); box(c, 66, 18, 73, 64, W1)
    box(c, 18, 14, 77, 22, W2)
    poly(c, [(10, 16), (48, 0), (86, 16)], RD, fn=lambda x, y: ((RD, 0) if y % 5 == 0 else (RD, 3 if (x // 6 + y // 5) % 2 else 2)))
    c.capsule(48, 22, 48, 46, 0.9, 0.9, ramp((170, 130, 80)), dither=0.0)
    box(c, 40, 46, 56, 58, WD)
    box(c, 40, 49, 56, 51, IR, sep=False)


def castle_prop_list():
    return [("castle_tower", castle_tower), ("castle_wall", castle_wall), ("castle_gate", castle_gate),
            ("door_arched", door), ("window_stained", window), ("throne", throne), ("table", table),
            ("chair", chair), ("bed", bed), ("bookshelf", bookshelf), ("chest_closed", chest_closed),
            ("chest_open", chest_open), ("barrel", barrel), ("anvil", anvil),
            ("shield_swords", shield_swords), ("well", well)] + extra_prop_list()


# ---------------------------------------------------------------- animated
def torch(c, t, i):
    box(c, 34, 74, 62, 84, IR)
    for x in (38, 58):
        c.fx(x, 79, (196, 202, 220))
    c.capsule(48, 88, 48, 50, 4.2, 3.2, W1, dither=0.05)
    box(c, 44, 66, 52, 69, IR, sep=True)
    poly(c, [(40, 44), (56, 44), (53, 54), (43, 54)], IR, idx=2)
    flame(c, 48, 46, 32, 7.5, t)
    for j in range(3):
        ph = (t + j / 3.0) % 1.0
        c.fx(48 + 6 * math.sin(6 * ph + j * 2), 40 - ph * 22, (255, 210 - int(ph * 80), 90))


def banner(c, t, i):
    cx, top, H, hw = 48, 16, 62, 22
    box(c, 12, 8, 83, 13, W1)
    c.blob(11, 10.5, 3.6, 3.6, GD, dither=0.0); c.blob(84, 10.5, 3.6, 3.6, GD, dither=0.0)
    c.pid += 1
    for y in range(top, top + H + 1):
        r = (y - top) / H
        shift = int(round(4 * r * math.sin(2 * math.pi * t - (y - top) / 9.0)))
        for x in range(cx - hw, cx + hw + 1):
            dxn = x - cx
            if y > top + H - 14 and abs(dxn) < (y - (top + H - 14)) * 0.9:
                continue
            f = math.sin(2 * math.pi * t + dxn / 4.0)
            idx = 3 if f > 0.55 else (1 if f < -0.45 else 2)
            rp = RD
            if abs(dxn) >= hw - 2 or y <= top + 2:
                rp = GD
            if (abs(dxn) <= 3 and top + 8 <= y <= top + 40) or (abs(y - (top + 20)) <= 3 and abs(dxn) <= 12):
                rp = GD
            c._put(x + shift, y, rp, idx, True)
    for x in (cx - 16, cx, cx + 16):
        c.capsule(x, 13, x, top + 3, 0.9, 0.9, WD, dither=0.0)


def candelabra(c, t, i):
    c.blob(48, 86, 15, 4.4, GD, dither=0.05)
    c.capsule(48, 84, 48, 38, 3.4, 2.2, GD, dither=0.05)
    for y in (72, 54):
        c.blob(48, y, 5, 3.4, GD, dither=0.0)
    c.chain([(48, 52), (38, 54), (28, 46), (28, 36)], [2.2, 2.2, 2.2, 2.2], GD, dither=0.0)
    c.chain([(48, 52), (58, 54), (68, 46), (68, 36)], [2.2, 2.2, 2.2, 2.2], GD, dither=0.0)
    wax = ramp((246, 238, 214))
    for (x, y0) in ((28, 36), (68, 36), (48, 38)):
        c.blob(x, y0 + 1, 4.4, 2, GD, dither=0.0)
        c.capsule(x, y0 - 1, x, y0 - 14, 2.6, 2.6, wax, dither=0.04)
        flame(c, x, y0 - 14, 12, 3.2, t, seed=x * 0.1, sway=1.0)


def fireplace(c, t, i):
    stones(c, 8, 22, 87, 91, STW, bw=14, bh=9, seed=5, sep=False)
    tone(c, 8, 22, 16, 91, 1); tone(c, 80, 22, 87, 91, -1)
    stones(c, 28, 2, 67, 22, STW, bw=12, bh=8, seed=6)
    box(c, 2, 14, 93, 24, STL[0])
    box(c, 24, 40, 71, 91, flat((22, 16, 20)), bevel=0)
    box(c, 20, 34, 75, 41, STL[0])
    box(c, 14, 87, 81, 91, STL[0])
    for y in range(44, 90, 3):
        for x in range(26, 70, 5):
            if (x * 3 + y * 7) % 11 == 0:
                c.det(x, y, (40, 30, 34))
    c.capsule(30, 85, 66, 83, 4.4, 4.4, WD, dither=0.05)
    c.capsule(36, 80, 60, 86, 4.0, 4.0, W2, dither=0.05)
    for (x, hh, sd) in ((38, 30, 0.0), (48, 40, 1.3), (59, 28, 2.4)):
        flame(c, x, 84, hh, 11, t, seed=sd, sway=3.0)
    for j in range(5):
        ph = (t + j / 5.0) % 1.0
        c.fx(36 + j * 6 + 3 * math.sin(7 * ph + j), 78 - ph * 34, (255, 200 - int(ph * 100), 70))


def cauldron(c, t, i):
    for (x, sd) in ((34, 0.0), (48, 1.2), (62, 2.6)):
        flame(c, x, 90, 28, 9, t, seed=sd, sway=2.4)
    c.capsule(28, 90, 68, 88, 3.4, 3.4, WD, dither=0.05)
    for x in (30, 48, 66):
        c.capsule(x, 70, x + (x - 48) * 0.15, 86, 2.6, 2.2, IRD, dither=0.0)
    c.blob(48, 50, 26, 24, ramp((70, 72, 90)), dither=0.06)
    c.blob(48, 30, 28, 6.4, IR, dither=0.04)
    c.blob(48, 30, 23.5, 4.4, flat((88, 214, 96)), dither=0.0)
    for k in range(4):
        ph = (t + k / 4.0) % 1.0
        bx = 36 + k * 8 + 2 * math.sin(5 * ph + k)
        by = 31 - 9 * ph
        rr = 1.6 + 2.2 * (1 - abs(2 * ph - 1))
        c.blob(bx, by, rr, rr, flat((186, 252, 160)), dither=0.0)
    c.blob(36, 44, 5, 8, ramp((100, 102, 120)), dither=0.2)


def animated_list():
    return [("torch", torch), ("banner", banner), ("candelabra", candelabra), ("fireplace", fireplace), ("cauldron", cauldron)] + extra_anim_list()


# ---------------------------------------------------------------- seamless 96x96 tiles
def tile_wall(c):
    stones(c, 0, 0, 95, 95, STW, bw=24, bh=12, seed=3, sep=False, tile=(4, 8))


def tile_floor_stone(c):
    stones(c, 0, 0, 95, 95, STF, bw=32, bh=24, seed=4, sep=False, tile=(3, 4))


def tile_floor_wood(c):
    def fn(x, y):
        row, ly = y // 12, y % 12
        j0 = (row * 37) % 96
        d = (x - j0) % 96
        seg, lx = d // 48, d % 48
        rp = WOODS[(row * 2 + seg) % len(WOODS)]
        if ly == 0 or lx == 0:
            return rp, 0
        if ly == 1:
            return rp, 3
        if ly == 11:
            return rp, 1
        if lx == 4 and ly in (3, 8):
            return rp, 0
        if ((x // 3) * 5 + row * 11) % 13 == 0 and ly in (4, 7):
            return rp, 1
        return rp, 2
    fillm(c, 0, 0, 95, 95, fn, None, False)


def tile_carpet(c):
    base, dark = ramp((176, 34, 48)), ramp((120, 20, 36))

    def fn(x, y):
        u, v = (x % 48) - 24, (y % 48) - 24
        m = abs(u) + abs(v)
        if m <= 12:
            return GD, 3 if m <= 8 else 2
        if m in (14, 15):
            return dark, 1
        if (x + y) % 12 == 0:
            return base, 3
        return base, 2
    fillm(c, 0, 0, 95, 95, fn, None, False)


def tile_list():
    return [("tile_wall", tile_wall), ("tile_floor_stone", tile_floor_stone),
            ("tile_floor_wood", tile_floor_wood), ("tile_carpet", tile_carpet)] + extra_tile_list()


# ---------------------------------------------------------------- extra objects (v6)
STEEL = ramp((178, 186, 206))
PARCH = ramp((240, 224, 180))
GLASS = ramp((176, 214, 234))


def stone_pillar(c):
    planks(c, 36, 24, 59, 82, [STN[0], STN[1]], pw=6, seed=1, sep=False)
    tone(c, 36, 24, 43, 82, 1); tone(c, 52, 24, 59, 82, -1)
    box(c, 29, 14, 66, 24, STL[0])
    box(c, 33, 8, 62, 15, STL[1])
    box(c, 31, 82, 64, 87, STL[0])
    box(c, 27, 87, 68, 91, STL[1])


def stairs(c):
    for k in range(6):
        x0, top = 6 + k * 14, 82 - k * 13
        stones(c, x0, top, x0 + 13, 91, STN, bw=14, bh=6, seed=k + 3, sep=True)
        box(c, x0, top, x0 + 13, top + 3, STL[0])


def drawbridge(c):
    for x in (12, 74):
        box(c, x, 72, x + 9, 91, WD)
    planks(c, 4, 58, 91, 72, [W1, W2, WL], pw=8, seed=2)
    box(c, 4, 54, 91, 59, W2)
    for x in (4, 82):
        box(c, x, 54, x + 9, 74, IR)
        for yy in (58, 68):
            c.fx(x + 4, yy, (206, 212, 228))
    for (sx, sy, ex, ey) in ((9, 54, 22, 6), (86, 54, 73, 6)):
        n = 9
        for k in range(n):
            u = k / (n - 1)
            x, y = sx + (ex - sx) * u, sy + (ey - sy) * u
            if k % 2:
                c.blob(x, y, 1.6, 2.8, IR, dither=0.0)
            else:
                c.blob(x, y, 2.8, 1.6, IR, dither=0.0)
    box(c, 4, 38, 10, 58, W1); box(c, 85, 38, 91, 58, W1)


def cell_bars(c):
    stones(c, 6, 6, 89, 91, [STN[3], STN[1]], bw=14, bh=8, seed=9, sep=False)
    tone(c, 6, 6, 89, 91, -1)
    m = arch_mask(47.5, 16, 22, 78)
    fillm(c, 25, 16, 70, 78, lambda x, y: (VOID, 2), m)
    for x in range(30, 66, 7):
        box(c, x, 16, x + 2, 78, IR, mask=m, sep=False)
    box(c, 25, 40, 70, 42, IR, mask=m, sep=False)
    box(c, 20, 78, 75, 85, STL[0])
    for x in (13, 82):
        for k in range(10):
            y = 12 + k * 6
            c.blob(x, y, 1.5, 2.8, IRD, dither=0.0)
            c.blob(x, y + 3, 2.8, 1.5, IR, dither=0.0)
    c.fx(44, 50, (230, 230, 220)); c.fx(52, 52, (230, 230, 220))


def armor_stand(c):
    box(c, 22, 86, 73, 91, WD); box(c, 45, 70, 51, 88, W2)
    c.capsule(40, 64, 38, 85, 5.0, 4.2, STEEL, dither=0.04, sep=True)
    c.capsule(56, 64, 58, 85, 5.0, 4.2, STEEL, dither=0.04, sep=True)
    poly(c, [(34, 56), (62, 56), (66, 72), (30, 72)], STEEL, idx=2)
    poly(c, [(33, 28), (63, 28), (60, 58), (36, 58)], STEEL, idx=2)
    c.capsule(27, 36, 22, 62, 4.6, 3.6, STEEL, dither=0.04, sep=True)
    c.capsule(69, 36, 74, 62, 4.6, 3.6, STEEL, dither=0.04, sep=True)
    c.blob(29, 32, 7.5, 6, STEEL, dither=0.0, new=True); c.blob(67, 32, 7.5, 6, STEEL, dither=0.0, new=True)
    c.blob(22, 64, 3.6, 3.6, STEEL, dither=0.0); c.blob(74, 64, 3.6, 3.6, STEEL, dither=0.0)
    c.blob(48, 25, 10, 4.4, STEEL, dither=0.0, new=True)
    c.blob(48, 14, 10, 11, STEEL, dither=0.04, new=True)
    box(c, 40, 13, 56, 16, VOID, bevel=0, sep=False)
    c.chain([(48, 5), (56, 0), (60, 7)], [3.2, 2.4, 1.2], ramp((200, 40, 50)), dither=0.04, sep=True)
    box(c, 46, 34, 49, 50, GD, bevel=0, sep=False)
    box(c, 41, 39, 54, 42, GD, bevel=0, sep=False)


def weapon_rack(c):
    for x in (24, 60):
        c.capsule(x, 90, x, 18, 1.6, 1.4, WD, dither=0.0)
        c.tri((x - 3.5, 22), (x + 3.5, 22), (x, 4), STEEL, sep=True)
    for x in (36, 48):
        c.capsule(x, 32, x, 78, 2.2, 1.2, STEEL, dither=0.0, sep=True)
        c.capsule(x - 6, 32, x + 6, 32, 1.8, 1.8, GD, dither=0.0, sep=True)
        c.capsule(x, 32, x, 22, 2.0, 2.0, ramp((90, 58, 40)), dither=0.0, sep=True)
        c.blob(x, 19, 2.8, 2.8, GD, dither=0.0)
    c.capsule(72, 90, 72, 20, 1.8, 1.6, WD, dither=0.0)
    poly(c, [(73, 20), (88, 15), (88, 40), (73, 34)], STEEL, idx=2)
    for x in (10, 80):
        box(c, x, 30, x + 6, 91, W1)
    box(c, 10, 44, 86, 49, W2); box(c, 10, 68, 86, 73, W2)
    box(c, 8, 87, 88, 91, WD)


def market_stall(c):
    for x in (8, 82):
        box(c, x, 14, x + 5, 91, W1)
    box(c, 6, 52, 90, 58, WL)
    box(c, 8, 58, 88, 80, W2)
    planks(c, 8, 58, 88, 80, [W2, W1], pw=10, seed=2, sep=False)
    box(c, 8, 78, 88, 84, WD)

    def fn(x, y):
        stripe = (x // 8) % 2
        rp = RD if stripe else ramp((244, 240, 230))
        e = 4 * math.sqrt(max(0.0, 1 - ((x % 8 - 3.5) / 4.0) ** 2))
        if y > 30 + e - 1:
            return rp, 1
        return rp, 3 if x % 8 < 2 else 2
    mask = lambda x, y: y <= 30 + 4 * math.sqrt(max(0.0, 1 - ((x % 8 - 3.5) / 4.0) ** 2))
    fillm(c, 4, 12, 91, 35, fn, mask)
    box(c, 4, 10, 91, 14, W2)
    box(c, 12, 42, 38, 52, ramp((180, 130, 70)))
    for (x, y) in ((16, 40), (22, 38), (28, 40), (34, 39), (19, 43), (31, 43)):
        c.blob(x, y, 3.8, 3.6, ramp((214, 48, 40)), dither=0.06)
    poly(c, [(54, 52), (74, 52), (74, 42), (60, 40)], ramp((246, 208, 80)), idx=2)
    c.det(62, 46, (210, 160, 40)); c.det(68, 48, (210, 160, 40))
    c.blob(80, 47, 4, 5, ramp((176, 112, 72)), dither=0.06)


def crate(c, x0, y0, x1, y1):
    box(c, x0, y0, x1, y1, WD)
    planks(c, x0 + 3, y0 + 3, x1 - 3, y1 - 3, [W1, W2], pw=7, vertical=False, seed=x0, sep=True)
    c.capsule(x0 + 4, y0 + 4, x1 - 4, y1 - 4, 1.4, 1.4, WD, dither=0.0, sep=True)
    c.capsule(x1 - 4, y0 + 4, x0 + 4, y1 - 4, 1.4, 1.4, WD, dither=0.0, sep=True)


def crate_stack(c):
    crate(c, 8, 48, 50, 91)
    crate(c, 52, 60, 88, 91)
    crate(c, 16, 18, 44, 47)
    c.blob(70, 56, 6, 3, ramp((214, 48, 40)), dither=0.1)


def hay_bale(c):
    hay = ramp((226, 192, 96))

    def rr(x, y):
        if not (10 <= x <= 85 and 38 <= y <= 90):
            return False
        cx = min(max(x, 18), 77); cy = min(max(y, 46), 82)
        return (x - cx) ** 2 + (y - cy) ** 2 <= 64
    def fn(x, y):
        s = (x * 3 + y * 11 + (y // 3) * 7) % 9
        if s == 0:
            return hay, 1
        if s == 4:
            return hay, 3
        return hay, 2
    fillm(c, 10, 38, 85, 90, fn, rr)
    tone(c, 10, 38, 85, 44, 1); tone(c, 10, 82, 85, 90, -1)
    for x in (30, 62):
        box(c, x, 38, x + 3, 90, ramp((120, 84, 52)), mask=rr, sep=False)
    for (x, y, dx) in ((14, 36, -3), (24, 35, 2), (40, 34, -2), (54, 35, 3), (70, 34, -2), (80, 36, 3)):
        c.fx(x, y, (240, 210, 120)); c.fx(x + dx, y - 1, (240, 210, 120)); c.fx(x + dx * 2, y - 2, (240, 210, 120))


def writing_desk(c):
    box(c, 8, 44, 88, 50, W1)
    box(c, 12, 50, 84, 62, W2)
    for x in (16, 52):
        box(c, x, 53, x + 30, 60, W1)
        c.blob(x + 15, 56.5, 1.8, 1.8, GD, dither=0.0)
    box(c, 12, 62, 20, 91, WD); box(c, 76, 62, 84, 91, WD)
    box(c, 20, 78, 76, 82, W2)
    c.capsule(18, 38, 40, 38, 4.2, 4.2, PARCH, dither=0.05, sep=True)
    c.blob(18, 38, 2, 3.6, ramp((200, 180, 130)), dither=0.0)
    box(c, 46, 36, 58, 43, PARCH); box(c, 58, 36, 70, 43, PARCH)
    c.det(58, 37, (120, 90, 60)); c.det(58, 40, (120, 90, 60))
    for k in range(3):
        c.det(48 + k * 3, 38 + k % 2 * 2, (90, 70, 60)); c.det(60 + k * 3, 38 + k % 2 * 2, (90, 70, 60))
    c.blob(78, 41, 4.4, 4.2, ramp((32, 36, 72)), dither=0.04, new=True)
    c.capsule(78, 38, 86, 20, 1.4, 0.5, ramp((250, 248, 244)), dither=0.0, sep=True)


def alchemy_table(c):
    box(c, 8, 52, 88, 58, W1)
    box(c, 12, 58, 84, 63, W2)
    box(c, 14, 63, 22, 91, WD); box(c, 74, 63, 82, 91, WD)
    box(c, 22, 78, 74, 82, W2)
    for (x, col) in ((22, (80, 210, 100)), (40, (180, 80, 220))):
        c.capsule(x, 28, x, 36, 2.6, 2.6, GLASS, dither=0.0)
        c.blob(x, 42, 8, 9, GLASS, dither=0.04, new=True)
        c.blob(x, 45, 6.6, 6.4, flat(col), dither=0.0, new=True)
        c.blob(x - 2, 43, 1.6, 1.6, flat((255, 255, 255)), dither=0.0)
        c.blob(x, 26, 3, 2, ramp((170, 120, 70)), dither=0.0)
    c.capsule(58, 24, 58, 50, 5.4, 5.4, GLASS, dither=0.04, sep=True)
    c.capsule(58, 36, 58, 50, 4.2, 4.2, flat((236, 80, 70)), dither=0.0, sep=True)
    c.blob(58, 22, 3.4, 2.6, ramp((170, 120, 70)), dither=0.0)
    c.blob(76, 48, 8, 5, STN[0], dither=0.04, new=True)
    c.capsule(74, 46, 82, 36, 1.8, 1.4, ramp((200, 196, 186)), dither=0.0, sep=True)
    c.fx(40, 34, (240, 200, 255)); c.fx(22, 34, (200, 255, 210))


def extra_prop_list():
    return [("stone_pillar", stone_pillar), ("stairs", stairs), ("drawbridge", drawbridge), ("cell_bars", cell_bars),
            ("armor_stand", armor_stand), ("weapon_rack", weapon_rack), ("market_stall", market_stall),
            ("crate_stack", crate_stack), ("hay_bale", hay_bale), ("writing_desk", writing_desk),
            ("alchemy_table", alchemy_table)]


# ---------------------------------------------------------------- extra animated
def campfire(c, t, i):
    for a in range(200, 341, 28):
        r = math.radians(a)
        c.blob(48 + 27 * math.cos(r), 82 + 6 * math.sin(r), 5.4, 4.0, STN[0], dither=0.04, new=True)
    c.capsule(26, 78, 70, 86, 4.6, 4.6, W2, dither=0.05)
    c.capsule(26, 86, 70, 78, 4.6, 4.6, WD, dither=0.05)
    for (x, hh, sd, ww) in ((36, 30, 0.0, 10), (48, 46, 1.4, 15), (60, 28, 2.6, 10)):
        flame(c, x, 80, hh, ww, t, seed=sd, sway=3.0)
    for a in range(20, 161, 28):
        r = math.radians(a)
        c.blob(48 + 27 * math.cos(r), 82 + 6 * math.sin(r), 5.6, 4.2, STN[1], dither=0.04, new=True)
    for j in range(5):
        ph = (t + j / 5.0) % 1.0
        c.fx(40 + j * 4 + 4 * math.sin(7 * ph + j), 66 - ph * 40, (255, 200 - int(ph * 110), 70))


def brazier(c, t, i):
    for (x0, x1) in ((28, 42), (68, 54), (48, 48)):
        c.capsule(x0, 91, x1, 58, 2.6, 2.2, IRD, dither=0.0)
    c.blob(48, 52, 24, 16, IR, dither=0.05, ymin=52)
    c.blob(48, 52, 25, 4, IRD, dither=0.0, new=True)
    c.blob(48, 51, 21, 3, flat((255, 112, 40)), dither=0.0, new=True)
    for (x, hh, sd, ww) in ((38, 24, 0.0, 9), (48, 36, 1.2, 13), (58, 22, 2.4, 9)):
        flame(c, x, 51, hh, ww, t, seed=sd, sway=2.4)
    for j in range(4):
        ph = (t + j / 4.0) % 1.0
        c.fx(40 + j * 6 + 3 * math.sin(6 * ph + j), 36 - ph * 28, (255, 210 - int(ph * 100), 80))


def extra_anim_list():
    return [("campfire", campfire), ("brazier", brazier)]


# ---------------------------------------------------------------- extra tiles
GR = [ramp((88, 150, 70)), ramp((98, 162, 76)), ramp((80, 140, 66))]
COB = [ramp((132, 130, 144)), ramp((120, 120, 138)), ramp((142, 134, 140)), ramp((112, 114, 134))]


def hh(x, y, s=0):
    return ((x % 96) * 374761393 + (y % 96) * 668265263 + s * 1442695041) & 0xffffffff


def tile_grass(c):
    def fn(x, y):
        rp = GR[(hh(x // 3, y // 3) >> 7) % 3]
        if hh(x, y, 1) % 47 == 0:
            return rp, 3
        if hh(x, y - 1, 1) % 47 == 0:
            return rp, 1
        if hh(x, y, 2) % 29 == 0:
            return rp, 1
        return rp, 2
    fillm(c, 0, 0, 95, 95, fn, None, False)


def tile_cobble(c):
    bw, bh = 24, 16

    def fn(x, y):
        row = y // bh
        off = (bw // 2) if row % 2 else 0
        cx = ((x + off) // bw) % 4
        lx, ly = (x + off) % bw, y % bh
        u = (lx - bw / 2 + 0.5) / (bw / 2 - 1)
        v = (ly - bh / 2 + 0.5) / (bh / 2 - 1)
        rp = COB[(cx * 3 + row * 5) % 4]
        if u * u + v * v > 1.0:
            return rp, 0
        lum = -(u * 0.5 + v * 0.7)
        return rp, (3 if lum > 0.35 else 1 if lum < -0.35 else 2)
    fillm(c, 0, 0, 95, 95, fn, None, False)


def extra_tile_list():
    return [("tile_grass", tile_grass), ("tile_cobble", tile_cobble)]


# ---------------------------------------------------------------- build
N_ANIM = 6


def build():
    root = "pixel_medieval_v6"
    shutil.rmtree(root, ignore_errors=True)
    os.makedirs(f"{root}/frames")
    statics = castle_prop_list() + tile_list()
    anims = animated_list()
    cols = 5
    rows = (len(statics) + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * S, rows * S), (0, 0, 0, 0))
    atlas = {"frames": {}, "meta": {"app": "make_medieval_v6.py", "image": "spritesheet_static.png", "format": "RGBA8888",
                                    "size": {"w": sheet.width, "h": sheet.height}, "frame_size": {"w": S, "h": S}, "scale": 1,
                                    "ground_y": GROUND, "note": "Objects: feet/base on ground_y. tile_* are seamless 96x96."}}
    pal = set()
    imgs = {}
    for k, (name, fn) in enumerate(statics):
        c = Cv2(); fn(c); im = c.render()
        imgs[name] = im
        im.save(f"{root}/frames/{name}.png")
        x, y = (k % cols) * S, (k // cols) * S
        sheet.paste(im, (x, y))
        atlas["frames"][name] = {"frame": {"x": x, "y": y, "w": S, "h": S}, "sourceSize": {"w": S, "h": S}, "rotated": False, "trimmed": False}
        pal.update(p[:3] for p in im.getdata() if p[3])
    sheet.save(f"{root}/spritesheet_static.png")
    json.dump(atlas, open(f"{root}/spritesheet_static.json", "w"), indent=2)

    asheet = Image.new("RGBA", (N_ANIM * S, len(anims) * S), (0, 0, 0, 0))
    aatlas = {"frames": {}, "animations": {}, "meta": {"app": "make_medieval_v6.py", "image": "spritesheet_animated.png",
                                                      "format": "RGBA8888", "size": {"w": asheet.width, "h": asheet.height},
                                                      "frame_size": {"w": S, "h": S}, "scale": 1}}
    aframes = {}
    for r, (name, fn) in enumerate(anims):
        names = []
        aframes[name] = []
        for i in range(N_ANIM):
            c = Cv2(); fn(c, i / N_ANIM, i); im = c.render()
            fname = f"{name}_{i}"
            im.save(f"{root}/frames/{fname}.png")
            asheet.paste(im, (i * S, r * S))
            aatlas["frames"][fname] = {"frame": {"x": i * S, "y": r * S, "w": S, "h": S}, "sourceSize": {"w": S, "h": S}, "rotated": False, "trimmed": False}
            names.append(fname); aframes[name].append(im)
            pal.update(p[:3] for p in im.getdata() if p[3])
        aatlas["animations"][name] = {"frames": names, "fps": 8, "loop": True}
    asheet.save(f"{root}/spritesheet_animated.png")
    json.dump(aatlas, open(f"{root}/spritesheet_animated.json", "w"), indent=2)

    # previews
    bg = (58, 52, 70, 255)
    pv = Image.new("RGBA", (sheet.width * 2, sheet.height * 2), bg)
    pv.alpha_composite(sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST))
    pv.save(f"{root}/preview_static_2x.png")
    av = Image.new("RGBA", (asheet.width * 2, asheet.height * 2), bg)
    av.alpha_composite(asheet.resize((asheet.width * 2, asheet.height * 2), Image.NEAREST))
    av.save(f"{root}/preview_animated_2x.png")
    gif = []
    for i in range(N_ANIM):
        g = Image.new("RGBA", (len(anims) * S * 2, S * 2), (30, 26, 40, 255))
        for k, (name, _) in enumerate(anims):
            g.alpha_composite(aframes[name][i].resize((S * 2, S * 2), Image.NEAREST), (k * S * 2, 0))
        gif.append(g.convert("P", palette=Image.ADAPTIVE))
    gif[0].save(f"{root}/preview_animated.gif", save_all=True, append_images=gif[1:], duration=120, loop=0, disposal=2)

    # cover 630x500
    cv = Image.new("RGBA", (630, 500), (0, 0, 0, 255))
    wall = imgs["tile_wall"]; floor = imgs["tile_floor_stone"]
    for y in range(0, 380, 96):
        for x in range(0, 630, 96):
            cv.paste(wall, (x, y))
    for y in range(380, 500, 96):
        for x in range(0, 630, 96):
            cv.paste(floor, (x, y))
    cv.alpha_composite(Image.new("RGBA", (630, 500), (10, 6, 24, 90)))

    def put(im, cx, top):
        im = im.resize((S * 2, S * 2), Image.NEAREST)
        cv.alpha_composite(im, (cx - S, top))
    put(imgs["window_stained"], 315, 20)
    put(aframes["banner"][1], 95, 10); put(aframes["banner"][3], 535, 10)
    put(aframes["torch"][1], 205, 120); put(aframes["torch"][4], 425, 120)
    for nm, cx in (("bookshelf", 95), ("throne", 315), ("chest_open", 535)):
        put(imgs[nm], cx, 430 - 184)
    put(imgs["barrel"], 200, 430 - 184 + 30) if False else None
    cv.convert("RGB").save(f"{root}/itch_cover_630x500.png")

    with open(f"{root}/palette.gpl", "w") as f:
        f.write("GIMP Palette\nName: Pixel Medieval v6\nColumns: 8\n#\n")
        for i, (a, b, c_) in enumerate(sorted(pal)):
            f.write(f"{a:3d} {b:3d} {c_:3d}  c{i}\n")
    open(f"{root}/README.txt", "w").write(f"""PIXEL MEDIEVAL PACK v6 - castle pieces, furniture, props, tiles
{len(statics) - len(tile_list())} static objects, {len(anims)} animated objects, {len(tile_list())} seamless tiles. All {S}x{S} px, transparent PNG
(tiles are fully opaque and tile seamlessly).

Static objects: {', '.join(n for n, _ in castle_prop_list())}
Animated ({N_ANIM} frames @ 8 fps): {', '.join(n for n, _ in anims)}
Tiles: {', '.join(n for n, _ in tile_list())}

spritesheet_static.png/.json     all static objects + tiles, 5 columns (TexturePacker-style atlas)
spritesheet_animated.png/.json   one row per animated object, {N_ANIM} columns; JSON has animations
frames/                          every sprite as its own PNG
palette.gpl                      {len(pal)} colors (GIMP / Aseprite / Krita)
preview_*                        nearest-neighbour previews, not for use in game
itch_cover_630x500.png           cover image for an itch.io page
make_medieval_v6.py              generator source (Python + Pillow)

Objects sit on row {GROUND} of {S}: align the frame bottom to your ground line.
Engine tips: Nearest/Point filtering, no mipmaps. Tiles: set wrap mode to Repeat.
Unity: Sprite Mode Multiple, Grid By Cell Size {S}x{S}, Pixels Per Unit 16.
Godot: AtlasTexture / TileSet with {S}x{S} cells, filter Nearest.

License: CC0 by default - change this line before publishing if you want other terms.
""")
    shutil.copy(__file__, f"{root}/make_medieval_v6.py")
    with zipfile.ZipFile("pixel_medieval_v6.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for dp, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(dp, f); z.write(p, p)
    print("done", len(pal), "colors")


if __name__ == "__main__":
    build()
